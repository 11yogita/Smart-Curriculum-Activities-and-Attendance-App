import React from "react";

type BadgeVariant = "safe" | "warning" | "critical" | "pending" | "auto-approved" | "approved" | "rejected" | "active" | "inactive" | "blue" | "purple" | "teal";

interface BadgeProps {
  variant: BadgeVariant;
  children: React.ReactNode;
  className?: string;
}

const variantStyles: Record<BadgeVariant, string> = {
  safe: "bg-[#D2DCB6] text-[#4a5f48]",
  warning: "bg-[#FEF3C7] text-[#D97706]",
  critical: "bg-[#FEE2E2] text-destructive",
  pending: "bg-[#FEF3C7] text-[#D97706]",
  "auto-approved": "bg-[#D2DCB6] text-[#4a5f48]",
  approved: "bg-[#D2DCB6] text-[#4a5f48]",
  rejected: "bg-[#FEE2E2] text-destructive",
  active: "bg-primary text-primary-foreground",
  inactive: "bg-muted text-muted-foreground",
  blue: "bg-primary/20 text-[#778873]",
  purple: "bg-[#778873]/20 text-[#5f6c5d]",
  teal: "bg-[#D2DCB6] text-[#4a5f48]",
};

export function Badge({ variant, children, className = "" }: BadgeProps) {
  return (
    <span
      className={`inline-flex items-center rounded-full px-[10px] py-[2px] text-[11px] font-bold uppercase tracking-wide ${variantStyles[variant]} ${className}`}
    >
      {children}
    </span>
  );
}