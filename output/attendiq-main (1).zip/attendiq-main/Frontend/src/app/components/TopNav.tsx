import React from "react";
import { Bell, ChevronRight } from "lucide-react";

interface TopNavProps {
  breadcrumb: string[];
  userInitials?: string;
}

export function TopNav({ breadcrumb, userInitials = "RS" }: TopNavProps) {

  return (
    <div className="h-[60px] bg-card border-b border-border flex items-center justify-between px-8 flex-shrink-0">
      {/* Breadcrumb */}
      <div className="flex items-center gap-1.5 text-[14px]">
        {breadcrumb.map((crumb, idx) => (
          <React.Fragment key={crumb}>
            {idx > 0 && <ChevronRight size={14} className="text-muted-foreground" />}
            <span className={idx === breadcrumb.length - 1 ? "text-foreground font-medium" : "text-muted-foreground"}>
              {crumb}
            </span>
          </React.Fragment>
        ))}
      </div>

      {/* Right side */}
      <div className="flex items-center gap-3">
        <button
          className="relative p-2 rounded-[6px] hover:bg-background transition-colors"
        >
          <Bell size={18} className="text-foreground" />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-destructive rounded-full" />
        </button>
        <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-primary-foreground text-[12px] font-bold cursor-pointer">
          {userInitials}
        </div>
      </div>
    </div>
  );
}