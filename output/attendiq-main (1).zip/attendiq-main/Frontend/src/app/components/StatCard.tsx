import React from "react";

interface StatCardProps {
  label: string;
  value: string | number;
  subLabel?: string;
  borderColor?: string;
  valueColor?: string;
  icon?: React.ReactNode;
  badge?: React.ReactNode;
}

export function StatCard({ label, value, subLabel, borderColor, valueColor, icon, badge }: StatCardProps) {
  return (
    <div
      className="bg-card rounded-[8px] border border-border p-5 shadow-[0_1px_4px_rgba(0,0,0,0.06)] flex flex-col gap-1 flex-1"
      style={borderColor ? { borderLeft: `4px solid ${borderColor}` } : {}}
    >
      <div className="flex items-center justify-between">
        <span className="text-[12px] text-muted-foreground uppercase tracking-wide font-medium">{label}</span>
        {icon && <span className="text-muted-foreground">{icon}</span>}
        {badge && badge}
      </div>
      <div
        className="text-[28px] font-bold leading-tight"
        style={{ color: valueColor || "#1A1A2E" }}
      >
        {value}
      </div>
      {subLabel && <div className="text-[12px] text-muted-foreground">{subLabel}</div>}
    </div>
  );
}
