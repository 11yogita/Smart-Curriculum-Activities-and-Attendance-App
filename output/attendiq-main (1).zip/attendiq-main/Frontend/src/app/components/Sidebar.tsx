import React from "react";
import { useNavigate, useLocation } from "react-router";
import {
  LayoutDashboard,
  CalendarDays,
  FileText,
  Clock,
  BookOpen,
  Users,
  CheckSquare,
  BarChart2,
  Upload,
  UserCog,
  LogOut,
} from "lucide-react";

type Role = "student" | "teacher" | "admin";

interface NavItem {
  label: string;
  path: string;
  icon: React.ReactNode;
  badge?: number;
}

const studentNav: NavItem[] = [
  { label: "Dashboard", path: "/student/dashboard", icon: <LayoutDashboard size={16} /> },
  { label: "Predict Leave", path: "/student/predict", icon: <BarChart2 size={16} /> },
  { label: "Apply Leave", path: "/student/leave/apply", icon: <FileText size={16} /> },
  { label: "Leave History", path: "/student/leave/history", icon: <Clock size={16} /> },
  { label: "Timetable", path: "/student/timetable", icon: <CalendarDays size={16} /> },
];

const teacherNav: NavItem[] = [
  { label: "Dashboard", path: "/teacher/dashboard", icon: <LayoutDashboard size={16} /> },
  { label: "Leave Approvals", path: "/teacher/leaves", icon: <CheckSquare size={16} />, badge: 3 },
  { label: "Student Reports", path: "/teacher/students", icon: <Users size={16} /> },
];

const adminNav: NavItem[] = [
  { label: "Dashboard", path: "/admin/dashboard", icon: <LayoutDashboard size={16} /> },
  { label: "User Management", path: "/admin/users", icon: <UserCog size={16} /> },
  { label: "Subject Management", path: "/admin/subjects", icon: <BookOpen size={16} /> },
];

const roleConfig: Record<Role, { nav: NavItem[]; user: string; role: string; activeColor: string }> = {
  student: {
    nav: studentNav,
    user: "Rahul Sharma",
    role: "Student • CS2301",
    activeColor: "var(--color-primary-foreground)",
  },
  teacher: {
    nav: teacherNav,
    user: "Dr. Priya Patel",
    role: "Teacher",
    activeColor: "var(--color-primary-foreground)",
  },
  admin: {
    nav: adminNav,
    user: "Admin User",
    role: "Administrator",
    activeColor: "var(--color-primary-foreground)",
  },
};

interface SidebarProps {
  role: Role;
}

export function Sidebar({ role }: SidebarProps) {
  const navigate = useNavigate();
  const location = useLocation();
  const { nav, user, role: roleLabel, activeColor } = roleConfig[role];

  return (
    <div className="w-[240px] min-h-screen bg-secondary flex flex-col flex-shrink-0">
      {/* Logo */}
      <div className="px-6 py-5 border-b border-white/10">
        <button
          onClick={() => navigate("/")}
          className="text-[20px] font-bold text-primary-foreground tracking-tight hover:opacity-80 transition-opacity"
        >
          AttendIQ
        </button>
        <div className="text-[11px] text-primary-foreground/80 mt-0.5 capitalize">{role} portal</div>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-4 flex flex-col gap-1">
        {nav.map((item) => {
          const isActive = location.pathname === item.path;
          return (
            <button
              key={item.path}
              onClick={() => navigate(item.path)}
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-[6px] text-[14px] transition-all text-left"
              style={{
                backgroundColor: isActive ? activeColor : "transparent",
                color: isActive ? "var(--color-primary)" : "var(--color-primary-foreground)",
              }}
              onMouseEnter={(e) => {
                if (!isActive) e.currentTarget.style.backgroundColor = "rgba(255,255,255,0.07)";
              }}
              onMouseLeave={(e) => {
                if (!isActive) e.currentTarget.style.backgroundColor = "transparent";
              }}
            >
              {item.icon}
              <span className="flex-1">{item.label}</span>
              {item.badge && (
                <span className="bg-destructive text-primary-foreground text-[10px] font-bold rounded-full w-5 h-5 flex items-center justify-center">
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* User info */}
      <div className="px-4 py-4 border-t border-white/10">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-primary-foreground text-[12px] font-bold flex-shrink-0">
            {user.split(" ").map((n) => n[0]).join("").slice(0, 2)}
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-[13px] text-primary-foreground font-medium truncate">{user}</div>
            <div className="text-[11px] text-primary-foreground/80 truncate">{roleLabel}</div>
          </div>
        </div>
        <button
          onClick={() => navigate("/")}
          className="mt-3 w-full flex items-center gap-2 text-[12px] text-primary-foreground/80 hover:text-primary-foreground transition-colors px-1"
        >
          <LogOut size={13} />
          Sign out
        </button>
      </div>
    </div>
  );
}