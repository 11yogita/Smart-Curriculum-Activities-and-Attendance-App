import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { api } from '../../lib/api';

export interface User {
  id: string;
  email: string;
  full_name: string;
  role: 'student' | 'teacher' | 'admin';
  student_id: string | null;
}

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  login: (access: string, refresh: string, userData: User) => void;
  logout: () => void;
  checkAuth: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const login = (access: string, refresh: string, userData: User) => {
    localStorage.setItem('access_token', access);
    localStorage.setItem('refresh_token', refresh);
    localStorage.setItem('user', JSON.stringify(userData));
    setUser(userData);
  };

  const logout = () => {
    localStorage.removeItem('access_token');
    localStorage.removeItem('refresh_token');
    localStorage.removeItem('user');
    setUser(null);
  };

  const checkAuth = async () => {
    const token = localStorage.getItem('access_token');
    const storedUser = localStorage.getItem('user');

    if (token && storedUser) {
      try {
        // We will assume the stored user is correct initially for fast render
        setUser(JSON.parse(storedUser));
        
        // Then we can verifiy the token against the backend optionally
        const res = await api.get('/auth/me/');
        if (res.data) {
           setUser(res.data);
           localStorage.setItem('user', JSON.stringify(res.data));
        }
      } catch (error) {
         // The interceptor might handle the 401 refresh, 
         // If completely failed, interceptor triggers 'auth:logout', we should clear state
      }
    } else {
        logout();
    }
  };

  useEffect(() => {
    const initAuth = async () => {
       await checkAuth();
       setIsLoading(false);
    };
    initAuth();

    const handleLogoutEvent = () => logout();
    window.addEventListener('auth:logout', handleLogoutEvent);
    
    return () => {
      window.removeEventListener('auth:logout', handleLogoutEvent);
    };
  }, []);

  return (
    <AuthContext.Provider value={{ user, isLoading, login, logout, checkAuth }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
