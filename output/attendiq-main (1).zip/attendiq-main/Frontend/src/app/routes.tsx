import { createBrowserRouter, Navigate } from "react-router";
import type { ReactNode } from "react";
import { AuthProvider } from "./contexts/AuthContext";
import LoginPage from "./pages/LoginPage";
import LandingPage from "./pages/LandingPage";
import StudentDashboard from "./pages/student/StudentDashboard";
import AttendancePredictor from "./pages/student/AttendancePredictor";
import ApplyLeave from "./pages/student/ApplyLeave";
import LeaveHistory from "./pages/student/LeaveHistory";
import Timetable from "./pages/student/Timetable";
import TeacherDashboard from "./pages/teacher/TeacherDashboard";
import LeaveApprovals from "./pages/teacher/LeaveApprovals";
import StudentReports from "./pages/teacher/StudentReports";
import AdminDashboard from "./pages/admin/AdminDashboard";
import UserManagement from "./pages/admin/UserManagement";
import SubjectManagement from "./pages/admin/SubjectManagement";

const RootLayout = ({ children }: { children: ReactNode }) => (
  <AuthProvider>{children}</AuthProvider>
);

export const router = createBrowserRouter([
  { path: "/", element: <RootLayout><LandingPage /></RootLayout> },
  { path: "/login", element: <RootLayout><LoginPage /></RootLayout> },
  { path: "/student/dashboard", element: <RootLayout><StudentDashboard /></RootLayout> },
  { path: "/student/predict", element: <RootLayout><AttendancePredictor /></RootLayout> },
  { path: "/student/leave/apply", element: <RootLayout><ApplyLeave /></RootLayout> },
  { path: "/student/leave/history", element: <RootLayout><LeaveHistory /></RootLayout> },
  { path: "/student/timetable", element: <RootLayout><Timetable /></RootLayout> },
  { path: "/teacher/dashboard", element: <RootLayout><TeacherDashboard /></RootLayout> },
  { path: "/teacher/leaves", element: <RootLayout><LeaveApprovals /></RootLayout> },
  { path: "/teacher/students", element: <RootLayout><StudentReports /></RootLayout> },
  { path: "/admin/dashboard", element: <RootLayout><AdminDashboard /></RootLayout> },
  { path: "/admin/users", element: <RootLayout><UserManagement /></RootLayout> },
  { path: "/admin/subjects", element: <RootLayout><SubjectManagement /></RootLayout> },
  { path: "*", element: <Navigate to="/login" replace /> },
]);
