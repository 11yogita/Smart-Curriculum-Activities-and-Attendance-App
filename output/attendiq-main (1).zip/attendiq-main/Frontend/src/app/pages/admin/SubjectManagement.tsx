import React, { useState, useEffect } from "react";
import { Sidebar } from "../../components/Sidebar";
import { TopNav } from "../../components/TopNav";
import { Search, ChevronDown, Plus, Pencil, Trash2, X, Loader2 } from "lucide-react";
import { api } from "../../../lib/api";
import { useAuth } from "../../contexts/AuthContext";

interface SubjectData {
  id: string;
  code: string;
  name: string;
  sem: string;
  dept: string;
  teacher: string;
  teacher_id: string;
  students: number;
  minPct: number;
  custom: boolean;
}

interface Teacher {
  id: string;
  full_name: string;
}

interface EditModalProps {
  subject: SubjectData | null;
  teachers: Teacher[];
  onClose: () => void;
  onSave: (data: SubjectSavePayload) => Promise<void>;
}

interface SubjectSavePayload {
  id?: string;
  name: string;
  subject_code: string;
  teacher: string;
  credits: number;
}

interface SubjectApiItem {
  id: string;
  subject_code: string;
  name: string;
  teacher_name: string | null;
  teacher: string;
  enrolled_count: number;
}

function EditModal({ subject, teachers, onClose, onSave }: EditModalProps) {
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: subject?.name || "",
    subject_code: subject?.code || "",
    teacher: subject?.teacher_id || (teachers.length > 0 ? teachers[0].id : ""),
    credits: 3 // Defaulting credits since it's required by backend but not in the original UI mock
  });

  const handleSubmit = async () => {
    setLoading(true);
    try {
      await onSave({ ...formData, id: subject?.id });
      onClose();
    } catch (e) {
      // console.error(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center" style={{ backgroundColor: "rgba(0,0,0,0.4)" }}>
      <div className="bg-card rounded-[12px] shadow-[0_16px_48px_rgba(0,0,0,0.16)] w-[480px]">
        <div className="flex items-center justify-between px-8 pt-7 pb-5 border-b border-border">
          <h2 className="text-[18px] font-bold text-foreground">
            {subject ? `Edit Subject — ${subject.code}` : "Create New Subject"}
          </h2>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground">
            <X size={20} />
          </button>
        </div>
        <div className="px-8 py-6 space-y-4">
          <div>
            <label className="block text-[12px] font-medium text-muted-foreground uppercase tracking-wide mb-1.5">Subject Name</label>
            <input
              value={formData.name}
              onChange={(e) => setFormData({...formData, name: e.target.value})}
              className="w-full border border-border rounded-[6px] px-3 py-2.5 text-[14px] text-foreground outline-none focus:border-primary"
            />
          </div>
          <div>
            <label className="block text-[12px] font-medium text-muted-foreground uppercase tracking-wide mb-1.5">Subject Code</label>
            <input
              value={formData.subject_code}
              onChange={(e) => setFormData({...formData, subject_code: e.target.value})}
              disabled={!!subject} // Disable code edit if it's an existing subject
              className="w-full border border-border rounded-[6px] px-3 py-2.5 text-[14px] text-foreground outline-none focus:border-primary disabled:bg-background disabled:text-muted-foreground"
            />
          </div>
          <div className="flex gap-3">
            <div className="flex-1">
              <label className="block text-[12px] font-medium text-muted-foreground uppercase tracking-wide mb-1.5">Semester</label>
              <div className="relative">
                <select defaultValue={subject?.sem || "Sem 5"} className="w-full border border-border rounded-[6px] px-3 py-2.5 text-[14px] text-foreground outline-none appearance-none bg-card focus:border-primary">
                  {["Sem 1", "Sem 2", "Sem 3", "Sem 4", "Sem 5", "Sem 6", "Sem 7", "Sem 8"].map((s) => <option key={s}>{s}</option>)}
                </select>
                <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
              </div>
            </div>
            <div className="flex-1">
              <label className="block text-[12px] font-medium text-muted-foreground uppercase tracking-wide mb-1.5">Department</label>
              <div className="relative">
                <select className="w-full border border-border rounded-[6px] px-3 py-2.5 text-[14px] text-foreground outline-none appearance-none bg-card focus:border-primary text-muted-foreground">
                  <option>N/A (Backend not tracking yet)</option>
                </select>
                <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
              </div>
            </div>
          </div>
          <div>
            <label className="block text-[12px] font-medium text-muted-foreground uppercase tracking-wide mb-1.5">Assigned Teacher</label>
            <div className="relative">
              <select 
                value={formData.teacher} 
                onChange={(e) => setFormData({...formData, teacher: e.target.value})}
                className="w-full border border-border rounded-[6px] px-3 py-2.5 text-[14px] text-foreground outline-none appearance-none bg-card focus:border-primary">
                {teachers.map((t) => <option key={t.id} value={t.id}>{t.full_name}</option>)}
              </select>
              <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
            </div>
          </div>
          <div>
            <label className="block text-[12px] font-medium text-muted-foreground uppercase tracking-wide mb-1.5">Credits</label>
            <input
              type="number"
              min={1}
              max={6}
              value={formData.credits}
              onChange={(e) => setFormData({...formData, credits: parseInt(e.target.value)})}
              className="w-full border border-border rounded-[6px] px-3 py-2.5 text-[14px] text-foreground outline-none focus:border-primary"
            />
            <p className="text-[12px] text-muted-foreground mt-1">Default 3. Range: 1–6</p>
          </div>
        </div>
        <div className="flex gap-3 px-8 pb-7">
          <button onClick={onClose} disabled={loading} className="flex-1 border border-border text-foreground rounded-[6px] h-11 text-[14px] font-medium hover:bg-background transition-colors disabled:opacity-50">
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            disabled={loading || !formData.name || !formData.subject_code || !formData.teacher}
            className="flex-1 flex items-center justify-center bg-primary text-primary-foreground rounded-[6px] h-11 text-[14px] font-medium hover:bg-primary/90 transition-colors disabled:opacity-50"
          >
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : "Save Changes"}
          </button>
        </div>
      </div>
    </div>
  );
}

export default function SubjectManagement() {
  const { user } = useAuth();
  
  const [subjects, setSubjects] = useState<SubjectData[]>([]);
  const [teachers, setTeachers] = useState<Teacher[]>([]);
  const [loading, setLoading] = useState(true);

  const [editingSubject, setEditingSubject] = useState<SubjectData | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [search, setSearch] = useState("");

  const fetchData = async () => {
    try {
      setLoading(true);
      // Fetch subjects
      const subRes = await api.get('/admin/subjects/');
      const formattedSubjects: SubjectData[] = (subRes.data.results || []).map((s: SubjectApiItem) => ({
        id: s.id,
        code: s.subject_code,
        name: s.name,
        sem: "Sem 5", // Mock since the backend doesn't store this yet
        dept: "CS",  // Mock
        teacher: s.teacher_name || "Unassigned",
        teacher_id: s.teacher,
        students: s.enrolled_count,
        minPct: 75,
        custom: false,
      }));
      setSubjects(formattedSubjects);

      // Fetch teachers for the dropdown
      const typeRes = await api.get('/admin/users/?role=teacher');
      setTeachers(typeRes.data.results || []);
    } catch (err) {
      // console.error("Failed to load subjects", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleSave = async (data: SubjectSavePayload) => {
    try {
      if (data.id) {
        await api.put(`/admin/subjects/${data.id}/`, data);
      } else {
        await api.post('/admin/subjects/', data);
      }
      await fetchData(); // Refresh data
    } catch (err) {
      // console.error("Failed to save subject", err);
      // Depending on axios setup, could show toast here
      throw err;
    }
  };
  
  const handleDelete = async (id: string, enrolled: number) => {
    if (enrolled > 0) return;
    try {
      await api.delete(`/admin/subjects/${id}/`);
      setSubjects(subjects.filter(s => s.id !== id));
    } catch (err) {
      // console.error("Failed to delete", err);
    }
  };

  const filtered = subjects.filter((s) =>
    s.name.toLowerCase().includes(search.toLowerCase()) ||
    s.code.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="flex h-screen bg-background overflow-hidden" style={{ fontFamily: "Inter, sans-serif" }}>
      <Sidebar role="admin" />
      <div className="flex-1 flex flex-col overflow-hidden">
        <TopNav breadcrumb={["Admin", "Subject Management"]} userInitials={user?.full_name?.substring(0, 2).toUpperCase() || "A"} />
        <div className="flex-1 overflow-y-auto p-8 space-y-5">

          {/* Header */}
          <div className="flex items-center justify-between">
            <h1 className="text-[22px] font-bold text-foreground">Subject Management</h1>
            <button 
              onClick={() => setIsCreating(true)}
              className="flex items-center gap-2 bg-primary text-primary-foreground rounded-[6px] px-4 h-10 text-[13px] font-medium hover:bg-primary/90 transition-colors">
              <Plus size={15} /> Add New Subject
            </button>
          </div>

          {/* Filter bar */}
          <div className="bg-card rounded-[8px] border border-border p-4 flex items-center gap-3">
            <div className="relative flex-1 max-w-xs">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search subject..."
                className="w-full border border-border rounded-[6px] pl-8 pr-3 py-2 text-[13px] text-foreground outline-none focus:border-primary"
              />
            </div>
            {["Semester", "Department"].map((label) => (
              <div key={label} className="relative">
                <select className="border border-border rounded-[6px] px-3 py-2 pr-8 text-[13px] text-foreground outline-none appearance-none bg-card">
                  <option>All {label}s</option>
                </select>
                <ChevronDown size={13} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
              </div>
            ))}
          </div>

          {/* Table */}
          <div className="bg-card rounded-[8px] border border-border shadow-[0_1px_4px_rgba(0,0,0,0.06)] overflow-hidden">
            <table className="w-full">
              <thead>
                <tr style={{ backgroundColor: "var(--secondary)" }}>
                  {["Code", "Subject Name", "Semester", "Department", "Assigned Teacher", "Students", "Min Attendance %", "Actions"].map((h) => (
                    <th key={h} className="text-left text-[11px] font-bold text-secondary-foreground uppercase tracking-wide px-4 py-3 whitespace-nowrap">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr>
                    <td colSpan={8} className="px-4 py-8 text-center text-muted-foreground flex items-center justify-center">
                      <Loader2 className="w-6 h-6 animate-spin text-primary" />
                    </td>
                  </tr>
                ) : filtered.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="px-4 py-8 text-center text-muted-foreground">
                      No subjects found.
                    </td>
                  </tr>
                ) : filtered.map((s, idx) => {
                  const minPct = s.minPct;
                  const isCustom = s.custom;
                  const canDelete = s.students === 0;
                  return (
                    <tr key={s.id} style={{ backgroundColor: idx % 2 === 0 ? "#FFFFFF" : "#F8F9FA" }} className="h-12 hover:bg-[#F0F7FF] transition-colors">
                      <td className="px-4 py-3 text-[13px] font-medium text-foreground">{s.code}</td>
                      <td className="px-4 py-3 text-[13px] font-medium text-foreground">{s.name}</td>
                      <td className="px-4 py-3 text-[13px] text-muted-foreground">{s.sem}</td>
                      <td className="px-4 py-3 text-[13px] text-foreground">{s.dept}</td>
                      <td className="px-4 py-3 text-[13px] text-foreground">{s.teacher}</td>
                      <td className="px-4 py-3 text-[13px] text-foreground">{s.students}</td>
                      <td className="px-4 py-3">
                        {isCustom ? (
                          <span className="bg-[#FEF3C7] text-[#D97706] text-[11px] font-bold rounded-full px-2.5 py-1">
                            {minPct}% custom
                          </span>
                        ) : (
                          <span className="text-[13px] text-foreground">{minPct}%</span>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => setEditingSubject(s)}
                            className="flex items-center gap-1 text-[12px] text-foreground border border-border rounded-[4px] px-2.5 py-1 hover:bg-background transition-colors"
                          >
                            <Pencil size={11} /> Edit
                          </button>
                          <div className="relative group">
                            <button
                              onClick={() => handleDelete(s.id, s.students)}
                              disabled={!canDelete}
                              className={`flex items-center gap-1 text-[12px] border rounded-[4px] px-2.5 py-1 transition-colors ${
                                canDelete 
                                ? "text-destructive border-destructive hover:bg-destructive hover:text-destructive-foreground cursor-pointer" 
                                : "text-[#9CA3AF] border-border cursor-not-allowed bg-background"
                              }`}
                            >
                              <Trash2 size={11} /> Delete
                            </button>
                            {!canDelete && (
                              <div className="absolute bottom-full mb-1 left-1/2 -translate-x-1/2 hidden group-hover:block bg-card text-foreground text-[11px] rounded px-2 py-1 whitespace-nowrap z-10 border border-border shadow">
                                Cannot delete: {s.students} students enrolled
                              </div>
                            )}
                          </div>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {(editingSubject || isCreating) && (
        <EditModal
          subject={editingSubject}
          teachers={teachers}
          onClose={() => { setEditingSubject(null); setIsCreating(false); }}
          onSave={handleSave}
        />
      )}
    </div>
  );
}
