import React, { useState, useEffect } from "react";
import { Sidebar } from "../../components/Sidebar";
import { TopNav } from "../../components/TopNav";
import { Badge } from "../../components/Badge";
import { Search, ChevronDown, Plus, X, Pencil, Loader2 } from "lucide-react";
import { api } from "../../../lib/api";
import { useAuth } from "../../contexts/AuthContext";

const TEMP_PASSWORDS_STORAGE_KEY = "admin_temp_passwords_by_email";

const normalizeEmail = (email: string) => email.trim().toLowerCase();

interface UserData {
  id: string;
  full_name: string;
  email: string;
  role: string;
  is_active?: boolean;
  student_id?: string;
  generated_password?: string;
  
  // Student specifics
  roll_number?: string;
  department?: string;
  batch?: string;
  
  // Teacher specifics
  employee_id?: string;
}

interface CreateUserPayload {
  email: string;
  role: "student" | "teacher";
  full_name: string;
  student_id?: string;
}

export default function UserManagement() {
  const { user } = useAuth();
  const [tab, setTab] = useState<"Students" | "Teachers">("Students");
  const [search, setSearch] = useState("");
  const [drawerOpen, setDrawerOpen] = useState(false);
  
  const [usersInfo, setUsersInfo] = useState<UserData[]>([]);
  const [loading, setLoading] = useState(false);
  const [fetchError, setFetchError] = useState<string | null>(null);
  
  // Drawer state
  const [newRole, setNewRole] = useState<"student" | "teacher">("student");
  const [formData, setFormData] = useState({
    first_name: "",
    last_name: "",
    email: "",
    department: "Computer Science",
    roll_number: "", // for student
    employee_id: "", // for teacher
  });
  const [creating, setCreating] = useState(false);
  const [generatedPassword, setGeneratedPassword] = useState<string | null>(null);
  const [createError, setCreateError] = useState<string | null>(null);
  const [passwordByEmail, setPasswordByEmail] = useState<Record<string, string>>(() => {
    try {
      const raw = localStorage.getItem(TEMP_PASSWORDS_STORAGE_KEY);
      if (!raw) return {};
      const parsed = JSON.parse(raw) as Record<string, string>;
      return typeof parsed === "object" && parsed !== null ? parsed : {};
    } catch {
      return {};
    }
  });

  useEffect(() => {
    localStorage.setItem(TEMP_PASSWORDS_STORAGE_KEY, JSON.stringify(passwordByEmail));
  }, [passwordByEmail]);

  useEffect(() => {
    if (user?.role !== "admin") {
      setUsersInfo([]);
      setFetchError("This page is only available to admin users.");
      return;
    }

    fetchUsers();
  }, [tab, user?.role]);

  const fetchUsers = async () => {
    setLoading(true);
    setFetchError(null);
    try {
      const roleQuery = tab.toLowerCase().slice(0, -1); // "student" or "teacher"
      const res = await api.get(`/admin/users/?role=${roleQuery}`);
      const payload = res.data as
        | UserData[]
        | { results?: UserData[]; data?: UserData[] | { results?: UserData[] } };

      const users = Array.isArray(payload)
        ? payload
        : Array.isArray(payload.results)
          ? payload.results
          : Array.isArray(payload.data)
            ? payload.data
            : Array.isArray(payload.data?.results)
              ? payload.data.results
              : [];

      setUsersInfo(users);
    } catch (err) {
      console.error("Error fetching users", err);
      const axiosErr = err as {
        response?: { status?: number; data?: { detail?: string } };
      };

      if (axiosErr.response?.status === 403) {
        setFetchError("You are not allowed to view users. Please sign in with an admin account.");
      } else if (axiosErr.response?.data?.detail) {
        setFetchError(axiosErr.response.data.detail);
      } else {
        setFetchError("Failed to load users. Please check your connection and try again.");
      }

      setUsersInfo([]);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateUser = async () => {
    setCreating(true);
    setCreateError(null);
    try {
      // Basic split for full name
      const full_name = `${formData.first_name} ${formData.last_name}`.trim();
      const normalizedEmail = normalizeEmail(formData.email);
      const payload: CreateUserPayload = {
        email: normalizedEmail,
        role: newRole,
        full_name,
      };

      if (newRole === "student") {
        payload.student_id = formData.roll_number;
      }

      const res = await api.post('/admin/users/', payload);
      const generated = (res.data.generated_password as string | undefined) || null;
      setGeneratedPassword(generated);

      const createdEmail = normalizeEmail((res.data.email as string | undefined) || normalizedEmail);
      if (generated && createdEmail) {
        setPasswordByEmail((prev) => ({ ...prev, [createdEmail]: generated }));
      }

      setDrawerOpen(false);
      setFormData({
        first_name: "", last_name: "", email: "",
        department: "Computer Science", roll_number: "", employee_id: ""
      });
      fetchUsers();
    } catch (err) {
      console.error("Failed to create user", err);
      const detail = typeof err === 'object' && err !== null && 'response' in err
        ? (err as { response?: { data?: { detail?: string; email?: string[]; student_id?: string[] } } }).response?.data
        : undefined;

      if (detail?.email?.length) {
        setCreateError(detail.email[0]);
      } else if (detail?.student_id?.length) {
        setCreateError(detail.student_id[0]);
      } else if (detail?.detail) {
        setCreateError(detail.detail);
      } else {
        setCreateError("Failed to create user. Please check your input.");
      }
    } finally {
      setCreating(false);
    }
  };

  const toggleStatus = async (userId: string, currentStatus: boolean) => {
    try {
      // PUT or PATCH request depending on API. Let's assume PATCH
      await api.patch(`/admin/users/${userId}/`, { is_active: !currentStatus });
      setUsersInfo(usersInfo.map(u => u.id === userId ? { ...u, is_active: !currentStatus } : u));
    } catch (err) {
      // console.error("Failed to update status", err);
    }
  };

  const filtered = usersInfo.filter((s) =>
    s.full_name.toLowerCase().includes(search.toLowerCase()) ||
    s.email.toLowerCase().includes(search.toLowerCase()) ||
    (s.roll_number && s.roll_number.toLowerCase().includes(search.toLowerCase())) ||
    (s.employee_id && s.employee_id.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div className="flex h-screen bg-background overflow-hidden" style={{ fontFamily: "Inter, sans-serif" }}>
      <Sidebar role="admin" />
      <div className="flex-1 flex flex-col overflow-hidden relative">
        <TopNav breadcrumb={["Admin", "User Management"]} userInitials={user?.full_name?.substring(0, 2).toUpperCase() || "A"} />
        <div className="flex-1 overflow-y-auto p-8 space-y-5">

          {createError && (
            <div className="bg-[#FEE2E2] border border-[#FCA5A5] text-[#991B1B] rounded-[8px] px-4 py-3 text-[13px]">
              {createError}
            </div>
          )}

          {fetchError && (
            <div className="bg-[#FEF3C7] border border-[#FCD34D] text-[#92400E] rounded-[8px] px-4 py-3 text-[13px]">
              {fetchError}
            </div>
          )}

          {generatedPassword && (
            <div className="bg-[#DCFCE7] border border-[#86EFAC] text-[#166534] rounded-[8px] px-4 py-3 text-[13px]">
              Generated password for the newly created user: <span className="font-semibold">{generatedPassword}</span>
            </div>
          )}

          {/* Header */}
          <div className="flex items-center justify-between">
            <h1 className="text-[22px] font-bold text-foreground">User Management</h1>
            <button
              onClick={() => setDrawerOpen(true)}
              className="flex items-center gap-2 bg-primary text-primary-foreground rounded-[6px] px-4 h-10 text-[13px] font-medium hover:bg-primary/90 transition-colors"
            >
              <Plus size={15} /> Add New User
            </button>
          </div>

          {/* Tabs */}
          <div className="flex gap-0 border-b border-border">
            {(["Students", "Teachers"] as const).map((t) => (
              <button
                key={t}
                onClick={() => setTab(t)}
                className="px-5 py-2.5 text-[14px] font-medium transition-colors"
                style={{
                  color: tab === t ? "var(--color-primary)" : "var(--color-foreground)",
                  borderBottom: tab === t ? "2px solid var(--color-primary)" : "2px solid transparent",
                }}
              >
                {t}
              </button>
            ))}
          </div>

          {/* Filter bar */}
          <div className="bg-card rounded-[8px] border border-border p-4 flex items-center gap-3">
            <div className="relative flex-1 max-w-xs">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search name, email, roll..."
                className="w-full border border-border rounded-[6px] pl-8 pr-3 py-2 text-[13px] text-foreground outline-none focus:border-primary"
              />
            </div>
            <div className="relative">
              <select className="border border-border rounded-[6px] px-3 py-2 pr-8 text-[13px] text-foreground outline-none appearance-none bg-card">
                <option>All Departments</option>
                <option>CS</option>
                <option>IT</option>
                <option>ME</option>
              </select>
              <ChevronDown size={13} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
            </div>
            <div className="relative">
              <select className="border border-border rounded-[6px] px-3 py-2 pr-8 text-[13px] text-foreground outline-none appearance-none bg-card">
                <option>All Status</option>
                <option>Active</option>
                <option>Inactive</option>
              </select>
              <ChevronDown size={13} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
            </div>
          </div>

          {/* Table */}
          <div className="bg-card rounded-[8px] border border-border shadow-[0_1px_4px_rgba(0,0,0,0.06)] overflow-hidden">
            <table className="w-full">
              <thead>
                <tr style={{ backgroundColor: "var(--secondary)" }}>
                  {["#", "Name", "Email", tab === "Students" ? "Roll No" : "Emp ID", "Department", "Temp Password", "Status", "Actions"].map((h) => (
                    <th key={h} className="text-left text-[11px] font-bold text-primary-foreground uppercase tracking-wide px-4 py-3">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr>
                    <td colSpan={8} className="px-4 py-8 text-center flex items-center justify-center">
                      <Loader2 className="w-6 h-6 animate-spin text-primary" />
                    </td>
                  </tr>
                ) : filtered.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="px-4 py-8 text-center text-muted-foreground">
                      No {tab.toLowerCase()} found.
                    </td>
                  </tr>
                ) : filtered.map((s, idx) => {
                  const isActive = s.is_active ?? true;
                  const tempPassword = passwordByEmail[normalizeEmail(s.email)] || s.generated_password;
                  return (
                    <tr key={s.id} style={{ backgroundColor: idx % 2 === 0 ? "#FFFFFF" : "#F8F9FA" }} className="h-12 hover:bg-[#F0F7FF] transition-colors">
                      <td className="px-4 py-3 text-[13px] text-muted-foreground">{idx + 1}</td>
                      <td className="px-4 py-3 text-[13px] font-medium text-foreground">{s.full_name}</td>
                      <td className="px-4 py-3 text-[13px] text-muted-foreground">{s.email}</td>
                      <td className="px-4 py-3 text-[13px] text-foreground">{tab === "Students" ? s.student_id : "—"}</td>
                      <td className="px-4 py-3 text-[13px] text-foreground">{s.department || "CS"}</td>
                      <td className="px-4 py-3 text-[13px] text-foreground font-medium">{tempPassword || "—"}</td>
                      <td className="px-4 py-3">
                        <Badge variant={isActive ? "active" : "inactive"}>{isActive ? "Active" : "Inactive"}</Badge>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <button className="text-muted-foreground hover:text-foreground transition-colors">
                            <Pencil size={14} />
                          </button>
                          <button
                            onClick={() => toggleStatus(s.id, isActive)}
                            className="text-[12px] font-medium hover:underline transition-colors"
                            style={{ color: isActive ? "var(--color-destructive)" : "var(--color-primary)" }}
                          >
                            {isActive ? "Deactivate" : "Activate"}
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>

            {/* Pagination */}
            <div className="flex items-center justify-between px-4 py-3 border-t border-border">
              <span className="text-[13px] text-muted-foreground">Showing {filtered.length} {tab.toLowerCase()}</span>
              <div className="flex gap-1">
                {[1, 2, 3, "...", 39].map((p, i) => (
                  <button
                    key={i}
                    className="w-8 h-8 rounded-[4px] text-[13px] transition-colors"
                    style={{ backgroundColor: p === 1 ? "var(--color-primary)" : "transparent", color: p === 1 ? "var(--color-primary-foreground)" : "var(--color-foreground)" }}
                  >
                    {p}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Add User Drawer */}
        {drawerOpen && (
          <>
            <div
              className="absolute inset-0 bg-black/50 z-40"
              onClick={() => setDrawerOpen(false)}
            />
            <div className="absolute right-0 top-0 bottom-0 w-[400px] bg-card shadow-[0_0_40px_rgba(0,0,0,0.15)] z-50 flex flex-col">
              <div className="flex items-center justify-between px-6 py-5 border-b border-border">
                <h2 className="text-[18px] font-bold text-foreground">Add New User</h2>
                <button onClick={() => setDrawerOpen(false)} className="text-muted-foreground hover:text-foreground">
                  <X size={20} />
                </button>
              </div>
              <div className="flex-1 overflow-y-auto p-6 space-y-4">
                <div className="flex gap-3">
                  <div className="flex-1">
                    <label className="block text-[12px] font-medium text-muted-foreground uppercase tracking-wide mb-1.5">First Name</label>
                    <input 
                      value={formData.first_name} 
                      onChange={(e) => setFormData({...formData, first_name: e.target.value})} 
                      className="w-full border border-border rounded-[6px] px-3 py-2.5 text-[14px] text-foreground outline-none focus:border-primary" 
                      placeholder="First name" 
                    />
                  </div>
                  <div className="flex-1">
                    <label className="block text-[12px] font-medium text-muted-foreground uppercase tracking-wide mb-1.5">Last Name</label>
                    <input 
                      value={formData.last_name} 
                      onChange={(e) => setFormData({...formData, last_name: e.target.value})} 
                      className="w-full border border-border rounded-[6px] px-3 py-2.5 text-[14px] text-foreground outline-none focus:border-primary" 
                      placeholder="Last name" 
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-[12px] font-medium text-muted-foreground uppercase tracking-wide mb-1.5">Email</label>
                  <input 
                    type="email" 
                    value={formData.email} 
                    onChange={(e) => setFormData({...formData, email: e.target.value})} 
                    className="w-full border border-border rounded-[6px] px-3 py-2.5 text-[14px] text-foreground outline-none focus:border-primary" 
                    placeholder="user@college.edu" 
                  />
                </div>
                <div>
                  <label className="block text-[12px] font-medium text-muted-foreground uppercase tracking-wide mb-2">Role</label>
                  <div className="flex gap-2">
                    {[{ label: "Student", val: "student" }, { label: "Teacher", val: "teacher" }].map((r) => (
                      <button 
                        key={r.val} 
                        onClick={() => setNewRole(r.val as "student" | "teacher")}
                        className={`flex-1 py-2 px-4 rounded-[6px] text-[13px] font-medium border transition-colors ${
                          newRole === r.val 
                            ? "border-primary bg-primary text-primary-foreground" 
                            : "border-border bg-background text-foreground hover:bg-secondary"
                        }`}
                      >
                        {r.label}
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="block text-[12px] font-medium text-muted-foreground uppercase tracking-wide mb-1.5">Department</label>
                  <div className="relative">
                    <select 
                      value={formData.department} 
                      onChange={(e) => setFormData({...formData, department: e.target.value})} 
                      className="w-full border border-border rounded-[6px] px-3 py-2.5 text-[14px] text-foreground outline-none focus:border-primary appearance-none bg-card"
                    >
                      <option>Computer Science</option>
                      <option>Information Technology</option>
                      <option>Mechanical Engineering</option>
                    </select>
                    <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
                  </div>
                </div>
                <div>
                  <label className="block text-[12px] font-medium text-muted-foreground uppercase tracking-wide mb-1.5">
                    {newRole === "student" ? "Roll Number" : "Employee ID"}
                  </label>
                  <input 
                    value={newRole === "student" ? formData.roll_number : formData.employee_id} 
                    onChange={(e) => setFormData(newRole === "student" ? {...formData, roll_number: e.target.value} : {...formData, employee_id: e.target.value})}
                    className="w-full border border-border rounded-[6px] px-3 py-2.5 text-[14px] text-foreground outline-none focus:border-primary" 
                    placeholder={newRole === "student" ? "e.g. CS2350" : "e.g. EMP102"} 
                  />
                </div>
              </div>
              <div className="px-6 py-5 border-t border-border">
                <button 
                  onClick={handleCreateUser}
                  disabled={creating || !formData.email || !formData.first_name}
                  className="w-full flex justify-center items-center bg-primary text-primary-foreground rounded-[6px] h-11 text-[14px] font-medium hover:bg-primary/90 transition-colors disabled:opacity-50">
                  {creating ? <Loader2 className="w-5 h-5 animate-spin" /> : "Create Account"}
                </button>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
