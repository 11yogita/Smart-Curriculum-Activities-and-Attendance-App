import React, { useState, useEffect } from "react";
import { Sidebar } from "../../components/Sidebar";
import { TopNav } from "../../components/TopNav";
import { StatCard } from "../../components/StatCard";
import { useNavigate } from "react-router";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine, Cell,
} from "recharts";
import { Loader2 } from "lucide-react";
import { api } from "../../../lib/api";
import { useAuth } from "../../contexts/AuthContext";

interface AdminDashboardStats {
  total_students: number;
  total_teachers: number;
  total_subjects: number;
  avg_attendance_pct: number;
  below_threshold_count: number;
  pending_leaves_count: number;
}

// Leaving static data for visuals that aren't fully supported by the current backend schema.
const deptData = [
  { dept: "CS", pct: 74.2 },
  { dept: "IT", pct: 79.8 },
  { dept: "ME", pct: 68.5 },
  { dept: "EC", pct: 81.3 },
  { dept: "CE", pct: 72.1 },
  { dept: "EE", pct: 76.4 },
];



export default function AdminDashboard() {
  const navigate = useNavigate();
  const { user } = useAuth();
  
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [stats, setStats] = useState<AdminDashboardStats | null>(null);

  useEffect(() => {
    const fetchDashboard = async () => {
      try {
        setLoading(true);
        const res = await api.get('/admin/dashboard/');
        setStats(res.data);
      } catch (err) {
        // console.error("Failed to fetch admin dashboard stats", err);
        setError("Failed to load dashboard data.");
      } finally {
        setLoading(false);
      }
    };
    fetchDashboard();
  }, []);

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center bg-background">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex h-screen items-center justify-center bg-background">
        <div className="text-destructive font-medium">{error}</div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-background overflow-hidden" style={{ fontFamily: "Inter, sans-serif" }}>
      <Sidebar role="admin" />
      <div className="flex-1 flex flex-col overflow-hidden">
        <TopNav breadcrumb={["Admin", "Dashboard"]} userInitials={user?.full_name?.substring(0, 2).toUpperCase() || "A"} />
        <div className="flex-1 overflow-y-auto p-8 space-y-6">

          {/* Stat cards */}
          <div className="flex gap-4">
            <StatCard label="Total Students" value={stats?.total_students || 0} subLabel="Enrolled" valueColor="var(--color-secondary-foreground)" borderColor="var(--color-secondary)" />
            <StatCard label="Teachers" value={stats?.total_teachers || 0} subLabel="Active faculty" valueColor="var(--color-primary-foreground)" borderColor="var(--color-primary)" />
            <StatCard label="Subjects" value={stats?.total_subjects || 0} subLabel="This semester" valueColor="var(--color-secondary-foreground)" borderColor="var(--color-secondary)" />
            <StatCard label="Avg Attendance" value={`${stats?.avg_attendance_pct || 0}%`} subLabel="Below 75% threshold" valueColor="#D97706" borderColor="#D97706" />
            <StatCard label="Pending Leaves" value={stats?.pending_leaves_count || 0} subLabel="Require action" valueColor="var(--color-destructive)" borderColor="var(--color-destructive)" />
          </div>

          {/* Full-width bar chart */}
          <div className="bg-card rounded-[8px] border border-border shadow-[0_1px_4px_rgba(0,0,0,0.06)] p-5">
            <h3 className="text-[15px] font-semibold text-foreground mb-4">Attendance Distribution by Department</h3>
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={deptData} margin={{ left: -10, right: 20 }}>
                <CartesianGrid stroke="#E5E7EB" strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="dept" tick={{ fontSize: 12, fill: "#6B7280" }} tickLine={false} axisLine={false} />
                <YAxis domain={[50, 100]} tick={{ fontSize: 11, fill: "#6B7280" }} tickLine={false} axisLine={false} />
                <Tooltip
                  formatter={(v: number) => [`${v}%`, "Avg Attendance"]}
                  contentStyle={{ fontSize: 12, border: "1px solid #E5E7EB", borderRadius: 6 }}
                />
                <ReferenceLine y={75} stroke="var(--color-destructive)" strokeDasharray="4 3" strokeWidth={1.5} label={{ value: "75% Min", position: "right", fontSize: 10, fill: "var(--color-destructive)" }} />
                <Bar dataKey="pct" radius={[4, 4, 0, 0]} maxBarSize={48}>
                  {deptData.map((d, i) => (
                    <Cell key={i} fill={d.pct >= 75 ? "var(--color-primary-foreground)" : "var(--color-destructive)"} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}