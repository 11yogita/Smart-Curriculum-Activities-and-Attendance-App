import React, { useState, useEffect } from "react";
import { Sidebar } from "../../components/Sidebar";
import { TopNav } from "../../components/TopNav";
import { StatCard } from "../../components/StatCard";
import { Badge } from "../../components/Badge";
import { useNavigate } from "react-router";
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { api } from "../../../lib/api";
import { useAuth } from "../../contexts/AuthContext";
import { Loader2 } from "lucide-react";

interface TeacherDashboardSummary {
  total_subjects: number;
  total_students: number;
  pending_leaves: number;
  critical_students: number;
}

interface TeacherDashboardSubject {
  subject_id: string;
  subject__name: string;
  subject__code: string;
  total_students: number;
  average_attendance: number;
  safe_students: number;
  warning_students: number;
  critical_students: number;
}

interface PendingLeaveItem {
  id: string;
  student__full_name: string;
  subjects: Array<{ subject_name: string }>;
  leave_type: string;
}

export default function TeacherDashboard() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [approved, setApproved] = useState<string[]>([]);
  const [rejected, setRejected] = useState<string[]>([]);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Data
  const [summary, setSummary] = useState<TeacherDashboardSummary | null>(null);
  const [subjects, setSubjects] = useState<TeacherDashboardSubject[]>([]);
  const [leaves, setLeaves] = useState<PendingLeaveItem[]>([]);

  useEffect(() => {
    const fetchDashboard = async () => {
      try {
        setLoading(true);
        const dashboardRes = await api.get('/teacher/dashboard/');
        setSummary(dashboardRes.data.overall_stats || {});
        setSubjects(dashboardRes.data.subject_stats || []);
        
        // Also fetch pending leaves for quick preview
        const leavesRes = await api.get('/teacher/leaves/?status=pending');
        const pendingLeaves: PendingLeaveItem[] = (leavesRes.data.leaves || []).map((l: {
          id: string;
          student_name: string;
          affected_subjects: Array<{ subject_name: string }>;
          leave_type: string;
        }) => ({
          id: l.id,
          student__full_name: l.student_name,
          subjects: l.affected_subjects || [],
          leave_type: l.leave_type,
        }));
        setLeaves(pendingLeaves.slice(0, 4));
      } catch (err) {
        console.error("Dashboard fetch error:", err);
        setError("Failed to load dashboard data");
      } finally {
        setLoading(false);
      }
    };
    fetchDashboard();
  }, []);

  const handleLeaveAction = async (id: string, action: 'approved' | 'rejected') => {
    try {
      await api.patch(`/teacher/leaves/${id}/`, { action, review_note: '' });
      if (action === 'approved') {
        setApproved([...approved, id]);
      } else {
        setRejected([...rejected, id]);
      }
    } catch (err) {
      console.error(`Failed to ${action} leave`, err);
      // Optional: show a small toast error if failing
    }
  };

  const getPieData = (s: TeacherDashboardSubject) => [
    { name: "Safe (≥75%)", value: s.safe_students, color: "var(--color-primary-foreground)" },
    { name: "Warning (65-75%)", value: s.warning_students, color: "#D97706" },
    { name: "Critical (<65%)", value: s.critical_students, color: "var(--color-destructive)" },
  ];

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center bg-background">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex h-screen items-center justify-center bg-background">
        <div className="text-destructive font-medium">{error}</div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-background overflow-hidden" style={{ fontFamily: "Inter, sans-serif" }}>
      <Sidebar role="teacher" />
      <div className="flex-1 flex flex-col overflow-hidden">
        <TopNav breadcrumb={["Dashboard"]} userInitials={user?.full_name?.substring(0, 2).toUpperCase() || "T"} />
        <div className="flex-1 overflow-y-auto p-8 space-y-6">

          {/* Greeting */}
          <div>
            <h1 className="text-[22px] font-bold text-foreground">Good morning, {user?.full_name?.split(' ')[0] || "Professor"} 👋</h1>
            <p className="text-[14px] text-muted-foreground">Here's an overview of your classes today</p>
          </div>

          {/* Stat cards */}
          <div className="flex gap-5">
            <StatCard label="My Subjects" value={summary?.total_subjects || 0} subLabel="Active this semester" />
            <StatCard label="Total Students" value={summary?.total_students || 0} subLabel="Across all subjects" />
            <StatCard
              label="Pending Approvals"
              value={summary?.pending_leaves || 0}
              subLabel="Action needed"
              valueColor="#D97706"
              borderColor="#D97706"
            />
            <StatCard
              label="Below 75%"
              value={summary?.critical_students || 0}
              subLabel="Students at risk"
              valueColor="#DC2626"
              borderColor="#DC2626"
            />
          </div>

          {/* Main row */}
          <div className="flex gap-5">
            {/* Subject Overview */}
            <div className="flex-1 bg-card rounded-[8px] border border-border shadow-[0_1px_4px_rgba(0,0,0,0.06)] overflow-hidden">
              <div className="px-5 py-4 border-b border-border">
                <h3 className="text-[15px] font-semibold text-foreground">Subject Overview</h3>
              </div>
              <table className="w-full">
                <thead>
                  <tr className="bg-secondary">
                    {["Subject", "Code", "Enrolled", "Avg %", "Below 75%", "Actions"].map((h) => (
                      <th key={h} className="text-left text-[11px] font-bold text-secondary-foreground uppercase tracking-wide px-4 py-3">
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {subjects.map((s, idx) => {
                    const avgStr = s.average_attendance ? parseFloat(s.average_attendance).toFixed(1) : "0.0";
                    const isHighlight = s.critical_students > 10;
                    return (
                      <tr
                        key={s.subject_id}
                        className="h-12 transition-colors"
                        style={{
                          backgroundColor: isHighlight ? "#FFF7ED" : idx % 2 === 0 ? "#FFFFFF" : "#F8F9FA",
                        }}
                      >
                        <td className="px-4 py-3 text-[13px] text-foreground font-medium">{s.subject__name}</td>
                        <td className="px-4 py-3 text-[13px] text-muted-foreground">{s.subject__code}</td>
                        <td className="px-4 py-3 text-[13px] text-foreground">{s.total_students}</td>
                        <td className="px-4 py-3 text-[13px] font-semibold"
                          style={{ color: parseFloat(avgStr) >= 75 ? "var(--color-primary)" : "var(--color-destructive)" }}>
                          {avgStr}%
                        </td>
                        <td className="px-4 py-3 text-[13px] font-semibold"
                          style={{ color: isHighlight ? "var(--color-destructive)" : "#D97706" }}>
                          {s.critical_students}
                        </td>
                        <td className="px-4 py-3">
                          <button
                            onClick={() => navigate(`/teacher/students?subject=${s.subject_id}`)}
                            className="text-[12px] px-3 py-1.5 rounded-[4px] border transition-colors"
                            style={{
                              borderColor: isHighlight ? "#D97706" : "#E5E7EB",
                              color: isHighlight ? "#D97706" : "#374151",
                              backgroundColor: isHighlight ? "#FEF3C7" : "transparent",
                            }}
                          >
                            View
                          </button>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>

            {/* Right side */}
            <div className="w-[420px] flex flex-col gap-4">
              {/* Donut chart - display for first subject if available */}
              {subjects.length > 0 && (
                <div className="bg-card rounded-[8px] border border-border shadow-[0_1px_4px_rgba(0,0,0,0.06)] p-5">
                  <h3 className="text-[14px] font-semibold text-foreground mb-3">Attendance Distribution — {subjects[0].subject__code}</h3>
                  <ResponsiveContainer width="100%" height={170}>
                    <PieChart>
                      <Pie data={getPieData(subjects[0])} cx="50%" cy="50%" innerRadius={50} outerRadius={75} dataKey="value" paddingAngle={2}>
                        {getPieData(subjects[0]).map((entry, index) => (
                          <Cell key={index} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(v: number) => [`${v} Students`, ""]} contentStyle={{ fontSize: 12, border: "1px solid #E5E7EB", borderRadius: 6 }} />
                      <Legend wrapperStyle={{ fontSize: 11 }} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              )}

              {/* Pending leaves */}
              <div className="bg-card rounded-[8px] border border-border shadow-[0_1px_4px_rgba(0,0,0,0.06)] p-5">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-[14px] font-semibold text-foreground">Pending Leaves</h3>
                  <button onClick={() => navigate("/teacher/leaves")} className="text-[12px] text-primary hover:underline">
                    View all →
                  </button>
                </div>
                <div className="space-y-3">
                  {leaves.length === 0 ? (
                     <div className="text-[13px] text-muted-foreground text-center py-4">No pending leaves.</div>
                  ) : leaves.map((l) => {
                    const isApproved = approved.includes(l.id);
                    const isRejected = rejected.includes(l.id);
                    return (
                      <div key={l.id} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                        <div>
                          <div className="text-[13px] font-medium text-foreground">{l.student__full_name}</div>
                          <div className="text-[11px] text-muted-foreground">{l.subjects.length > 0 ? l.subjects[0].subject_name : "Multiple"} · {l.leave_type.charAt(0).toUpperCase() + l.leave_type.slice(1)}</div>
                        </div>
                        {isApproved ? (
                          <Badge variant="approved">Approved</Badge>
                        ) : isRejected ? (
                          <Badge variant="rejected">Rejected</Badge>
                        ) : (
                          <div className="flex gap-1.5">
                            <button
                              onClick={() => handleLeaveAction(l.id, 'approved')}
                              className="text-[11px] px-2.5 py-1 rounded-[4px] border border-primary text-primary hover:bg-primary/10 transition-colors"
                            >
                              ✓
                            </button>
                            <button
                              onClick={() => handleLeaveAction(l.id, 'rejected')}
                              className="text-[11px] px-2.5 py-1 rounded-[4px] border border-destructive text-destructive hover:bg-destructive/10 transition-colors"
                            >
                              ✗
                            </button>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}