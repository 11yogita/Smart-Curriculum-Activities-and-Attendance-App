import React, { useState, useEffect } from "react";
import { Sidebar } from "../../components/Sidebar";
import { TopNav } from "../../components/TopNav";
import { Badge } from "../../components/Badge";
import { ChevronDown, ChevronRight, X, Loader2 } from "lucide-react";
import { api } from "../../../lib/api";
import { format } from "date-fns";
import { useAuth } from "../../contexts/AuthContext";

interface LeaveRequestData {
  id: string; // The backend uses UUID strings for the `id` field
  student: string;
  roll: string;
  subject: string;
  type: string;
  from: string;
  to: string;
  days: number;
  predictedPct: number;
  reason: string;
  status: string;
  note?: string;
  submitted?: string;
  proofFileUrl?: string | null;
  proofFileName?: string | null;
}

interface LeaveApiSubject {
  subject_name: string;
  predicted_pct: number;
}

interface LeaveApiItem {
  id: string;
  student_name: string | null;
  student_id: string | null;
  leave_type: string;
  from_date: string;
  to_date: string;
  reason: string;
  status: string;
  review_note?: string;
  affected_subjects?: LeaveApiSubject[];
  proof_file?: string | null;
  proof_file_name?: string | null;
}

interface LeaveModalProps {
  leave: LeaveRequestData;
  onClose: () => void;
  onDecide: (id: string, decision: "approved" | "rejected", note: string) => void;
}

function LeaveModal({ leave, onClose, onDecide }: LeaveModalProps) {
  const [decision, setDecision] = useState<"approved" | "rejected">("approved");
  const [note, setNote] = useState("");

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center" style={{ backgroundColor: "rgba(0,0,0,0.4)" }}>
      <div className="bg-card rounded-[12px] shadow-[0_16px_48px_rgba(0,0,0,0.16)] w-[520px] max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="px-8 pt-8 pb-5 border-b border-border">
          <div className="flex items-center justify-between">
            <h2 className="text-[20px] font-bold text-foreground">Review Leave Request</h2>
            <button onClick={onClose} className="text-muted-foreground hover:text-foreground transition-colors">
              <X size={20} />
            </button>
          </div>
        </div>

        <div className="px-8 py-6 space-y-5">
          {/* Student info */}
          <div className="bg-background rounded-[8px] p-4">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary text-[14px] font-bold">
                {leave.student.split(" ").map(n => n[0]).join("")}
              </div>
              <div>
                <div className="text-[14px] font-semibold text-foreground">{leave.student}</div>
                <div className="text-[12px] text-muted-foreground">{leave.roll}</div>
              </div>
            </div>
            <div className="flex gap-2 flex-wrap">
              {[`${leave.type} Leave`, `${leave.from} – ${leave.to}`, `${leave.days} days`].map((tag) => (
                <span key={tag} className="bg-muted text-foreground text-[12px] rounded-full px-3 py-1">{tag}</span>
              ))}
            </div>
          </div>

          {/* Attendance impact */}
          <div>
            <h3 className="text-[13px] font-semibold text-foreground uppercase tracking-wide mb-2">Attendance Impact</h3>
            <table className="w-full">
              <thead>
                <tr style={{ backgroundColor: "var(--secondary)" }}>
                  {["Subject", "Current %", "After Leave", "Status"].map((h) => (
                    <th key={h} className="text-left text-[11px] font-bold text-primary-foreground uppercase tracking-wide px-3 py-2">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                <tr className="bg-[#FEE2E2]">
                  <td className="px-3 py-2.5 text-[13px] text-foreground">{leave.subject}</td>
                  <td className="px-3 py-2.5 text-[13px] text-[#D97706] font-medium">71.4%</td>
                  <td className="px-3 py-2.5 text-[13px] font-medium text-destructive">{leave.predictedPct}%</td>
                  <td className="px-3 py-2.5 text-[12px] text-destructive">⛔ Below Threshold</td>
                </tr>
                <tr className="bg-[#F0FDF4]">
                  <td className="px-3 py-2.5 text-[13px] text-foreground">CS301</td>
                  <td className="px-3 py-2.5 text-[13px] text-[#D97706] font-medium">88.9%</td>
                  <td className="px-3 py-2.5 text-[13px] font-medium text-[#16A34A]">82.1%</td>
                  <td className="px-3 py-2.5 text-[12px] text-[#16A34A]">✅ Safe</td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Reason */}
          <div>
            <h3 className="text-[13px] font-semibold text-foreground uppercase tracking-wide mb-2">Leave Reason</h3>
            <div className="bg-background rounded-[6px] px-4 py-3 text-[14px] text-foreground">
              {leave.reason}
            </div>
          </div>

          {leave.proofFileUrl && (
            <div>
              <h3 className="text-[13px] font-semibold text-foreground uppercase tracking-wide mb-2">Proof Document</h3>
              <a
                href={leave.proofFileUrl}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 text-[13px] text-primary hover:underline"
              >
                View Proof
                <span className="text-muted-foreground">{leave.proofFileName}</span>
              </a>
            </div>
          )}

          {/* Decision cards */}
          <div>
            <h3 className="text-[13px] font-semibold text-foreground uppercase tracking-wide mb-3">Decision</h3>
            <div className="flex gap-3">
              <button
                onClick={() => setDecision("approved")}
                className="flex-1 p-4 rounded-[8px] border-2 transition-all text-left"
                style={{
                  borderColor: decision === "approved" ? "#16A34A" : "#E5E7EB",
                  backgroundColor: decision === "approved" ? "#F0FDF4" : "transparent",
                }}
              >
                <div className="w-8 h-8 rounded-full bg-[#DCFCE7] flex items-center justify-center mb-2">
                  <span className="text-[#16A34A] text-[16px]">✓</span>
                </div>
                <div className="text-[14px] font-semibold text-[#16A34A]">Approve Leave</div>
              </button>
              <button
                onClick={() => setDecision("rejected")}
                className="flex-1 p-4 rounded-[8px] border-2 transition-all text-left"
                style={{
                  borderColor: decision === "rejected" ? "#DC2626" : "#E5E7EB",
                  backgroundColor: decision === "rejected" ? "#FEE2E2" : "transparent",
                }}
              >
                <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center mb-2">
                  <span className="text-muted-foreground text-[16px]">✗</span>
                </div>
                <div className="text-[14px] font-semibold text-foreground">Reject Leave</div>
                <div className="text-[12px] text-muted-foreground">A note is required.</div>
              </button>
            </div>
          </div>

          {/* Rejection note */}
          {decision === "rejected" && (
            <div>
              <label className="block text-[12px] font-semibold text-destructive uppercase tracking-wide mb-2">
                Reason for Rejection *
              </label>
              <textarea
                rows={3}
                value={note}
                onChange={(e) => setNote(e.target.value.slice(0, 500))}
                placeholder="Explain why this leave is being rejected..."
                className="w-full border-2 border-[#DC2626] rounded-[6px] px-3 py-2.5 text-[14px] text-foreground outline-none resize-none"
              />
              <div className="flex justify-end mt-1">
                <span className="text-[11px] text-muted-foreground">{note.length}/500</span>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-8 pb-8 flex gap-3">
          <button
            onClick={onClose}
            className="flex-1 border border-border text-foreground rounded-[6px] h-11 text-[14px] font-medium hover:bg-background transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={() => { onDecide(leave.id, decision, note); onClose(); }}
            className="flex-1 text-primary-foreground rounded-[6px] h-11 text-[14px] font-medium transition-colors"
            style={{ backgroundColor: decision === "approved" ? "#16A34A" : "#DC2626" }}
            disabled={decision === "rejected" && !note}
          >
            Submit Decision
          </button>
        </div>
      </div>
    </div>
  );
}

export default function LeaveApprovals() {
  const { user } = useAuth();
  
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [leaveRequests, setLeaveRequests] = useState<LeaveRequestData[]>([]);
  const [reviewed, setReviewed] = useState<LeaveRequestData[]>([]);

  const [statuses, setStatuses] = useState<Record<string, "approved" | "rejected">>({});
  const [reviewedOpen, setReviewedOpen] = useState(false);
  const [activeModal, setActiveModal] = useState<LeaveRequestData | null>(null);

  // Fetch all leaves, then categorize into pending and reviewed
  useEffect(() => {
    const fetchLeaves = async () => {
      try {
        setLoading(true);
        // The endpoint /teacher/leaves/ will return all leaves associated with the teacher's subjects
        const res = await api.get('/teacher/leaves/');
        
        const formatLeave = (l: LeaveApiItem): LeaveRequestData => ({
          id: l.id,
          student: l.student_name || "Unknown",
          roll: l.student_id || "—",
          subject: l.affected_subjects?.length > 0 ? l.affected_subjects[0].subject_name : "Multiple",
          type: l.leave_type.charAt(0).toUpperCase() + l.leave_type.slice(1),
          from: format(new Date(l.from_date), 'MMM d'),
          to: format(new Date(l.to_date), 'MMM d'),
          days: Math.ceil((new Date(l.to_date).getTime() - new Date(l.from_date).getTime()) / (1000 * 3600 * 24)) + 1,
          predictedPct: l.affected_subjects?.length > 0 ? l.affected_subjects[0].predicted_pct : 0.0,
          reason: l.reason,
          status: l.status,
          note: l.review_note || "—",
          proofFileUrl: l.proof_file || null,
          proofFileName: l.proof_file_name || null,
        });

        const allLeaves: LeaveApiItem[] = res.data.leaves || [];
        const pending = allLeaves.filter((l) => l.status === "pending").map(formatLeave);
        const resolved = allLeaves.filter((l) => l.status !== "pending").map(formatLeave);
        
        setLeaveRequests(pending);
        setReviewed(resolved);
      } catch (err) {
        console.error("Failed to fetch leaves", err);
        setError("Failed to load leave requests");
      } finally {
        setLoading(false);
      }
    };
    fetchLeaves();
  }, []);

  const handleDecide = async (id: string, decision: "approved" | "rejected", note: string) => {
    try {
      // Optimistically update UI state
      setStatuses((prev) => ({ ...prev, [id]: decision }));
      
      await api.patch(`/teacher/leaves/${id}/`, {
        action: decision,
        review_note: note
      });
      
      // Move from pending to reviewed array
      const request = leaveRequests.find(l => l.id === id);
      if (request) {
        setLeaveRequests(prev => prev.filter(l => l.id !== id));
        setReviewed(prev => [{...request, status: decision, note}, ...prev]);
      }
    } catch (err) {
      console.error("Failed to approve/reject leave", err);
      // Revert optimistic update
      setStatuses((prev) => {
        const newStatuses = { ...prev };
        delete newStatuses[id];
        return newStatuses;
      });
    }
  };

  return (
    <div className="flex h-screen bg-background overflow-hidden" style={{ fontFamily: "Inter, sans-serif" }}>
      <Sidebar role="teacher" />
      <div className="flex-1 flex flex-col overflow-hidden">
        <TopNav breadcrumb={["Leave Approvals"]} userInitials={user?.full_name?.substring(0, 2).toUpperCase() || "T"} />
        <div className="flex-1 overflow-y-auto p-8 space-y-5">

          {/* Title */}
          <div className="flex items-center gap-3">
            <h1 className="text-[22px] font-bold text-foreground">Leave Approval Queue</h1>
            <span className="bg-[#FEF3C7] text-[#D97706] text-[12px] font-bold px-3 py-1 rounded-full">
              {leaveRequests.length} Pending
            </span>
          </div>

          {/* Table */}
          <div className="bg-card rounded-[8px] border border-border shadow-[0_1px_4px_rgba(0,0,0,0.06)] overflow-hidden">
            {loading ? (
              <div className="p-8 flex justify-center items-center">
                 <Loader2 className="w-8 h-8 animate-spin text-primary" />
              </div>
            ) : error ? (
              <div className="p-8 text-center text-destructive">{error}</div>
            ) : leaveRequests.length === 0 ? (
              <div className="p-8 text-center text-muted-foreground">No pending leave requests.</div>
            ) : (
            <table className="w-full">
              <thead>
                <tr style={{ backgroundColor: "var(--secondary)" }}>
                  {["Student", "Subject", "Type", "Date Range", "Days", "Predicted %", "Reason", "Status", "Actions"].map((h) => (
                    <th key={h} className="text-left text-[11px] font-bold text-primary-foreground uppercase tracking-wide px-4 py-3 whitespace-nowrap">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {leaveRequests.map((l, idx) => {
                  const decided = statuses[l.id];
                  return (
                    <tr key={l.id} style={{ backgroundColor: idx % 2 === 0 ? "#FFFFFF" : "#F8F9FA" }} className="h-12 hover:bg-[#F0F7FF] transition-colors">
                      <td className="px-4 py-3">
                        <div className="text-[13px] font-medium text-foreground">{l.student}</div>
                        <div className="text-[11px] text-muted-foreground">{l.roll}</div>
                      </td>
                      <td className="px-4 py-3 text-[13px] text-foreground">{l.subject}</td>
                      <td className="px-4 py-3 text-[13px] text-foreground">{l.type}</td>
                      <td className="px-4 py-3 text-[13px] text-foreground whitespace-nowrap">{l.from} – {l.to}</td>
                      <td className="px-4 py-3 text-[13px] text-foreground">{l.days}d</td>
                      <td className="px-4 py-3 text-[13px] font-semibold text-muted-foreground">
                        —
                      </td>
                      <td className="px-4 py-3 text-[13px] text-foreground max-w-[140px] truncate" title={l.reason}>{l.reason}</td>
                      <td className="px-4 py-3">
                        {decided ? (
                          <Badge variant={decided}>{decided}</Badge>
                        ) : (
                          <Badge variant="pending">Pending</Badge>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        {!decided ? (
                          <div className="flex gap-1.5">
                            <button
                              onClick={() => handleDecide(l.id, "approved", "")}
                              className="text-[11px] px-2.5 py-1 rounded-[4px] border border-[#16A34A] text-[#16A34A] hover:bg-[#DCFCE7] transition-colors font-medium"
                            >
                              ✓ Approve
                            </button>
                            <button
                              onClick={() => setActiveModal(l)}
                              className="text-[11px] px-2.5 py-1 rounded-[4px] border border-[#DC2626] text-destructive hover:bg-[#FEE2E2] transition-colors font-medium"
                            >
                              ✗ Reject
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => setActiveModal(l)}
                            className="text-[12px] text-primary hover:underline"
                          >
                            Review
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            )}

            {/* Reviewed section */}
            <div className="border-t border-border">
              <button
                onClick={() => setReviewedOpen(!reviewedOpen)}
                className="w-full flex items-center gap-2 px-4 py-3 text-[13px] text-muted-foreground hover:bg-background transition-colors"
              >
                {reviewedOpen ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
                Reviewed · {reviewed.length} entries
              </button>
              {reviewedOpen && reviewed.map((l, idx) => (
                <div key={l.id} className="flex items-center gap-4 px-4 py-3 border-t border-border opacity-60"
                  style={{ backgroundColor: idx % 2 === 0 ? "#FFFFFF" : "#F8F9FA" }}>
                  <span className="text-[13px] text-foreground w-36">{l.student}</span>
                  <span className="text-[13px] text-muted-foreground w-16">{l.subject}</span>
                  <span className="text-[13px] text-muted-foreground flex-1">{l.from} – {l.to}</span>
                  <Badge variant={l.status === "auto_approved" ? "auto-approved" : (l.status as "approved" | "rejected")}>{l.status === "auto_approved" ? "auto-approved" : l.status}</Badge>
                  <span className="text-[12px] text-muted-foreground flex-1 truncate">{l.note}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Modal */}
      {activeModal && (
        <LeaveModal
          leave={activeModal}
          onClose={() => setActiveModal(null)}
          onDecide={handleDecide}
        />
      )}
    </div>
  );
}
