import React, { useState, useEffect, useMemo } from "react";
import { Sidebar } from "../../components/Sidebar";
import { TopNav } from "../../components/TopNav";
import { Badge } from "../../components/Badge";
import { Search, ChevronDown, Download, ArrowUp, Loader2 } from "lucide-react";
import { api } from "../../../lib/api";
import { useAuth } from "../../contexts/AuthContext";

interface StudentReportData {
  no: number;
  id: string;
  name: string;
  roll: string;
  attended: number;
  conducted: number;
  pct: number;
  status: "safe" | "warning" | "critical";
}

interface TeacherSubjectOption {
  subject_id: string;
  subject_name: string;
  subject_code: string;
}

interface TeacherAttendanceRow {
  student_id: string;
  student_name: string;
  student_roll: string | null;
  attended: number;
  total: number;
  percentage: number;
}

export default function StudentReports() {
  const { user } = useAuth();
  
  const [search, setSearch] = useState("");
  const [subjectId, setSubjectId] = useState("");
  const [statusFilter, setStatusFilter] = useState("All Attendance");

  const [subjects, setSubjects] = useState<TeacherSubjectOption[]>([]);
  const [studentsData, setStudentsData] = useState<StudentReportData[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // 1. Fetch available subjects for the dropdown
    const fetchSubjects = async () => {
      try {
        const res = await api.get('/teacher/subjects/');
        const subjectList = res.data.subjects || [];
        setSubjects(subjectList);
        if (subjectList.length > 0) {
          setSubjectId(subjectList[0].subject_id);
        } else {
          setLoading(false);
          setStudentsData([]);
        }
      } catch (err) {
        console.error("Failed to load subjects", err);
        setError("Failed to load subjects");
        setLoading(false);
      }
    };
    fetchSubjects();
  }, []);

  useEffect(() => {
    const fetchStudentsForSubject = async () => {
      if (!subjectId) return;
      try {
        setLoading(true);
        setError(null);
        const res = await api.get(`/teacher/attendance/?subject_id=${subjectId}`);
        const rows: StudentReportData[] = (res.data.students || []).map((s: TeacherAttendanceRow, index: number) => ({
          no: index + 1,
          id: s.student_id,
          name: s.student_name,
          roll: s.student_roll || "—",
          attended: s.attended,
          conducted: s.total,
          pct: parseFloat(s.percentage || 0),
          status: parseFloat(s.percentage || 0) >= 75 ? "safe" : parseFloat(s.percentage || 0) >= 65 ? "warning" : "critical",
        }));
        setStudentsData(rows);
      } catch (err) {
        console.error("Failed to fetch student reports", err);
        setError("Failed to load student reports for this subject.");
        setStudentsData([]);
      } finally {
        setLoading(false);
      }
    };

    fetchStudentsForSubject();
  }, [subjectId]);

  const filtered = useMemo(() => {
    return studentsData.filter((s) => {
      const matchSearch = s.name.toLowerCase().includes(search.toLowerCase()) || s.roll.toLowerCase().includes(search.toLowerCase());
      
      let matchStatus = true;
      if (statusFilter === "Below 75%") matchStatus = s.pct < 75;
      else if (statusFilter === "75%–85%") matchStatus = s.pct >= 75 && s.pct <= 85;
      else if (statusFilter === "Above 85%") matchStatus = s.pct > 85;

      return matchSearch && matchStatus;
    });
  }, [studentsData, search, statusFilter]);

  // Derived Stats based on filtered data OR all subject data
  const stats = useMemo(() => {
    if (studentsData.length === 0) return { total: 0, avg: 0, below: 0, safe: 0 };
    const total = studentsData.length;
    const avg = studentsData.reduce((acc, curr) => acc + curr.pct, 0) / total;
    const below = studentsData.filter(s => s.pct < 75).length;
    const safe = studentsData.filter(s => s.pct >= 75).length;
    return { total, avg: avg.toFixed(1), below, safe };
  }, [studentsData]);

  return (
    <div className="flex h-screen bg-background overflow-hidden" style={{ fontFamily: "Inter, sans-serif" }}>
      <Sidebar role="teacher" />
      <div className="flex-1 flex flex-col overflow-hidden">
        <TopNav breadcrumb={["Student Reports"]} userInitials={user?.full_name?.substring(0, 2).toUpperCase() || "T"} />
        <div className="flex-1 overflow-y-auto p-8 space-y-5">

          {/* Filter bar */}
          <div className="bg-card rounded-[8px] border border-border p-4 flex items-center gap-3">
            <div className="relative">
              <select
                value={subjectId}
                onChange={(e) => setSubjectId(e.target.value)}
                className="border border-border rounded-[6px] px-3 py-2 pr-8 text-[13px] text-foreground outline-none focus:border-primary appearance-none bg-card max-w-[200px] truncate"
              >
                {subjects.map(s => (
                  <option key={s.subject_id} value={s.subject_id}>
                    {s.subject_name} — {s.subject_code}
                  </option>
                ))}
              </select>
              <ChevronDown size={13} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
            </div>
            <div className="relative">
              <select 
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="border border-border rounded-[6px] px-3 py-2 pr-8 text-[13px] text-foreground outline-none focus:border-primary appearance-none bg-card">
                <option>All Attendance</option>
                <option>Below 75%</option>
                <option>75%–85%</option>
                <option>Above 85%</option>
              </select>
              <ChevronDown size={13} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
            </div>
            <div className="relative flex-1 max-w-xs">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search student..."
                className="w-full border border-border rounded-[6px] pl-8 pr-3 py-2 text-[13px] text-foreground outline-none focus:border-primary"
              />
            </div>
            <button className="ml-auto flex items-center gap-2 border border-border rounded-[6px] px-4 py-2 text-[13px] text-foreground hover:bg-background transition-colors">
              <Download size={14} />
              Export CSV
            </button>
          </div>

          {/* Summary bar */}
          <div className="bg-card rounded-[8px] border border-border shadow-[0_1px_4px_rgba(0,0,0,0.06)] p-4 flex items-center divide-x divide-border">
            <div className="pr-8">
              <div className="text-[11px] text-muted-foreground uppercase tracking-wide mb-1">Total Students</div>
              <div className="text-[22px] font-bold text-foreground">{stats.total}</div>
            </div>
            <div className="px-8">
              <div className="text-[11px] text-muted-foreground uppercase tracking-wide mb-1">Class Avg</div>
              <div className="text-[22px] font-bold text-[#D97706]">{stats.avg}%</div>
            </div>
            <div className="px-8">
              <div className="text-[11px] text-muted-foreground uppercase tracking-wide mb-1">Below 75%</div>
              <div className="text-[22px] font-bold text-destructive">{stats.below}</div>
            </div>
            <div className="pl-8">
              <div className="text-[11px] text-muted-foreground uppercase tracking-wide mb-1">Safe (≥75%)</div>
              <div className="text-[22px] font-bold text-[#16A34A]">{stats.safe}</div>
            </div>
          </div>

          {/* Table */}
          <div className="bg-card rounded-[8px] border border-border shadow-[0_1px_4px_rgba(0,0,0,0.06)] overflow-hidden">
            {loading ? (
              <div className="p-8 flex justify-center items-center">
                 <Loader2 className="w-8 h-8 animate-spin text-primary" />
              </div>
            ) : error ? (
              <div className="p-8 text-center text-destructive">{error}</div>
            ) : filtered.length === 0 ? (
              <div className="p-8 text-center text-muted-foreground">No students found for this filter.</div>
            ) : (
            <>
            <table className="w-full">
              <thead>
                <tr style={{ backgroundColor: "var(--secondary)" }}>
                  {["#", "Student Name", "Roll No", "Attended", "Conducted", "Attendance %", "Status", "Actions"].map((h, i) => (
                    <th key={h} className="text-left text-[11px] font-bold text-primary-foreground uppercase tracking-wide px-4 py-3">
                      <div className="flex items-center gap-1">
                        {h}
                        {h === "Attendance %" && <ArrowUp size={11} className="opacity-70" />}
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map((s, idx) => (
                  <tr key={s.id} style={{ backgroundColor: idx % 2 === 0 ? "#FFFFFF" : "#F8F9FA" }} className="h-12 hover:bg-[#F0F7FF] transition-colors">
                    <td className="px-4 py-3 text-[13px] text-muted-foreground">{s.no}</td>
                    <td className="px-4 py-3 text-[13px] font-medium text-foreground">{s.name}</td>
                    <td className="px-4 py-3 text-[13px] text-muted-foreground">{s.roll}</td>
                    <td className="px-4 py-3 text-[13px] text-foreground">{s.attended}</td>
                    <td className="px-4 py-3 text-[13px] text-foreground">{s.conducted}</td>
                    <td className="px-4 py-3 text-[13px] font-semibold"
                      style={{ color: s.pct >= 80 ? "#16A34A" : s.pct >= 75 ? "#D97706" : "#DC2626" }}>
                      {s.pct}%
                    </td>
                    <td className="px-4 py-3">
                      <Badge variant={s.status}>{s.status}</Badge>
                    </td>
                    <td className="px-4 py-3">
                      <button className="text-[12px] text-primary hover:underline">View Profile →</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            {/* Pagination */}
            <div className="flex items-center justify-between px-4 py-3 border-t border-border">
              <span className="text-[13px] text-muted-foreground">Showing {filtered.length} students</span>
              <div className="flex gap-1">
                {[1].map((p) => (
                  <button
                    key={p}
                    className="w-8 h-8 rounded-[4px] text-[13px] transition-colors"
                    style={{ backgroundColor: p === 1 ? "var(--color-primary)" : "transparent", color: p === 1 ? "var(--color-primary-foreground)" : "var(--color-foreground)" }}
                  >
                    {p}
                  </button>
                ))}
              </div>
            </div>
            </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
