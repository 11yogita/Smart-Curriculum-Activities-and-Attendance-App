import React, { useState, useEffect } from "react";
import { Sidebar } from "../../components/Sidebar";
import { TopNav } from "../../components/TopNav";
import { Badge } from "../../components/Badge";
import { StatCard } from "../../components/StatCard";
import { Search, ChevronDown, Loader2 } from "lucide-react";
import { api } from "../../../lib/api";
import { format } from "date-fns";

interface LeaveHistoryItem {
  id: string;
  type: string;
  from: string;
  to: string;
  subjects: string[];
  status: string;
  note: string;
  submitted: string;
}

interface LeaveApiItem {
  id: string;
  leave_type: string;
  from_date: string;
  to_date: string;
  affected_subjects?: Array<{ subject_name: string }>;
  status: string;
  review_note?: string;
  created_at: string;
}

const statusVariantMap: Record<string, "auto-approved" | "approved" | "pending" | "rejected"> = {
  "auto-approved": "auto-approved",
  approved: "approved",
  pending: "pending",
  rejected: "rejected",
};

const statusLabels: Record<string, string> = {
  "auto-approved": "Auto-Approved",
  approved: "Approved",
  pending: "Pending",
  rejected: "Rejected",
};

export default function LeaveHistory() {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");
  
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [leaveData, setLeaveData] = useState<LeaveHistoryItem[]>([]);
  const [stats, setStats] = useState({ total: 0, auto: 0, pending: 0, rejected: 0 });

  useEffect(() => {
    const fetchHistory = async () => {
      try {
        setLoading(true);
        const res = await api.get('/student/leave/');
        const formattedData: LeaveHistoryItem[] = (res.data.leaves || []).map((l: LeaveApiItem) => ({
           id: l.id, // backend sends UUID, we'll slice it for display
           type: l.leave_type.charAt(0).toUpperCase() + l.leave_type.slice(1),
           from: format(new Date(l.from_date), 'MMM d'),
           to: format(new Date(l.to_date), 'MMM d'),
           subjects: (l.affected_subjects || []).map((s) => s.subject_name),
           status: l.status,
           note: l.review_note || "—",
           submitted: format(new Date(l.created_at), 'MMM d, yyyy')
        }));
        setLeaveData(formattedData);
        
        // Calculate stats
        setStats({
          total: formattedData.length,
          auto: formattedData.filter((l) => l.status === 'auto-approved').length,
          pending: formattedData.filter((l) => l.status === 'pending').length,
          rejected: formattedData.filter((l) => l.status === 'rejected').length,
        });

      } catch (err) {
        console.error("Failed to load leave history", err);
        setError("Failed to load leave history");
      } finally {
        setLoading(false);
      }
    };
    fetchHistory();
  }, []);

  const filtered = leaveData.filter((l) => {
    const matchesSearch = l.id.toLowerCase().includes(search.toLowerCase()) || l.type.toLowerCase().includes(search.toLowerCase());
    const normalizedStatus = statusFilter.toLowerCase().replace(/\s+/g, "-");
    const matchesStatus = statusFilter === "All" || l.status === normalizedStatus;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="flex h-screen bg-background overflow-hidden" style={{ fontFamily: "Inter, sans-serif" }}>
      <Sidebar role="student" />
      <div className="flex-1 flex flex-col overflow-hidden">
        <TopNav breadcrumb={["Leave History"]} userInitials="RS" />
        <div className="flex-1 overflow-y-auto p-8 space-y-5">

          {/* Stat cards */}
          <div className="flex gap-4">
            <StatCard label="Total Leaves" value={stats.total} subLabel="This academic year" />
            <StatCard label="Auto-Approved" value={stats.auto} subLabel="No action needed" valueColor="#16A34A" borderColor="#16A34A" />
            <StatCard label="Pending" value={stats.pending} subLabel="Awaiting review" valueColor="#D97706" borderColor="#D97706" />
            <StatCard label="Rejected" value={stats.rejected} subLabel="By teacher" valueColor="#DC2626" borderColor="#DC2626" />
          </div>

          {/* Filter bar */}
          <div className="bg-card rounded-[8px] border border-border p-4 flex items-center gap-3">
            <div className="relative flex-1 max-w-xs">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search leave ID or type..."
                className="w-full border border-border rounded-[6px] pl-8 pr-3 py-2 text-[13px] text-foreground outline-none focus:border-primary"
              />
            </div>
            <div className="relative">
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="border border-border rounded-[6px] px-3 py-2 pr-8 text-[13px] text-foreground outline-none focus:border-primary appearance-none bg-card"
              >
                {["All", "Auto-Approved", "Approved", "Pending", "Rejected"].map((s) => (
                  <option key={s}>{s}</option>
                ))}
              </select>
              <ChevronDown size={13} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
            </div>
          </div>

          {/* Table */}
          <div className="bg-card rounded-[8px] border border-border shadow-[0_1px_4px_rgba(0,0,0,0.06)] overflow-hidden">
            {loading ? (
               <div className="p-8 flex justify-center items-center">
                 <Loader2 className="w-8 h-8 animate-spin text-primary" />
               </div>
            ) : error ? (
               <div className="p-8 text-center text-destructive">{error}</div>
            ) : leaveData.length === 0 ? (
               <div className="p-8 text-center text-muted-foreground">No leave history found.</div>
            ) : (
             <>
              <table className="w-full">
              <thead>
                <tr style={{ backgroundColor: "var(--secondary)" }}>
                  {["Leave ID", "Type", "Date Range", "Subjects", "Status", "Teacher Note", "Submitted", ""].map((h) => (
                    <th key={h} className="text-left text-[11px] font-bold text-primary-foreground uppercase tracking-wide px-4 py-3">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map((l, idx) => (
                  <tr key={l.id} style={{ backgroundColor: idx % 2 === 0 ? "#FFFFFF" : "#F8F9FA" }} className="h-12 hover:bg-primary/10 transition-colors">
                    <td className="px-4 py-3 text-[13px] font-medium text-foreground" title={l.id}>{l.id.substring(0, 8)}...</td>
                    <td className="px-4 py-3 text-[13px] text-foreground">{l.type}</td>
                    <td className="px-4 py-3 text-[13px] text-foreground">{l.from} – {l.to}</td>
                    <td className="px-4 py-3">
                      <div className="flex gap-1 flex-wrap">
                        {l.subjects.map((s) => (
                          <span key={s} className="bg-primary-foreground text-primary text-[11px] font-medium rounded px-2 py-0.5">{s}</span>
                        ))}
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <Badge variant={statusVariantMap[l.status]}>{statusLabels[l.status]}</Badge>
                    </td>
                    <td className="px-4 py-3 text-[13px] text-muted-foreground max-w-[180px] truncate">{l.note}</td>
                    <td className="px-4 py-3 text-[13px] text-muted-foreground">{l.submitted}</td>
                    <td className="px-4 py-3">
                      <button className="text-[13px] text-primary hover:underline whitespace-nowrap">View Details →</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            {/* Pagination */}
            <div className="flex items-center justify-between px-4 py-3 border-t border-border">
              <span className="text-[13px] text-muted-foreground">Showing {filtered.length} of {leaveData.length} entries</span>
              <div className="flex gap-1">
                {[1, 2, 3].map((p) => (
                  <button
                    key={p}
                    className="w-8 h-8 rounded-[4px] text-[13px] transition-colors"
                    style={{ backgroundColor: p === 1 ? "var(--color-primary)" : "transparent", color: p === 1 ? "var(--color-primary-foreground)" : "var(--color-foreground)" }}
                  >
                    {p}
                  </button>
                ))}
              </div>
            </div>
            </>
           )}
          </div>
        </div>
      </div>
    </div>
  );
}
