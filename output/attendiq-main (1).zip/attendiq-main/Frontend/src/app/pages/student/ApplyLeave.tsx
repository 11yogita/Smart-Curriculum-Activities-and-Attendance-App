import React, { useState, useEffect, useCallback } from "react";
import { Sidebar } from "../../components/Sidebar";
import { TopNav } from "../../components/TopNav";
import { Badge } from "../../components/Badge";
import { api } from "../../../lib/api";
import { Loader2 } from "lucide-react";

interface PredictedSubject {
  subject_id: string;
  subject_name: string;
  current_pct: number;
  predicted_pct: number;
  delta: number;
  safe: boolean;
  classes_missed: number;
}

interface PredictMultiResponse {
  from_date: string;
  to_date: string;
  subjects: PredictedSubject[];
  all_safe: boolean;
}

function getApprovalStatus(predicted: number): { label: string; badge: "warning" | "safe" } {
  return predicted < 75
    ? { label: "Needs Approval", badge: "warning" }
    : { label: "Auto-Approved", badge: "safe" };
}

export default function ApplyLeave() {
  const [leaveType, setLeaveType] = useState<"medical" | "academic" | "personal" | "other">("medical");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [reason, setReason] = useState("");
  const [proofFile, setProofFile] = useState<File | null>(null);
  const [proofError, setProofError] = useState<string | null>(null);
  const [submitted, setSubmitted] = useState(false);
  const [submitLoading, setSubmitLoading] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  // Prediction state
  const [predicting, setPredicting] = useState(false);
  const [predictError, setPredictError] = useState<string | null>(null);
  const [affectedSubjects, setAffectedSubjects] = useState<PredictedSubject[]>([]);
  const [noClassesOnDates, setNoClassesOnDates] = useState(false);

  const requiresProof = leaveType === "medical" || leaveType === "academic";

  const handleProofChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) {
      return;
    }

    if (!["application/pdf", "image/jpeg", "image/jpg", "image/png"].includes(file.type)) {
      setProofError("Only PDF, JPG, and PNG files are accepted.");
      setProofFile(null);
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      setProofError("File must be under 5MB.");
      setProofFile(null);
      return;
    }

    setProofError(null);
    setProofFile(file);
  };

  const handleLeaveTypeChange = (nextType: "medical" | "academic" | "personal" | "other") => {
    setLeaveType(nextType);
    setProofFile(null);
    setProofError(null);
  };

  // Auto-fetch prediction whenever both dates are selected
  const fetchPrediction = useCallback(async (from: string, to: string) => {
    if (!from || !to || from > to) {
      setAffectedSubjects([]);
      setNoClassesOnDates(false);
      setPredictError(null);
      return;
    }

    try {
      setPredicting(true);
      setPredictError(null);
      setNoClassesOnDates(false);

      const res = await api.get<PredictMultiResponse>(
        `/student/predict/multi/?from_date=${from}&to_date=${to}`
      );

      // Only keep subjects that actually have classes on these dates
      const subjectsWithClasses = (res.data.subjects || []).filter(
        (s) => s.classes_missed > 0
      );

      if (subjectsWithClasses.length === 0) {
        setNoClassesOnDates(true);
        setAffectedSubjects([]);
      } else {
        setAffectedSubjects(subjectsWithClasses);
        setNoClassesOnDates(false);
      }
    } catch (err) {
      console.error("Failed to fetch prediction", err);
      setPredictError("Could not calculate attendance impact. Please try again.");
      setAffectedSubjects([]);
    } finally {
      setPredicting(false);
    }
  }, []);

  useEffect(() => {
    if (fromDate && toDate) {
      fetchPrediction(fromDate, toDate);
    } else {
      setAffectedSubjects([]);
      setNoClassesOnDates(false);
    }
  }, [fromDate, toDate, fetchPrediction]);

  const handleSubmit = async () => {
    if (!fromDate || !toDate) {
      setSubmitError("Please select both from date and to date.");
      return;
    }
    if (fromDate > toDate) {
      setSubmitError("From date must be before or equal to to date.");
      return;
    }
    if (!reason.trim()) {
      setSubmitError("Please provide a reason for your leave.");
      return;
    }
    if (affectedSubjects.length === 0) {
      setSubmitError("No classes are scheduled for the selected dates. Leave request is not needed.");
      return;
    }

    if (requiresProof && !proofFile) {
      setSubmitError("Proof document is required for medical and academic leaves.");
      return;
    }

    const formData = new FormData();
    formData.append("leave_type", leaveType);
    formData.append("from_date", fromDate);
    formData.append("to_date", toDate);
    formData.append("reason", reason.trim());
    affectedSubjects.forEach((subject) => formData.append("subject_ids", subject.subject_id));
    if (proofFile) {
      formData.append("proof_file", proofFile);
    }

    try {
      setSubmitLoading(true);
      setSubmitError(null);
      await api.post("/student/leave/", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });
      setSubmitted(true);
      setReason("");
      setFromDate("");
      setToDate("");
      setAffectedSubjects([]);
      setProofFile(null);
      setProofError(null);
    } catch (err: unknown) {
      const detail =
        typeof err === "object" &&
        err !== null &&
        "response" in err
        ? (err as { response?: { data?: { detail?: string } } }).response?.data?.detail
        : undefined;
      setSubmitError(detail || "Failed to submit leave request. Please try again.");
    } finally {
      setSubmitLoading(false);
    }
  };

  const needsApproval = affectedSubjects.filter((s) => s.predicted_pct < 75).length;
  const autoApproved = affectedSubjects.filter((s) => s.predicted_pct >= 75).length;

  if (submitted) {
    return (
      <div className="flex h-screen bg-background overflow-hidden" style={{ fontFamily: "Inter, sans-serif" }}>
        <Sidebar role="student" />
        <div className="flex-1 flex flex-col overflow-hidden">
          <TopNav breadcrumb={["Apply Leave"]} userInitials="MD" />
          <div className="flex-1 overflow-y-auto p-8 flex items-center justify-center">
            <div className="bg-card rounded-[12px] border border-border p-12 text-center max-w-md">
              <div className="w-16 h-16 bg-[#DCFCE7] rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-[32px]">✅</span>
              </div>
              <h2 className="text-[20px] font-bold text-foreground mb-2">Leave Request Submitted</h2>
              <p className="text-[14px] text-muted-foreground mb-6">
                Your leave request has been submitted successfully. You will be notified once it is reviewed.
              </p>
              <button
                onClick={() => setSubmitted(false)}
                className="bg-primary text-primary-foreground rounded-[6px] px-6 h-11 text-[14px] font-medium hover:bg-primary/90 transition-colors"
              >
                Submit Another Leave
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-background overflow-hidden" style={{ fontFamily: "Inter, sans-serif" }}>
      <Sidebar role="student" />
      <div className="flex-1 flex flex-col overflow-hidden">
        <TopNav breadcrumb={["Apply Leave"]} userInitials="MD" />
        <div className="flex-1 overflow-y-auto p-8">
          <div className="flex gap-5">

            {/* LEFT — Form */}
            <div className="w-[600px] flex-shrink-0">
              <div className="bg-card rounded-[8px] border border-border shadow-[0_1px_4px_rgba(0,0,0,0.06)] p-6">
                <h2 className="text-[16px] font-semibold text-foreground mb-5">Leave Details</h2>

                {/* Leave Type */}
                <div className="mb-5">
                  <label className="block text-[12px] font-medium text-muted-foreground uppercase tracking-wide mb-2">
                    Leave Type
                  </label>
                  <div className="flex gap-2 flex-wrap">
                    {(["medical", "academic", "personal", "other"] as const).map((t) => (
                      <button
                        key={t}
                        onClick={() => handleLeaveTypeChange(t)}
                        className="px-5 py-2 rounded-[6px] text-[13px] font-medium transition-all border capitalize"
                        style={{
                          backgroundColor: leaveType === t ? "var(--color-primary-foreground)" : "transparent",
                          borderColor: leaveType === t ? "var(--color-primary)" : "var(--color-border)",
                          color: leaveType === t ? "var(--color-primary)" : "var(--color-foreground)",
                        }}
                      >
                        {t}
                      </button>
                    ))}
                  </div>
                </div>

                {requiresProof && (
                  <div className="mb-5">
                    <label className="block text-[12px] font-medium text-muted-foreground uppercase tracking-wide mb-2">
                      Proof Document <span className="text-destructive">*</span>
                    </label>
                    <p className="text-[12px] text-muted-foreground mb-2">
                      {leaveType === "medical"
                        ? "Upload a medical certificate or doctor prescription."
                        : "Upload the official event letter or permission slip from college."}
                    </p>
                    <label className="flex items-center gap-3 border border-border rounded-[6px] px-4 py-3 cursor-pointer hover:border-primary transition-colors">
                      <span className="text-[13px] text-primary font-medium">
                        {proofFile ? `✓ ${proofFile.name}` : "Choose File"}
                      </span>
                      <input
                        type="file"
                        accept=".pdf,.jpg,.jpeg,.png"
                        onChange={handleProofChange}
                        className="hidden"
                      />
                    </label>
                    {proofError && (
                      <p className="text-[12px] text-destructive mt-1">{proofError}</p>
                    )}
                    {!proofFile && (
                      <p className="text-[11px] text-muted-foreground mt-1">
                        Accepted: PDF, JPG, PNG — Max 5MB
                      </p>
                    )}
                  </div>
                )}

                {/* Date Range */}
                <div className="flex gap-3 mb-5">
                  <div className="flex-1">
                    <label className="block text-[12px] font-medium text-muted-foreground uppercase tracking-wide mb-2">
                      From Date
                    </label>
                    <input
                      type="date"
                      value={fromDate}
                      onChange={(e) => setFromDate(e.target.value)}
                      className="w-full border border-border rounded-[6px] px-3 py-2.5 text-[14px] text-foreground outline-none focus:border-primary bg-background"
                    />
                  </div>
                  <div className="flex-1">
                    <label className="block text-[12px] font-medium text-muted-foreground uppercase tracking-wide mb-2">
                      To Date
                    </label>
                    <input
                      type="date"
                      value={toDate}
                      min={fromDate}
                      onChange={(e) => setToDate(e.target.value)}
                      className="w-full border border-border rounded-[6px] px-3 py-2.5 text-[14px] text-foreground outline-none focus:border-primary bg-background"
                    />
                  </div>
                </div>

                {/* Auto-populated affected subjects — read only */}
                <div className="mb-5">
                  <label className="block text-[12px] font-medium text-muted-foreground uppercase tracking-wide mb-2">
                    Affected Classes
                    <span className="ml-2 text-[11px] normal-case text-muted-foreground font-normal">
                      (auto-detected from your timetable)
                    </span>
                  </label>

                  {!fromDate || !toDate ? (
                    <p className="text-[13px] text-muted-foreground py-2">
                      Select dates above to see which classes will be affected.
                    </p>
                  ) : predicting ? (
                    <div className="flex items-center gap-2 py-2">
                      <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />
                      <span className="text-[13px] text-muted-foreground">Checking timetable...</span>
                    </div>
                  ) : predictError ? (
                    <p className="text-[13px] text-destructive">{predictError}</p>
                  ) : noClassesOnDates ? (
                    <div className="bg-[#F0FDF4] border border-[#86EFAC] rounded-[6px] px-4 py-3">
                      <p className="text-[13px] text-[#16A34A] font-medium">
                        ✓ No classes scheduled for these dates. You do not need to apply for leave.
                      </p>
                    </div>
                  ) : (
                    <div className="flex flex-wrap gap-2">
                      {affectedSubjects.map((s) => (
                        <div
                          key={s.subject_id}
                          className="px-3 py-1.5 rounded-[6px] text-[13px] font-medium border"
                          style={{
                            backgroundColor: "var(--color-primary-foreground)",
                            borderColor: "var(--color-primary)",
                            color: "var(--color-primary)",
                          }}
                        >
                          {s.subject_name}
                          <span className="ml-1 text-[11px] opacity-70">
                            ({s.classes_missed} class{s.classes_missed !== 1 ? "es" : ""})
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Reason */}
                <div className="mb-6">
                  <label className="block text-[12px] font-medium text-muted-foreground uppercase tracking-wide mb-2">
                    Reason
                  </label>
                  <textarea
                    rows={4}
                    value={reason}
                    onChange={(e) => setReason(e.target.value.slice(0, 500))}
                    placeholder="Describe the reason for your leave..."
                    className="w-full border border-border rounded-[6px] px-3 py-2.5 text-[14px] text-foreground outline-none focus:border-primary resize-none bg-background"
                  />
                  <div className="flex justify-end mt-1">
                    <span className="text-[11px] text-muted-foreground">{reason.length}/500</span>
                  </div>
                </div>

                {submitError && (
                  <div className="mb-4 text-[13px] text-destructive font-medium bg-[#FEE2E2] p-3 rounded-[6px]">
                    {submitError}
                  </div>
                )}

                <button
                  onClick={handleSubmit}
                  disabled={submitLoading || predicting || affectedSubjects.length === 0 || !reason.trim()}
                  className="w-full bg-primary flex items-center justify-center text-primary-foreground rounded-[6px] h-11 text-[14px] font-medium hover:bg-primary/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {submitLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : "Submit Leave Request"}
                </button>

                <p className="text-center text-[12px] text-muted-foreground mt-3">
                  Leave requests are reviewed within 24 hours on working days.
                </p>
              </div>
            </div>

            {/* RIGHT — Impact Preview */}
            <div className="flex-1">
              <div className="bg-background rounded-[8px] border border-border shadow-[0_1px_4px_rgba(0,0,0,0.06)] p-6">
                <div className="flex items-center justify-between mb-5">
                  <h2 className="text-[16px] font-semibold text-foreground">Attendance Impact Preview</h2>
                  <span className="bg-primary/10 text-primary text-[11px] font-bold uppercase tracking-wide rounded-full px-3 py-1">
                    Auto-calculated
                  </span>
                </div>

                {!fromDate || !toDate ? (
                  <p className="text-[14px] text-muted-foreground text-center py-8">
                    Select leave dates to see predicted attendance impact.
                  </p>
                ) : predicting ? (
                  <div className="flex items-center justify-center gap-2 py-8">
                    <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
                    <span className="text-[14px] text-muted-foreground">Calculating impact...</span>
                  </div>
                ) : noClassesOnDates ? (
                  <p className="text-[14px] text-muted-foreground text-center py-8">
                    No classes found for the selected dates.
                  </p>
                ) : affectedSubjects.length > 0 ? (
                  <>
                    <table className="w-full mb-5">
                      <thead>
                        <tr className="bg-secondary">
                          {["Subject", "Current %", "Predicted %", "Status"].map((h) => (
                            <th
                              key={h}
                              className="text-left text-[11px] font-bold text-primary-foreground uppercase tracking-wide px-3 py-2.5"
                            >
                              {h}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {affectedSubjects.map((s, i) => {
                          const { label, badge } = getApprovalStatus(s.predicted_pct);
                          return (
                            <tr
                              key={s.subject_id}
                              style={{ backgroundColor: i % 2 === 0 ? "#FFFFFF" : "#F8F9FA" }}
                              className="h-12"
                            >
                              <td className="px-3 py-3 text-[13px] text-foreground font-medium">
                                {s.subject_name}
                              </td>
                              <td className="px-3 py-3 text-[13px] text-[#D97706] font-medium">
                                {s.current_pct}%
                              </td>
                              <td
                                className="px-3 py-3 text-[13px] font-medium"
                                style={{ color: s.predicted_pct >= 75 ? "#16A34A" : "#DC2626" }}
                              >
                                {s.predicted_pct}%
                                <span className="ml-1 text-[11px] opacity-70">
                                  ({s.delta > 0 ? "+" : ""}{s.delta}%)
                                </span>
                              </td>
                              <td className="px-3 py-3">
                                <Badge variant={badge}>{label}</Badge>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>

                    <div className="space-y-2">
                      {needsApproval > 0 && (
                        <div className="bg-primary-foreground border border-primary/20 rounded-[6px] px-4 py-3 text-[14px] text-primary/80">
                          ⚠️ {needsApproval} subject{needsApproval > 1 ? "s" : ""} will require teacher approval
                        </div>
                      )}
                      {autoApproved > 0 && (
                        <div className="bg-secondary-foreground border border-secondary/20 rounded-[6px] px-4 py-3 text-[14px] text-secondary">
                          ✅ {autoApproved} subject{autoApproved > 1 ? "s" : ""} will be auto-approved
                        </div>
                      )}
                    </div>
                  </>
                ) : null}
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
}
