import React, { useEffect, useState } from "react";
import { Sidebar } from "../../components/Sidebar";
import { TopNav } from "../../components/TopNav";
import { StatCard } from "../../components/StatCard";
import { Badge } from "../../components/Badge";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  LineChart, Line, ReferenceLine, Cell,
} from "recharts";
import CalendarHeatmap from 'react-calendar-heatmap';
import { Tooltip as ReactTooltip } from 'react-tooltip';
import 'react-tooltip/dist/react-tooltip.css';
import 'react-calendar-heatmap/dist/styles.css';
import { api } from "../../../lib/api";
import { useAuth } from "../../contexts/AuthContext";
import { Loader2 } from "lucide-react";

interface StudentAttendanceSubject {
  subject_id: string;
  subject_name: string;
  subject_code: string;
  total_classes: number;
  attended: number;
  percentage: number;
}

interface StudentAttendanceSummary {
  student_id: string;
  subjects: StudentAttendanceSubject[];
  overall_percentage: number;
}

interface StudentChartPoint {
  date: string;
  cumulative_pct: number;
}

interface HeatmapValue {
  date: string;
  count: number;
  tooltipText: string;
}

function getErrorMessage(error: unknown): string {
  if (error instanceof Error) return error.message;
  return "Unknown error";
}

export default function StudentDashboard() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Data states
  const [summary, setSummary] = useState<StudentAttendanceSummary | null>(null);
  const [subjects, setSubjects] = useState<StudentAttendanceSubject[]>([]);
  const [heatmapData, setHeatmapData] = useState<StudentChartPoint[]>([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        setError(null);
        
        // 1. Fetch Subject List & Overall Settings
        const summaryRes = await api.get('/student/attendance/');
        setSummary(summaryRes.data);
        setSubjects(summaryRes.data.subjects || []);

        // 2. Fetch chart data for first subject (endpoint requires subject_id)
        const subjectList = summaryRes.data.subjects || [];
        if (subjectList.length > 0) {
          const firstSubjectId = subjectList[0].subject_id;
          const chartRes = await api.get(`/student/attendance/chart/?subject_id=${firstSubjectId}`);
          setHeatmapData(chartRes.data.chart_data || []);
        } else {
          setHeatmapData([]);
        }
      } catch (err: unknown) {
        console.error("Dashboard fetch error:", getErrorMessage(err));
        setError("Failed to load dashboard data. Please try again.");
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  // Prepare recharts arrays
  const totalConducted = subjects.reduce((acc, s) => acc + (s.total_classes || 0), 0);
  const totalAttended = subjects.reduce((acc, s) => acc + (s.attended || 0), 0);

  const barChartData = subjects.map((s) => ({
    subject: s.subject_code,
    pct: s.percentage,
    fill: s.percentage >= 80 ? "var(--color-primary)" : s.percentage >= 75 ? "var(--color-primary-foreground)" : "var(--color-destructive)",
  }));

  const heatmapStartDate = new Date(new Date().getTime() - 365 * 24 * 60 * 60 * 1000);

  if (loading) {
     return (
       <div className="flex h-screen items-center justify-center bg-background">
         <Loader2 className="w-8 h-8 animate-spin text-primary" />
       </div>
     );
  }

  if (error) {
     return (
       <div className="flex h-screen items-center justify-center bg-background">
         <div className="text-destructive font-medium">{error}</div>
       </div>
     );
  }

  return (
    <div className="flex h-screen bg-background overflow-hidden" style={{ fontFamily: "Inter, sans-serif" }}>
      <Sidebar role="student" />
      <div className="flex-1 flex flex-col overflow-hidden">
        <TopNav breadcrumb={["Dashboard"]} userInitials={user?.full_name?.substring(0, 2).toUpperCase() || "ST"} />
        <div className="flex-1 overflow-y-auto p-8 space-y-6">

          {/* Stat cards row */}
          <div className="flex gap-5">
            <StatCard
              label="Overall Attendance"
              value={`${summary?.overall_percentage}%`}
              subLabel="Current average"
              borderColor={summary?.overall_percentage >= 75 ? "var(--color-primary)" : "var(--color-destructive)"}
              valueColor={summary?.overall_percentage >= 75 ? "var(--color-primary)" : "var(--color-destructive)"}
            />
            <StatCard
              label="Total Classes"
              value={totalConducted}
              subLabel="Across all subjects"
              borderColor="var(--color-secondary)"
              valueColor="var(--color-secondary)"
            />
            <StatCard
              label="Classes Attended"
              value={totalAttended}
              subLabel={`Out of ${totalConducted} classes`}
              borderColor="var(--color-primary)"
              valueColor="var(--color-primary)"
            />
            <StatCard
              label="Subjects Enrolled"
              value={subjects.length || 0}
              subLabel="Current semester"
              borderColor="var(--color-secondary)"
              valueColor="var(--color-secondary)"
            />
          </div>

          {/* Main content row */}
          <div className="flex gap-5">
            {/* Subject-wise table */}
            <div className="flex-1 bg-card rounded-[8px] border border-border shadow-[0_1px_4px_rgba(0,0,0,0.06)] overflow-hidden">
              <div className="px-5 py-4 border-b border-border">
                <h3 className="text-[15px] font-semibold text-foreground">Subject-wise Attendance</h3>
              </div>
              <table className="w-full">
                <thead>
                  <tr className="bg-secondary">
                    {["Subject Name", "Code", "Conducted", "Attended", "Percentage", "Status"].map((h) => (
                      <th key={h} className="text-left text-[11px] font-bold text-secondary-foreground uppercase tracking-wide px-4 py-3">
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {subjects.map((s, idx) => (
                    <tr key={s.subject_id} style={{ backgroundColor: idx % 2 === 0 ? "#FFFFFF" : "#F8F9FA" }} className="h-12">
                      <td className="px-4 py-3 text-[13px] text-foreground font-medium">{s.subject_name}</td>
                      <td className="px-4 py-3 text-[13px] text-muted-foreground">{s.subject_code}</td>
                      <td className="px-4 py-3 text-[13px] text-foreground">{s.total_classes}</td>
                      <td className="px-4 py-3 text-[13px] text-foreground">{s.attended}</td>
                      <td className="px-4 py-3 text-[13px] font-semibold"
                        style={{ color: s.percentage >= 80 ? "var(--color-primary)" : s.percentage >= 75 ? "#D97706" : "var(--color-destructive)" }}>
                        {s.percentage}%
                      </td>
                      <td className="px-4 py-3">
                        <Badge variant={s.percentage >= 75 ? "safe" : s.percentage >= 65 ? "warning" : "critical"}>
                           {s.percentage >= 75 ? "Safe" : s.percentage >= 65 ? "Shortage" : "Critical"}
                        </Badge>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Right charts */}
            <div className="w-[380px] flex flex-col gap-4">
              {/* Wait to render chart until data exists, Recharts can bug out otherwise */}
              {barChartData.length > 0 && (
                <div className="bg-card rounded-[8px] border border-border shadow-[0_1px_4px_rgba(0,0,0,0.06)] p-5">
                  <h3 className="text-[14px] font-semibold text-foreground mb-3">Attendance Overview</h3>
                  <ResponsiveContainer width="100%" height={160}>
                    <BarChart data={barChartData} layout="vertical" margin={{ left: 0, right: 20 }}>
                      <CartesianGrid horizontal={false} stroke="#E5E7EB" />
                      <XAxis type="number" domain={[0, 100]} tick={{ fontSize: 10, fill: "#6B7280" }} tickLine={false} axisLine={false} />
                      <YAxis type="category" dataKey="subject" tick={{ fontSize: 11, fill: "#6B7280" }} tickLine={false} axisLine={false} width={44} />
                      <Tooltip
                        formatter={(v: number) => [`${v}%`, "Attendance"]}
                        contentStyle={{ fontSize: 12, border: "1px solid #E5E7EB", borderRadius: 6 }}
                      />
                      <ReferenceLine x={75} stroke="#DC2626" strokeDasharray="4 3" strokeWidth={1.5} label={{ value: "75%", position: "top", fontSize: 9, fill: "#DC2626" }} />
                      <Bar dataKey="pct" radius={[0, 3, 3, 0]} maxBarSize={16}>
                        {barChartData.map((d, i) => (
                          <Cell key={i} fill={d.fill} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              )}
            </div>
          </div>

          {/* Heatmap Row */}
          <div className="bg-card rounded-[16px] border border-border/20 shadow-xl p-8 mt-4 mb-8">
            <h3 className="text-[22px] font-black text-foreground mb-8 text-center tracking-tight">Visualize Your Academic Activity</h3>
            <div className="flex justify-center">
              <div className="w-full max-w-[850px]">
                <CalendarHeatmap
                  startDate={heatmapStartDate}
                  endDate={new Date()}
                  values={heatmapData.map((d): HeatmapValue => {
                    const pct = d.cumulative_pct || 0;
                    let level = 0;
                    if (pct > 0) {
                      if (pct >= 90) level = 4;
                      else if (pct >= 80) level = 3;
                      else if (pct >= 70) level = 2;
                      else level = 1;
                    }
                    return {
                      date: d.date,
                      count: level,
                      tooltipText: `${pct.toFixed(1)}% cumulative attendance on ${new Date(d.date).toLocaleDateString()}`
                    };
                  })}
                  classForValue={(value) => {
                    if (!value || value.count === 0) {
                      return 'color-empty';
                    }
                    return `color-scale-${value.count}`;
                  }}
                  tooltipDataAttrs={(value: HeatmapValue | null) => {
                    if (!value || !value.date) return {};
                    return {
                      'data-tooltip-id': 'heatmap-tooltip',
                      'data-tooltip-content': value.tooltipText,
                    };
                  }}
                  showWeekdayLabels={false}
                />
                <ReactTooltip id="heatmap-tooltip" style={{ backgroundColor: 'var(--color-popover)', color: 'var(--color-popover-foreground)', borderRadius: '6px', fontSize: '13px', border: '1px solid var(--color-border)' }} />
              </div>
            </div>
            
            <div className="flex items-center justify-end gap-3 mt-8 mr-6 text-[11px] font-bold text-muted-foreground uppercase tracking-wider">
              <span>Less Active</span>
              <div className="flex gap-1.5 opacity-90">
                <div className="w-3.5 h-3.5 rounded-[2px] bg-[#FDBA74]"></div>
                <div className="w-3.5 h-3.5 rounded-[2px] bg-[#FB923C]"></div>
                <div className="w-3.5 h-3.5 rounded-[2px] bg-[#EA580C]"></div>
                <div className="w-3.5 h-3.5 rounded-[2px] bg-[#9A3412]"></div>
              </div>
              <span>Highly Active</span>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}