import React, { useState, useEffect } from "react";
import { Sidebar } from "../../components/Sidebar";
import { TopNav } from "../../components/TopNav";
import { api } from "../../../lib/api";

interface TimetableSlot {
  id: string;
  start_time: string;
  end_time: string;
  subject_name: string;
  subject_code: string;
  room: string;
  slot_type: 'lecture' | 'lab' | 'minor' | 'activity' | 'wellness' | 'cep' | 'break';
}

interface TimetableResponse {
  success: boolean;
  division: string;
  schedule: Record<string, TimetableSlot[]>;
}

const typeStyles: Record<string, { bg: string; text: string; border: string }> = {
  lecture: { bg: 'bg-primary/10', text: 'text-primary', border: 'border-primary/20' },
  lab: { bg: 'bg-emerald-500/10', text: 'text-emerald-600', border: 'border-emerald-500/20' },
  minor: { bg: 'bg-orange-500/10', text: 'text-orange-600', border: 'border-orange-500/20' },
  activity: { bg: 'bg-purple-500/10', text: 'text-purple-600', border: 'border-purple-500/20' },
  wellness: { bg: 'bg-rose-500/10', text: 'text-rose-600', border: 'border-rose-500/20' },
  cep: { bg: 'bg-blue-500/10', text: 'text-blue-600', border: 'border-blue-500/20' },
  break: { bg: 'bg-secondary/50', text: 'text-muted-foreground', border: 'border-border' },
};

export default function Timetable() {
  const [division, setDivision] = useState<string>("A");
  const [schedule, setSchedule] = useState<Record<string, TimetableSlot[]>>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchTimetable = async () => {
      try {
        setLoading(true);
        const res = await api.get<TimetableResponse>("/student/timetable/");
        if (res.data.success) {
          setSchedule(res.data.schedule);
          setDivision(res.data.division);
        } else {
          setError("Failed to load timetable.");
        }
      } catch (err) {
        setError("Could not connect to server. Please try again.");
      } finally {
        setLoading(false);
      }
    };
    fetchTimetable();
  }, []);

  const days = Object.keys(schedule);

  return (
    <div className="flex h-screen bg-background overflow-hidden" style={{ fontFamily: "Inter, sans-serif" }}>
      <Sidebar role="student" />
      <div className="flex-1 flex flex-col overflow-hidden">
        <TopNav breadcrumb={["Timetable"]} userInitials="MD" />
        <div className="flex-1 overflow-y-auto p-8">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-[24px] font-bold text-foreground">Weekly Timetable</h1>
              <p className="text-[14px] text-muted-foreground mt-1">Class schedule for Division {division}</p>
            </div>
            <div className="flex items-center gap-2">
               <span className="bg-primary/10 text-primary text-[12px] font-bold px-3 py-1 rounded-full uppercase tracking-wider">Semester 5</span>
               <span className="bg-secondary text-secondary-foreground text-[12px] font-bold px-3 py-1 rounded-full uppercase tracking-wider">AY 2024-25</span>
            </div>
          </div>

          {loading ? (
             <div className="flex flex-col items-center justify-center h-[400px]">
                <div className="w-10 h-10 border-4 border-primary/20 border-t-primary rounded-full animate-spin mb-4" />
                <p className="text-[14px] text-muted-foreground font-medium">Synchronizing timetable...</p>
             </div>
          ) : error ? (
            <div className="bg-destructive/10 border border-destructive/20 rounded-[8px] p-12 text-center">
              <p className="text-destructive font-semibold mb-2">{error}</p>
              <button onClick={() => window.location.reload()} className="text-[13px] text-primary font-bold hover:underline">Try Refreshing</button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
              {days.map((day) => (
                <div key={day} className="space-y-4">
                  <div className="flex items-center gap-2 px-1">
                    <h3 className="text-[15px] font-bold text-foreground">{day}</h3>
                    <div className="h-px flex-1 bg-border/60" />
                  </div>
                  
                  <div className="space-y-3">
                    {schedule[day].length > 0 ? (
                      schedule[day].map((slot) => {
                        const style = typeStyles[slot.slot_type] || typeStyles.lecture;
                        return (
                          <div 
                            key={slot.id}
                            className={`group relative rounded-[10px] border ${style.border} ${style.bg} p-3.5 transition-all hover:shadow-md hover:scale-[1.02] cursor-pointer overflow-hidden`}
                          >
                            <div className="flex items-center justify-between mb-1.5">
                              <span className={`text-[10px] font-bold uppercase tracking-widest ${style.text}`}>{slot.slot_type}</span>
                              <span className="text-[11px] font-medium text-muted-foreground bg-background/50 px-2 py-0.5 rounded-full">{slot.start_time} - {slot.end_time}</span>
                            </div>
                            
                            <h4 className="text-[13px] font-bold text-foreground leading-snug mb-0.5 group-hover:text-primary transition-colors">
                              {slot.subject_name || (slot.slot_type === 'break' ? 'Recess' : slot.slot_type.charAt(0).toUpperCase() + slot.slot_type.slice(1))}
                            </h4>
                            <div className="flex items-center justify-between mt-2">
                              <span className="text-[11px] text-muted-foreground font-semibold">{slot.subject_code}</span>
                              {slot.room && (
                                <span className={`text-[10px] font-bold ${style.text} opacity-80`}>📍 {slot.room}</span>
                              )}
                            </div>
                          </div>
                        );
                      })
                    ) : (
                      <div className="h-24 bg-secondary/20 rounded-[10px] border border-dashed border-border flex items-center justify-center">
                        <span className="text-[11px] text-muted-foreground italic">No classes</span>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
          
          {/* Legend */}
          {!loading && !error && (
            <div className="mt-12 pt-6 border-t border-border flex flex-wrap gap-5">
              {Object.entries(typeStyles).map(([type, s]) => (
                <div key={type} className="flex items-center gap-2">
                  <div className={`w-3.5 h-3.5 rounded-full border ${s.border} ${s.bg}`} />
                  <span className="text-[12px] text-muted-foreground font-medium capitalize">{type}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
