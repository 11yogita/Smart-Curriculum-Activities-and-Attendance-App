import React, { useState, useEffect } from "react";
import { Sidebar } from "../../components/Sidebar";
import { TopNav } from "../../components/TopNav";
import { useNavigate } from "react-router";
import { ChevronDown, Minus, Plus, Loader2 } from "lucide-react";
import { api } from "../../../lib/api";

interface StudentAttendanceSubject {
  subject_id: string;
  subject_name: string;
  subject_code: string;
}

interface PredictResponse {
  subject_id: string;
  subject_name: string;
  current_pct: number;
  predicted_pct: number;
  delta: number;
  safe: boolean;
  miss: number;
}

export default function AttendancePredictor() {
  const navigate = useNavigate();
  
  const [subjects, setSubjects] = useState<StudentAttendanceSubject[]>([]);
  const [selectedSubjectId, setSelectedSubjectId] = useState<string>("");
  const [classesToMiss, setClassesToMiss] = useState(1);
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  
  // Predict Result States
  const [predictedData, setPredictedData] = useState<PredictResponse | null>(null);
  const [isCalculating, setIsCalculating] = useState(false);
  const [calculated, setCalculated] = useState(false);

  // Initial load: get enrolled subjects
  useEffect(() => {
    const fetchSubjects = async () => {
      try {
        const res = await api.get('/student/attendance/');
        if (res.data.subjects && res.data.subjects.length > 0) {
           setSubjects(res.data.subjects);
           setSelectedSubjectId(res.data.subjects[0].subject_id);
        }
      } catch (err) {
        console.error("Failed to load subjects", err);
      }
    };
    fetchSubjects();
  }, []);

  const handleCalculateSingle = async () => {
     if (!selectedSubjectId) return;
     try {
       setIsCalculating(true);
       const res = await api.get(`/student/predict/?subject_id=${selectedSubjectId}&miss=${classesToMiss}`);
       setPredictedData(res.data);
       setCalculated(true);
     } catch (err) {
       console.error("Simulation failed", err);
     } finally {
       setIsCalculating(false);
     }
  };

  return (
    <div className="flex h-screen bg-background overflow-hidden" style={{ fontFamily: "Inter, sans-serif" }}>
      <Sidebar role="student" />
      <div className="flex-1 flex flex-col overflow-hidden">
        <TopNav breadcrumb={["Attendance Predictor"]} userInitials="RS" />
        <div className="flex-1 overflow-y-auto p-8">
          <div className="mb-6">
            <h1 className="text-[24px] font-bold text-foreground">Attendance Predictor</h1>
            <p className="text-[14px] text-muted-foreground mt-1">Simulate how planned absences affect your attendance percentage</p>
          </div>

          <div className="flex gap-5">
            {/* Left: Simulate form */}
            <div className="w-[520px] flex-shrink-0">
              <div className="bg-card rounded-[8px] border border-border shadow-[0_1px_4px_rgba(0,0,0,0.06)] p-6">
                <h2 className="text-[16px] font-semibold text-foreground mb-5">Simulate Leave Impact</h2>

                {/* Subject dropdown */}
                <div className="mb-5">
                  <label className="block text-[12px] font-medium text-muted-foreground uppercase tracking-wide mb-2">Subject</label>
                  <div className="relative">
                    <select
                      value={selectedSubjectId}
                      onChange={(e) => setSelectedSubjectId(e.target.value)}
                      className="w-full border border-border rounded-[6px] px-3 py-2.5 text-[14px] text-foreground outline-none focus:border-primary appearance-none bg-card pr-8"
                    >
                      {subjects.map((s) => (
                        <option key={s.subject_id} value={s.subject_id}>{s.subject_name} — {s.subject_code}</option>
                      ))}
                    </select>
                    <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
                  </div>
                </div>

                {/* Classes to miss stepper */}
                <div className="mb-4">
                  <label className="block text-[12px] font-medium text-muted-foreground uppercase tracking-wide mb-2">Classes to Miss</label>
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => setClassesToMiss(Math.max(1, classesToMiss - 1))}
                      className="w-9 h-9 rounded-[6px] border border-border flex items-center justify-center hover:bg-background transition-colors"
                    >
                      <Minus size={14} className="text-foreground" />
                    </button>
                    <span className="text-[20px] font-bold text-foreground w-8 text-center">{classesToMiss}</span>
                    <button
                      onClick={() => setClassesToMiss(classesToMiss + 1)}
                      className="w-9 h-9 rounded-[6px] border border-border flex items-center justify-center hover:bg-background transition-colors"
                    >
                      <Plus size={14} className="text-foreground" />
                    </button>
                    <span className="text-[13px] text-muted-foreground">classes</span>
                  </div>
                </div>

                {/* Divider */}
                <div className="flex items-center gap-3 my-4">
                  <div className="flex-1 h-px bg-[#E5E7EB]" />
                  <span className="text-[12px] text-muted-foreground font-medium">OR use date range</span>
                  <div className="flex-1 h-px bg-[#E5E7EB]" />
                </div>

                {/* Date range */}
                <div className="flex gap-3 mb-6">
                  <div className="flex-1">
                    <label className="block text-[12px] font-medium text-muted-foreground uppercase tracking-wide mb-2">From</label>
                    <input
                      type="date"
                      value={fromDate}
                      onChange={(e) => setFromDate(e.target.value)}
                      className="w-full border border-border rounded-[6px] px-3 py-2.5 text-[14px] text-foreground outline-none focus:border-primary"
                    />
                  </div>
                  <div className="flex-1">
                    <label className="block text-[12px] font-medium text-muted-foreground uppercase tracking-wide mb-2">To</label>
                    <input
                      type="date"
                      value={toDate}
                      onChange={(e) => setToDate(e.target.value)}
                      className="w-full border border-border rounded-[6px] px-3 py-2.5 text-[14px] text-foreground outline-none focus:border-primary"
                    />
                  </div>
                </div>

                <button
                  onClick={handleCalculateSingle}
                  disabled={isCalculating || !selectedSubjectId}
                  className="w-full bg-primary flex justify-center items-center text-primary-foreground rounded-[6px] h-11 text-[14px] font-medium hover:bg-primary/90 transition-colors disabled:opacity-50"
                >
                  {isCalculating ? <Loader2 className="animate-spin w-4 h-4" /> : "Calculate Impact"}
                </button>
                <div className="text-center mt-3">
                  <button className="text-[13px] text-primary hover:underline">
                    Simulate across all subjects →
                  </button>
                </div>
              </div>
            </div>

            {/* Right: Result */}
            {calculated && predictedData && (
              <div className="flex-1">
                <div className="bg-card rounded-[8px] border border-border shadow-[0_1px_4px_rgba(0,0,0,0.06)] p-6">
                  <h2 className="text-[16px] font-semibold text-foreground mb-5">
                    Prediction Result
                  </h2>

                  {/* Stat boxes */}
                  <div className="grid grid-cols-3 gap-4 mb-5">
                    <div className="bg-primary-foreground rounded-[8px] p-4 text-center">
                      <div className="text-[11px] text-primary font-bold uppercase tracking-wide mb-1">Current</div>
                      <div className="text-[26px] font-bold text-primary">{predictedData.current_pct}%</div>
                    </div>
                    <div className="bg-[#FEE2E2] rounded-[8px] p-4 text-center">
                      <div className="text-[11px] text-destructive font-bold uppercase tracking-wide mb-1">Predicted</div>
                      <div className="text-[26px] font-bold text-destructive">{predictedData.predicted_pct}%</div>
                    </div>
                    <div className="bg-[#FEE2E2] rounded-[8px] p-4 text-center">
                      <div className="text-[11px] text-destructive font-bold uppercase tracking-wide mb-1">Impact</div>
                      <div className="text-[26px] font-bold text-destructive">{predictedData.delta}%</div>
                    </div>
                  </div>

                  {/* Warning banner */}
                  {!predictedData.safe && (
                    <div className="bg-[#FEE2E2] border-l-4 border-[#DC2626] rounded-r-[6px] px-4 py-3 mb-5">
                      <p className="text-[14px] text-destructive">
                        ⚠️ This leave will drop attendance to {predictedData.predicted_pct}% — below 75% minimum. Teacher approval required.
                      </p>
                    </div>
                  )}

                  {/* CTA buttons */}
                  <div className="flex gap-3 mt-5">
                    <button
                      onClick={() => navigate("/student/leave/apply")}
                      className="flex-1 bg-destructive text-primary-foreground rounded-[6px] h-11 text-[14px] font-medium hover:bg-destructive/90 transition-colors"
                    >
                      Apply for Leave →
                    </button>
                    <button
                      onClick={() => { setCalculated(false); setPredictedData(null); }}
                      className="px-6 border border-border text-foreground rounded-[6px] h-11 text-[14px] font-medium hover:bg-background transition-colors"
                    >
                      Recalculate
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
