import React, { useState } from "react";
import { useNavigate } from "react-router";
import { Eye, EyeOff, Loader2 } from "lucide-react";
import { useAuth } from "../contexts/AuthContext";
import { api } from "../../lib/api";

export default function LoginPage() {
  const navigate = useNavigate();
  const { login } = useAuth();
  
  const [role, setRole] = useState<"Student" | "Teacher" | "Admin">("Student");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [errorText, setErrorText] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSignIn = async () => {
    setErrorText("");
    if (!email || !password) {
      setErrorText("Please enter both email and password.");
      return;
    }
    
    setIsSubmitting(true);
    try {
      const response = await api.post('/auth/login/', {
        email,
        password,
        role: role.toLowerCase(),
      });
      
      if (response.status === 200) {
        const { access, refresh, user } = response.data;
        login(access, refresh, user);
        
        if (user.role === "student") navigate("/student/dashboard");
        else if (user.role === "teacher") navigate("/teacher/dashboard");
        else navigate("/admin/dashboard");
      }
    } catch (err: unknown) {
      const detail = typeof err === 'object' && err !== null && 'response' in err
        ? (err as { response?: { data?: { detail?: string } } }).response?.data?.detail
        : undefined;
      if (detail) {
        setErrorText(detail || "Invalid credentials or role mismatch.");
      } else {
        setErrorText("Network error. Is the backend running?");
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden" style={{ fontFamily: "Inter, sans-serif" }}>
      {/* Left Panel */}
      <div className="w-[600px] flex-shrink-0 bg-secondary flex flex-col p-10 relative overflow-hidden">
        {/* Logo */}
        <div className="text-[20px] font-bold text-primary-foreground">AttendIQ</div>

        {/* Center content */}
        <div className="flex-1 flex flex-col items-center justify-center text-center">
          <h1 className="text-[40px] font-bold text-primary-foreground leading-tight mb-4">
            Smart Attendance.<br />Smarter Decisions.
          </h1>
          <p className="text-[16px] text-primary-foreground/80 max-w-xs">
            Track, predict, and manage college attendance with AI-powered insights.
          </p>

          {/* Abstract geometric illustration */}
          <div className="mt-12 relative w-72 h-64">
            <svg viewBox="0 0 288 256" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
              {/* Hexagon grid pattern */}
              <circle cx="144" cy="128" r="100" fill="rgba(255,240,196,0.08)" />
              <circle cx="144" cy="128" r="70" fill="rgba(255,240,196,0.08)" />
              <circle cx="144" cy="128" r="40" fill="rgba(255,240,196,0.12)" />

              {/* Decorative lines */}
              <line x1="44" y1="128" x2="244" y2="128" stroke="#FFF0C4" strokeWidth="1" strokeOpacity="0.3" strokeDasharray="4 4" />
              <line x1="144" y1="28" x2="144" y2="228" stroke="#FFF0C4" strokeWidth="1" strokeOpacity="0.3" strokeDasharray="4 4" />
              <line x1="73" y1="57" x2="215" y2="199" stroke="#FFF0C4" strokeWidth="1" strokeOpacity="0.2" strokeDasharray="4 4" />
              <line x1="215" y1="57" x2="73" y2="199" stroke="#FFF0C4" strokeWidth="1" strokeOpacity="0.2" strokeDasharray="4 4" />

              {/* Nodes */}
              <circle cx="144" cy="128" r="12" fill="#FFF0C4" />
              <circle cx="44" cy="128" r="6" fill="#FFF0C4" fillOpacity="0.5" />
              <circle cx="244" cy="128" r="6" fill="#FFF0C4" fillOpacity="0.5" />
              <circle cx="144" cy="28" r="6" fill="#FFF0C4" fillOpacity="0.5" />
              <circle cx="144" cy="228" r="6" fill="#FFF0C4" fillOpacity="0.5" />
              <circle cx="93" cy="78" r="8" fill="#FFF0C4" fillOpacity="0.7" />
              <circle cx="195" cy="178" r="8" fill="#FFF0C4" fillOpacity="0.7" />
              <circle cx="195" cy="78" r="5" fill="#8C1007" fillOpacity="0.7" />
              <circle cx="93" cy="178" r="5" fill="#8C1007" fillOpacity="0.7" />

              {/* Connecting lines */}
              <line x1="144" y1="128" x2="93" y2="78" stroke="#FFF0C4" strokeWidth="1.5" strokeOpacity="0.6" />
              <line x1="144" y1="128" x2="195" y2="178" stroke="#FFF0C4" strokeWidth="1.5" strokeOpacity="0.6" />
              <line x1="144" y1="128" x2="195" y2="78" stroke="#8C1007" strokeWidth="1" strokeOpacity="0.4" />
              <line x1="144" y1="128" x2="93" y2="178" stroke="#8C1007" strokeWidth="1" strokeOpacity="0.4" />

              {/* Bar chart mini illustration */}
              <rect x="58" y="190" width="14" height="30" rx="2" fill="#FFF0C4" fillOpacity="0.6" />
              <rect x="78" y="180" width="14" height="40" rx="2" fill="#FFF0C4" fillOpacity="0.6" />
              <rect x="98" y="170" width="14" height="50" rx="2" fill="#FFF0C4" fillOpacity="0.8" />
              <rect x="118" y="185" width="14" height="35" rx="2" fill="#a32218" fillOpacity="0.7" />
              <line x1="50" y1="180" x2="145" y2="180" stroke="#FFF0C4" strokeWidth="0.5" strokeDasharray="3 3" />

              {/* Attendance % text */}
              <text x="180" y="100" fill="#FFF0C4" fontSize="11" fontFamily="Inter">82.5%</text>
              <text x="178" y="114" fill="#FFF0C4" fontSize="9" fontFamily="Inter">Attendance</text>
            </svg>
          </div>
        </div>

        {/* Bottom stats */}
        <div className="flex gap-8 text-center">
          <div>
            <div className="text-[20px] font-bold text-primary-foreground">5,000+</div>
            <div className="text-[12px] text-primary-foreground/80">Students</div>
          </div>
          <div>
            <div className="text-[20px] font-bold text-primary-foreground">200+</div>
            <div className="text-[12px] text-primary-foreground/80">Courses</div>
          </div>
          <div>
            <div className="text-[20px] font-bold text-primary-foreground">98%</div>
            <div className="text-[12px] text-primary-foreground/80">Accuracy</div>
          </div>
        </div>
      </div>

      {/* Right Panel */}
      <div className="flex-1 bg-background flex items-center justify-center">
        <div className="w-[440px] bg-card rounded-[16px] border border-border shadow-[0_4px_24px_rgba(0,0,0,0.08)] p-12">
          <div className="mb-8">
            <h2 className="text-[28px] font-bold text-foreground">Welcome back</h2>
            <p className="text-[14px] text-muted-foreground mt-1">Sign in to your account</p>
          </div>

          {/* Role selector */}
          <div className="flex gap-2 mb-6">
            {(["Student", "Teacher", "Admin"] as const).map((r) => (
              <button
                key={r}
                onClick={() => setRole(r)}
                className="flex-1 py-2 px-4 rounded-full text-[13px] font-medium transition-all border"
                style={{
                  backgroundColor: role === r ? "var(--color-primary)" : "transparent",
                  color: role === r ? "var(--color-primary-foreground)" : "var(--color-foreground)",
                  borderColor: role === r ? "var(--color-primary)" : "var(--color-border)",
                }}
              >
                {r}
              </button>
            ))}
          </div>

          {/* Email */}
          <div className="mb-4">
            <label className="block text-[13px] font-medium text-foreground mb-1.5">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder={`${role.toLowerCase()}@college.edu`}
              className="w-full border border-border rounded-[6px] px-3 py-2.5 text-[14px] text-foreground placeholder-muted-foreground outline-none transition-colors focus:border-primary focus:ring-1 focus:ring-primary"
            />
          </div>

          {/* Password */}
          <div className="mb-2">
            <label className="block text-[13px] font-medium text-foreground mb-1.5">Password</label>
            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full border border-border rounded-[6px] px-3 py-2.5 pr-10 text-[14px] text-foreground outline-none transition-colors focus:border-primary focus:ring-1 focus:ring-primary"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              >
                {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
          </div>

          {/* Forgot password */}
          <div className="flex justify-end mb-6">
            <button className="text-[13px] text-primary hover:underline">Forgot password?</button>
          </div>

          {/* Error Message */}
          {errorText && (
            <div className="mb-4 text-[13px] text-red-500 bg-red-500/10 p-2 rounded border border-red-500/20 text-center">
              {errorText}
            </div>
          )}

          {/* Sign In Button */}
          <button
            onClick={handleSignIn}
            disabled={isSubmitting}
            className="w-full bg-primary flex items-center justify-center text-primary-foreground rounded-[6px] h-11 text-[14px] font-medium hover:bg-primary/90 transition-colors disabled:opacity-50"
          >
            {isSubmitting ? <Loader2 className="animate-spin" size={18} /> : "Sign In"}
          </button>

          {/* Footer */}
          <p className="text-center text-[13px] text-muted-foreground mt-6">
            Don't have an account?{" "}
            <span className="text-primary hover:underline cursor-pointer">Contact admin</span>
          </p>
        </div>
      </div>
    </div>
  );
}