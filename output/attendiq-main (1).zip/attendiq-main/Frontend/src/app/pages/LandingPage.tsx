import React from 'react';
import { Link } from 'react-router';
import { 
  CalendarDays, 
  LayoutDashboard, 
  BarChart2, 
  FileText, 
  History, 
  LogOut, 
  Bell, 
  Grid, 
  TrendingUp, 
  BriefcaseMedical, 
  CalendarClock, 
  Eye, 
  Brain, 
  Zap, 
  ArrowRight, 
  Link as LinkIcon, 
  Mail, 
  Share2 
} from 'lucide-react';

export default function LandingPage() {
  return (
    <div className="dark bg-[#221110] text-slate-100 font-['Inter',_sans-serif] selection:bg-[#8C1007] selection:text-white min-h-screen">
      {/* START SECTION 1 — NAVBAR */}
      
{/* SECTION 1 — NAVBAR */}
<nav className="sticky top-0 z-50 w-full bg-[#3f0703]/80 backdrop-blur-md border-b border-white/10">
<div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
<div className="flex items-center gap-2">
<CalendarDays className="text-[#8C1007]" size={32} />
<span className="text-[22px] font-bold text-[#FFF0C4] tracking-tight">AttendIQ</span>
</div>
<div className="hidden md:flex items-center gap-8">
<a className="text-[#FFF0C4]/70 hover:text-[#FFF0C4] text-sm font-medium transition-colors" href="#features">Features</a>
<a className="text-[#FFF0C4]/70 hover:text-[#FFF0C4] text-sm font-medium transition-colors" href="#how-it-works">How It Works</a>
<a className="text-[#FFF0C4]/70 hover:text-[#FFF0C4] text-sm font-medium transition-colors" href="#benefits">Benefits</a>
<a className="text-[#FFF0C4]/70 hover:text-[#FFF0C4] text-sm font-medium transition-colors" href="#contact">Contact</a>
</div>
<div className="flex items-center gap-4">
<Link to="/login" className="text-[#FFF0C4]/80 hover:text-[#FFF0C4] text-sm font-bold px-4 py-2 transition-all">Sign In</Link>
<Link to="/login" className="bg-[#8C1007] hover:bg-red-700 text-[#FFF0C4] text-sm font-bold px-6 py-2.5 rounded-lg transition-all shadow-lg shadow-black/20">Get Started</Link>
</div>
</div>
</nav>
{/* SECTION 2 — HERO */}
<section className="relative overflow-hidden bg-gradient-to-br from-[#3f0703] to-[#660B05] py-24 md:py-32">
<div className="max-w-7xl mx-auto px-6 grid lg:grid-cols-2 gap-16 items-center">
<div className="flex flex-col gap-8">
<div className="inline-flex items-center bg-white/10 border border-white/20 rounded-full px-4 py-1.5 w-fit">
<span className="text-[#FFF0C4] text-xs font-bold tracking-widest uppercase">Built for University Students</span>
</div>
<h1 className="text-5xl md:text-7xl font-black text-[#FFF0C4] leading-[1.1] tracking-tight">
                    Smarter Attendance Management
                </h1>
<p className="text-xl text-[#FFF0C4]/80 max-w-xl leading-relaxed">
                    Track your daily lectures, predict future attendance impacts, and manage medical leaves seamlessly with AttendIQ.
                </p>
<div className="flex flex-wrap gap-6 py-4">
<div className="flex flex-col">
<span className="text-[#FFF0C4] text-2xl font-bold">75% Rule</span>
<span className="text-[#FFF0C4]/60 text-sm">Enforced Daily</span>
</div>
<div className="w-px h-12 bg-white/20"></div>
<div className="flex flex-col">
<span className="text-[#FFF0C4] text-2xl font-bold">10k+</span>
<span className="text-[#FFF0C4]/60 text-sm">Active Students</span>
</div>
<div className="w-px h-12 bg-white/20"></div>
<div className="flex flex-col">
<span className="text-[#FFF0C4] text-2xl font-bold">99.9%</span>
<span className="text-[#FFF0C4]/60 text-sm">Accuracy</span>
</div>
</div>
<div className="flex flex-wrap gap-4 pt-4">
<button className="bg-[#8C1007] text-[#FFF0C4] font-bold px-8 py-4 rounded-xl text-lg hover:scale-105 transition-transform shadow-xl">Get Started Now</button>
<button className="bg-white/10 text-[#FFF0C4] font-bold px-8 py-4 rounded-xl text-lg hover:bg-white/20 transition-all border border-white/10">Watch Demo</button>
</div>
</div>
{/* Dashboard Mockup - Pixel Perfect Light Theme */}
<div className="relative group w-full lg:w-[130%] max-w-[950px] mx-auto z-10 mt-8 lg:mt-0 lg:-ml-12 shadow-[0_0_80px_rgba(140,16,7,0.3)]">
  <div className="absolute -inset-0.5 bg-[#FFF0C4]/10 rounded-2xl blur-2xl opacity-80 group-hover:opacity-100 transition duration-1000"></div>
  <div className="relative bg-[#fdf3da] rounded-xl border border-[#3f0703]/10 overflow-hidden flex w-full h-[550px] shadow-2xl">
    
    {/* Mini Sidebar */}
    <div className="w-16 md:w-32 border-r border-[#3f0703]/10 flex flex-col items-center py-6 gap-2 flex-shrink-0 bg-[#590d06]">
      <div className="w-full px-4 flex flex-col items-start mb-6">
         <div className="text-white font-black text-sm md:text-lg leading-none">AttendIQ</div>
         <div className="text-white/80 font-medium text-[8px] md:text-[10px] mt-0.5">Student Portal</div>
      </div>

      <div className="w-[90%] bg-[#fdf3da] rounded-md flex items-center justify-start px-3 py-2.5 shadow-sm text-[#3f0703] cursor-pointer mb-2">
        <LayoutDashboard className="mr-2 text-[#8C1007]" size={16} />
        <span className="text-[10px] md:text-xs font-bold hidden md:block">Dashboard</span>
      </div>

      <div className="w-[90%] flex items-center justify-start px-3 py-2.5 text-white/70 hover:text-white cursor-pointer transition-colors">
        <BarChart2 className="mr-2" size={16} />
        <span className="text-[10px] md:text-xs font-medium hidden md:block text-shadow-sm">Predict Leave</span>
      </div>
      <div className="w-[90%] flex items-center justify-start px-3 py-2.5 text-white/70 hover:text-white cursor-pointer transition-colors">
        <FileText className="mr-2" size={16} />
        <span className="text-[10px] md:text-xs font-medium hidden md:block text-shadow-sm">Apply Leave</span>
      </div>
      <div className="w-[90%] flex items-center justify-start px-3 py-2.5 text-white/70 hover:text-white cursor-pointer transition-colors">
        <History className="mr-2" size={16} />
        <span className="text-[10px] md:text-xs font-medium hidden md:block text-shadow-sm">Leave History</span>
      </div>
      <div className="w-[90%] flex items-center justify-start px-3 py-2.5 text-white/70 hover:text-white cursor-pointer transition-colors">
        <CalendarDays className="mr-2" size={16} />
        <span className="text-[10px] md:text-xs font-medium hidden md:block text-shadow-sm">Timetable</span>
      </div>

      <div className="mt-auto w-full border-t border-white/10 pt-4 px-4 pb-2">
         <div className="flex items-center gap-2">
             <div className="size-6 md:size-8 rounded-full bg-[#8C1007] text-[#FFF0C4] flex items-center justify-center text-[9px] md:text-[11px] font-bold border border-white/20">RS</div>
             <div className="hidden md:flex flex-col">
                <span className="text-white text-[10px] font-bold leading-none mb-0.5">Rahul Sharma</span>
                <span className="text-white/60 text-[8px]">Student • CS2301</span>
             </div>
         </div>
         <div className="text-white/60 text-[9px] mt-4 flex items-center gap-1.5 cursor-pointer hover:text-white transition-colors"><LogOut size={12} /> Sign out</div>
      </div>
    </div>

    {/* Content Area */}
    <div className="flex-1 bg-[#fdf3da] flex flex-col p-6 overflow-hidden gap-5 hidden-scrollbar overflow-y-auto">
        {/* Top Header */}
        <div className="flex justify-between items-center bg-white shadow-[0_2px_10px_rgba(0,0,0,0.03)] px-6 py-3 rounded-lg border border-[#3f0703]/5 -mt-2 -mx-2 mb-1">
            <h2 className="text-[#3f0703] font-bold text-sm">Dashboard</h2>
            <div className="flex gap-4 items-center">
                <Bell className="text-[#3f0703]/60 cursor-pointer hover:text-[#3f0703] transition-colors" size={20} />
                <div className="size-6 rounded-full bg-[#590d06] text-[#FFF0C4] flex items-center justify-center text-[9px] font-bold shadow-sm">RS</div>
            </div>
        </div>

        {/* Top Cards Row */}
        <div className="grid grid-cols-4 gap-4 h-[85px]">
            {/* Card 1 */}
            <div className="bg-white rounded-lg border border-[rgba(63,7,3,0.08)] p-3 pb-2 flex flex-col justify-center shadow-[0_2px_8px_rgba(0,0,0,0.02)] border-l-[3px] border-l-[#8C1007]">
                <p className="text-[#3f0703]/60 text-[8px] font-bold uppercase tracking-wider mb-1">Overall Attendance</p>
                <p className="text-[#8C1007] font-black text-[28px] leading-none mb-1">82.5%</p>
                <p className="text-[#3f0703]/40 text-[8px] font-medium leading-none mt-auto">Above 75% threshold</p>
            </div>
             {/* Card 2 */}
            <div className="bg-white rounded-lg border border-[rgba(63,7,3,0.08)] p-3 pb-2 flex flex-col justify-center shadow-[0_2px_8px_rgba(0,0,0,0.02)] border-l-[3px] border-l-[#8C1007]">
                <p className="text-[#3f0703]/60 text-[8px] font-bold uppercase tracking-wider mb-1">Total Classes</p>
                <p className="text-[#3f0703] font-black text-[28px] leading-none mb-1">240</p>
                <p className="text-[#3f0703]/40 text-[8px] font-medium leading-none mt-auto">This semester</p>
            </div>
             {/* Card 3 */}
            <div className="bg-white rounded-lg border border-[rgba(63,7,3,0.08)] p-3 pb-2 flex flex-col justify-center shadow-[0_2px_8px_rgba(0,0,0,0.02)] border-l-[3px] border-l-[#8C1007]">
                <p className="text-[#3f0703]/60 text-[8px] font-bold uppercase tracking-wider mb-1">Classes Attended</p>
                <p className="text-[#3f0703] font-black text-[28px] leading-none mb-1">198</p>
                <p className="text-[#3f0703]/40 text-[8px] font-medium leading-none mt-auto">Out of 240 classes</p>
            </div>
            {/* Card 4 */}
            <div className="bg-white rounded-lg border border-[rgba(63,7,3,0.08)] p-3 pb-2 flex flex-col justify-center shadow-[0_2px_8px_rgba(0,0,0,0.02)] border-l-[3px] border-l-[#8C1007]">
                <p className="text-[#3f0703]/60 text-[8px] font-bold uppercase tracking-wider mb-1">Subjects Enrolled</p>
                <p className="text-[#3f0703] font-black text-[28px] leading-none mb-1">6</p>
                <p className="text-[#3f0703]/40 text-[8px] font-medium leading-none mt-auto">Semester 5</p>
            </div>
        </div>

        {/* Main Content Split */}
        <div className="flex gap-4 flex-1 overflow-hidden min-h-[220px]">
            {/* Left: Table */}
            <div className="flex-[2] bg-white rounded-lg border border-[rgba(63,7,3,0.08)] flex flex-col shadow-[0_2px_8px_rgba(0,0,0,0.02)]">
                <div className="px-5 py-3 border-b border-[rgba(63,7,3,0.04)]">
                    <h3 className="text-[#3f0703] font-bold text-[11px]">Subject-wise Attendance</h3>
                </div>
                <div className="flex-1 flex flex-col">
                    {/* Header */}
                    <div className="grid grid-cols-6 bg-[#590d06] text-[#FFF0C4] px-5 py-2.5 text-[7px] font-bold tracking-wider uppercase items-center">
                        <div className="col-span-2">Subject Name</div>
                        <div className="text-center">Code</div>
                        <div className="text-center">Conducted</div>
                        <div className="text-center">Attended</div>
                        <div className="text-center">Percentage</div>
                        <div className="text-center">Status</div>
                    </div>
                    {/* Rows */}
                    <div className="flex flex-col justify-between flex-1 px-5 py-1">
                        {[
                            { name: 'Data Structures', code: 'CS301', cond: 45, att: 40, perc: '88.9%', status: 'SAFE', color: 'bg-[#e5f5e9] text-[#1e8b41]' },
                            { name: 'Networks', code: 'CS302', cond: 40, att: 32, perc: '80%', status: 'SAFE', color: 'bg-[#e5f5e9] text-[#1e8b41]' },
                            { name: 'Operating Systems', code: 'CS303', cond: 42, att: 30, perc: '71.4%', status: 'WARNING', color: 'bg-[#fff5d0] text-[#b38800]' },
                            { name: 'DBMS', code: 'CS304', cond: 38, att: 25, perc: '65.8%', status: 'CRITICAL', color: 'bg-[#ffebee] text-[#d32f2f]' },
                            { name: 'Software Engg.', code: 'CS305', cond: 36, att: 30, perc: '83.3%', status: 'SAFE', color: 'bg-[#e5f5e9] text-[#1e8b41]' },
                            { name: 'Machine Learning', code: 'CS306', cond: 40, att: 28, perc: '70%', status: 'WARNING', color: 'bg-[#fff5d0] text-[#b38800]' },
                        ].map((row, i) => (
                            <div key={i} className="grid grid-cols-6 items-center text-[9px] text-[#3f0703]/80 border-b border-[rgba(63,7,3,0.03)] pb-2 pt-2 last:border-0">
                                <div className="col-span-2 font-medium text-[#3f0703]">{row.name}</div>
                                <div className="text-center">{row.code}</div>
                                <div className="text-center">{row.cond}</div>
                                <div className="text-center">{row.att}</div>
                                <div className="text-center font-bold text-[#3f0703]">{row.perc}</div>
                                <div className="text-center flex justify-center">
                                    <span className={`text-[7px] font-bold px-3 py-1 rounded-full ${row.color} leading-none`}>{row.status}</span>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            {/* Right: Charts */}
            <div className="flex-1 flex flex-col gap-4">
                {/* Bar Chart Card */}
                <div className="bg-white rounded-lg border border-[rgba(63,7,3,0.08)] p-4 shadow-[0_2px_8px_rgba(0,0,0,0.02)] flex-1 flex flex-col justify-between">
                    <div className="mb-2">
                        <h3 className="text-[#3f0703] font-bold text-[11px]">Attendance Overview</h3>
                    </div>
                    {/* Horizontal Bar Chart representation */}
                    <div className="flex flex-col gap-1.5 w-full relative">
                       {/* 75% red line */}
                       <div className="absolute top-0 bottom-3 right-[25%] w-px border-r border-dashed border-[#d32f2f] z-0"></div>
                       {/* Bars */}
                       {[88, 90, 75, 85, 95, 70].map((w, i) => (
                           <div key={i} className="flex items-center gap-2 z-10 w-full">
                               <span className="text-[7px] text-[#3f0703]/40 font-medium w-6">CS30{i+1}</span>
                               <div className="flex-1 h-[6px] bg-[#3f0703]/5 rounded-sm overflow-hidden flex w-full">
                                   <div className="bg-[#8C1007] h-full rounded-sm" style={{ width: `${w}%` }}></div>
                               </div>
                           </div>
                       ))}
                       {/* Axis */}
                       <div className="flex justify-between text-[6px] text-[#3f0703]/30 pl-8 pr-1 font-bold mt-1">
                           <span>0</span><span>25</span><span>50</span><span>75</span><span>100</span>
                       </div>
                    </div>
                </div>

                {/* Line Chart Card */}
                <div className="bg-white rounded-lg border border-[rgba(63,7,3,0.08)] p-4 shadow-[0_2px_8px_rgba(0,0,0,0.02)] flex-[0.8] flex flex-col justify-between">
                     <div className="mb-2">
                        <h3 className="text-[#3f0703] font-bold text-[11px]">Attendance Trend</h3>
                        <p className="text-[#3f0703]/40 text-[8px] font-medium leading-tight">CS301 — Last 30 days</p>
                    </div>
                    {/* Stylized SVG Line Chart */}
                    <div className="w-full relative flex-1 border-l border-b border-[rgba(63,7,3,0.06)] flex items-end px-1 pb-1 ml-4 mt-2">
                        {/* 75% dashed line */}
                        <div className="absolute top-[50%] left-0 w-full border-t border-dashed border-[#d32f2f]/60"> <span className="absolute -right-3 -top-1.5 text-[6px] text-[#d32f2f] font-bold">75</span></div>
                        <svg viewBox="0 0 100 40" className="w-full h-full overflow-visible" preserveAspectRatio="none">
                            <path d="M0,30 C5,10 10,40 20,20 C30,30 40,20 50,30 C60,10 70,30 80,25 C90,20 95,10 100,15" fill="none" stroke="#8C1007" strokeWidth="1.5" />
                        </svg>
                        {/* Y Axis */}
                        <div className="absolute -left-4 -bottom-1 flex flex-col justify-between h-full text-[6px] text-[#3f0703]/30 py-1 font-bold items-end w-3">
                            <span>100</span><span>80</span><span>65</span><span>50</span>
                        </div>
                        {/* X Axis */}
                        <div className="absolute left-1 -bottom-3.5 flex justify-between w-[95%] text-[6px] text-[#3f0703]/30 font-bold">
                             <span>1</span><span>11</span><span>21</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        {/* Bottom Wide Card (Heatmap) */}
        <div className="bg-white rounded-lg border border-[rgba(63,7,3,0.08)] shadow-[0_2px_8px_rgba(0,0,0,0.02)] flex flex-col pt-4 pb-4 px-6 flex-shrink-0 items-center justify-center mt-auto mb-2">
             <h3 className="text-[#3f0703] font-bold text-xs mb-4">Visualize Your Academic Activity</h3>
             
             {/* Simple visual representation of heatmap */}
             <div className="flex flex-col items-center w-full max-w-[500px]">
                 {/* Months */}
                 <div className="flex text-[7px] text-[#3f0703]/40 w-full mb-1.5 justify-between px-2 font-bold uppercase tracking-wider">
                     <span>Apr</span><span>May</span><span>Jun</span><span>Jul</span><span>Aug</span><span>Sep</span><span>Oct</span><span>Nov</span><span>Dec</span><span>Jan</span><span>Feb</span><span>Mar</span>
                 </div>
                 {/* Grid */}
                 <div className="flex gap-[2px] w-full justify-between">
                     {/* Just creating a pattern of blocks */}
                     {Array.from({length: 45}).map((_, colIdx) => (
                         <div key={colIdx} className="flex flex-col gap-[2px]">
                             {Array.from({length: 5}).map((_, rowIdx) => {
                                 // Randomize opacity/color based on a math formula to look like a chart
                                 const val = Math.sin(colIdx * 0.4) * Math.cos(rowIdx * 0.6) + Math.sin(colIdx * 0.1);
                                 let color = 'bg-[#fff5d0]';
                                 if (val > 0.6) color = 'bg-[#590d06]';
                                 else if (val > 0.2) color = 'bg-[#8C1007]';
                                 else if (val > -0.3) color = 'bg-[#c23f18]';
                                 else if (val > -0.7) color = 'bg-[#e79f42]';
                                 
                                 return <div key={rowIdx} className={`w-[8px] h-[8px] md:w-[10px] md:h-[10px] ${color} rounded-[1px]`}></div>
                             })}
                         </div>
                     ))}
                 </div>

                 {/* Legend */}
                 <div className="flex items-center justify-end w-full gap-2 mt-4 pr-2">
                    <span className="text-[6px] uppercase font-bold text-[#3f0703]/40 tracking-wider">Less Active</span>
                    <div className="flex gap-1">
                        <div className="w-2 h-2 bg-[#fff5d0] rounded-[1px]"></div>
                        <div className="w-2 h-2 bg-[#e79f42] rounded-[1px]"></div>
                        <div className="w-2 h-2 bg-[#c23f18] rounded-[1px]"></div>
                        <div className="w-2 h-2 bg-[#8C1007] rounded-[1px]"></div>
                        <div className="w-2 h-2 bg-[#590d06] rounded-[1px]"></div>
                    </div>
                    <span className="text-[6px] uppercase font-bold text-[#3f0703]/40 tracking-wider">Highly Active</span>
                 </div>
             </div>
        </div>

    </div>
  </div>
</div>
</div>
</section>
{/* SECTION 3 — FEATURES */}
<section className="py-24 bg-[#FFF0C4]" id="features">
<div className="max-w-7xl mx-auto px-6">
<div className="text-center mb-20 flex flex-col gap-4">
<h2 className="text-4xl md:text-5xl font-black text-[#3f0703] tracking-tight">Everything You Need to Manage Attendance</h2>
<p className="text-[#3f0703]/70 text-lg max-w-2xl mx-auto">A powerful suite of tools designed to ensure you never fall below the threshold while maintaining academic excellence.</p>
</div>
<div className="grid md:grid-cols-2 gap-8">
{/* Card 1 */}
<div className="bg-white p-8 rounded-xl shadow-xl shadow-[#3f0703]/5 flex gap-6 hover:translate-y-[-4px] transition-transform">
<div className="bg-[#8C1007]/10 size-14 rounded-xl flex items-center justify-center flex-shrink-0">
<LayoutDashboard className="text-[#8C1007]" size={30} />
</div>
<div>
<h3 className="text-xl font-bold text-[#3f0703] mb-2">Attendance Dashboard</h3>
<p className="text-slate-600 leading-relaxed">Real-time tracking of your presence across all subjects with visual progress indicators.</p>
</div>
</div>
{/* Card 2 */}
<div className="bg-white p-8 rounded-xl shadow-xl shadow-[#3f0703]/5 flex gap-6 hover:translate-y-[-4px] transition-transform">
<div className="bg-[#8C1007]/10 size-14 rounded-xl flex items-center justify-center flex-shrink-0">
<TrendingUp className="text-[#8C1007]" size={30} />
</div>
<div>
<h3 className="text-xl font-bold text-[#3f0703] mb-2">Attendance Prediction</h3>
<p className="text-slate-600 leading-relaxed">AI-powered insights that predict your future percentage based on upcoming schedule and leave plans.</p>
</div>
</div>
{/* Card 3 */}
<div className="bg-white p-8 rounded-xl shadow-xl shadow-[#3f0703]/5 flex gap-6 hover:translate-y-[-4px] transition-transform">
<div className="bg-[#8C1007]/10 size-14 rounded-xl flex items-center justify-center flex-shrink-0">
<BriefcaseMedical className="text-[#8C1007]" size={30} />
</div>
<div>
<h3 className="text-xl font-bold text-[#3f0703] mb-2">Smart Leave Management</h3>
<p className="text-slate-600 leading-relaxed">Submit medical and duty leave requests digitally. Track approval status from teachers in real-time.</p>
</div>
</div>
{/* Card 4 */}
<div className="bg-white p-8 rounded-xl shadow-xl shadow-[#3f0703]/5 flex gap-6 hover:translate-y-[-4px] transition-transform">
<div className="bg-[#8C1007]/10 size-14 rounded-xl flex items-center justify-center flex-shrink-0">
<CalendarClock className="text-[#8C1007]" size={30} />
</div>
<div>
<h3 className="text-xl font-bold text-[#3f0703] mb-2">Timetable Integration</h3>
<p className="text-slate-600 leading-relaxed">Seamlessly syncs with your university's weekly schedule to automatically generate daily logs.</p>
</div>
</div>
</div>
</div>
</section>
{/* SECTION 4 — VISUALIZATION (Heatmap) */}
<section className="py-24 bg-[#3f0703] text-[#FFF0C4] overflow-hidden">
<div className="max-w-7xl mx-auto px-6 text-center">
<h2 className="text-3xl md:text-5xl font-black mb-12">Visualize Your Academic Activity</h2>
<div className="bg-[#1a0201] p-10 rounded-2xl border border-white/5 inline-block mx-auto max-w-full overflow-x-auto">
<div className="heatmap-grid w-[600px] md:w-[800px]">
{/* JS could generate this, but we'll hardcode squares with different opacity for visual effect */}
{/* Repeat squares to fill 12x12 approximately */}
<div className="heatmap-square bg-[#660B05]"></div>
<div className="heatmap-square bg-[#8C1007]"></div>
<div className="heatmap-square bg-[#FFF0C4]/10"></div>
<div className="heatmap-square bg-[#8C1007] opacity-60"></div>
<div className="heatmap-square bg-[#FFF0C4]"></div>
<div className="heatmap-square bg-[#8C1007]"></div>
<div className="heatmap-square bg-[#660B05] opacity-50"></div>
<div className="heatmap-square bg-[#8C1007]"></div>
<div className="heatmap-square bg-[#FFF0C4] opacity-80"></div>
<div className="heatmap-square bg-[#8C1007] opacity-20"></div>
<div className="heatmap-square bg-[#660B05]"></div>
<div className="heatmap-square bg-[#8C1007]"></div>
{/* Simulating many rows */}
<div className="heatmap-square bg-[#8C1007]"></div><div className="heatmap-square bg-[#FFF0C4]"></div><div className="heatmap-square bg-[#8C1007] opacity-40"></div><div className="heatmap-square bg-[#660B05]"></div><div className="heatmap-square bg-[#8C1007]"></div><div className="heatmap-square bg-[#FFF0C4]/10"></div><div className="heatmap-square bg-[#8C1007]"></div><div className="heatmap-square bg-[#FFF0C4]"></div><div className="heatmap-square bg-[#8C1007]"></div><div className="heatmap-square bg-[#660B05]"></div><div className="heatmap-square bg-[#8C1007] opacity-70"></div><div className="heatmap-square bg-[#FFF0C4]"></div>
<div className="heatmap-square bg-[#660B05]"></div><div className="heatmap-square bg-[#8C1007]"></div><div className="heatmap-square bg-[#FFF0C4]"></div><div className="heatmap-square bg-[#8C1007]"></div><div className="heatmap-square bg-[#FFF0C4]/20"></div><div className="heatmap-square bg-[#8C1007]"></div><div className="heatmap-square bg-[#660B05]"></div><div className="heatmap-square bg-[#8C1007] opacity-60"></div><div className="heatmap-square bg-[#8C1007]"></div><div className="heatmap-square bg-[#FFF0C4]"></div><div className="heatmap-square bg-[#8C1007] opacity-30"></div><div className="heatmap-square bg-[#660B05]"></div>
<div className="heatmap-square bg-[#8C1007]"></div><div className="heatmap-square bg-[#FFF0C4]"></div><div className="heatmap-square bg-[#8C1007]"></div><div className="heatmap-square bg-[#660B05] opacity-80"></div><div className="heatmap-square bg-[#8C1007]"></div><div className="heatmap-square bg-[#FFF0C4]"></div><div className="heatmap-square bg-[#8C1007] opacity-50"></div><div className="heatmap-square bg-[#8C1007]"></div><div className="heatmap-square bg-[#FFF0C4] opacity-20"></div><div className="heatmap-square bg-[#8C1007]"></div><div className="heatmap-square bg-[#660B05]"></div><div className="heatmap-square bg-[#FFF0C4]"></div>
{/* Additional rows for density... */}
</div>
<div className="mt-8 flex items-center justify-end gap-2 text-xs text-[#FFF0C4]/40 uppercase tracking-widest font-bold">
<span>Less Active</span>
<div className="flex gap-1">
<div className="size-3 rounded-sm bg-[#660B05]"></div>
<div className="size-3 rounded-sm bg-[#8C1007] opacity-60"></div>
<div className="size-3 rounded-sm bg-[#8C1007]"></div>
<div className="size-3 rounded-sm bg-[#FFF0C4] opacity-70"></div>
<div className="size-3 rounded-sm bg-[#FFF0C4]"></div>
</div>
<span>Highly Active</span>
</div>
</div>
</div>
</section>
{/* SECTION 5 — HOW IT WORKS */}
<section className="py-24 bg-[#FFF0C4]" id="how-it-works">
<div className="max-w-7xl mx-auto px-6">
<h2 className="text-4xl font-black text-[#3f0703] text-center mb-20 tracking-tight">How It Works</h2>
<div className="relative grid md:grid-cols-4 gap-8">
{/* Dashed Connector */}
<div className="hidden md:block absolute top-1/4 left-0 w-full h-0.5 border-t-2 border-dashed border-[#3f0703]/20 -z-0"></div>
<div className="relative flex flex-col items-center text-center gap-4 bg-[#FFF0C4] z-10">
<div className="size-16 rounded-full bg-[#3f0703] text-[#FFF0C4] flex items-center justify-center text-2xl font-bold border-4 border-[#FFF0C4]">1</div>
<h3 className="text-xl font-bold text-[#3f0703]">View Attendance</h3>
<p className="text-slate-600 text-sm">Access your current semester data instantly.</p>
</div>
<div className="relative flex flex-col items-center text-center gap-4 bg-[#FFF0C4] z-10">
<div className="size-16 rounded-full bg-[#3f0703] text-[#FFF0C4] flex items-center justify-center text-2xl font-bold border-4 border-[#FFF0C4]">2</div>
<h3 className="text-xl font-bold text-[#3f0703]">Predict Impact</h3>
<p className="text-slate-600 text-sm">Simulate leaves to see future percentage.</p>
</div>
<div className="relative flex flex-col items-center text-center gap-4 bg-[#FFF0C4] z-10">
<div className="size-16 rounded-full bg-[#3f0703] text-[#FFF0C4] flex items-center justify-center text-2xl font-bold border-4 border-[#FFF0C4]">3</div>
<h3 className="text-xl font-bold text-[#3f0703]">Apply for Leave</h3>
<p className="text-slate-600 text-sm">Submit digital forms for medical reasons.</p>
</div>
<div className="relative flex flex-col items-center text-center gap-4 bg-[#FFF0C4] z-10">
<div className="size-16 rounded-full bg-[#3f0703] text-[#FFF0C4] flex items-center justify-center text-2xl font-bold border-4 border-[#FFF0C4]">4</div>
<h3 className="text-xl font-bold text-[#3f0703]">Teacher Approval</h3>
<p className="text-slate-600 text-sm">Faculty reviews and updates your logs.</p>
</div>
</div>
</div>
</section>
{/* SECTION 6 — BENEFITS */}
<section className="py-24 bg-[#660B05] text-[#FFF0C4]" id="benefits">
<div className="max-w-7xl mx-auto px-6 grid md:grid-cols-3 gap-12">
<div className="flex flex-col gap-4 p-8 border border-white/10 rounded-2xl bg-white/5">
<Eye className="text-[#8C1007]" size={36} />
<h3 className="text-2xl font-bold">Improved Transparency</h3>
<p className="text-[#FFF0C4]/70 leading-relaxed">No more surprises at the end of the semester. Both students and teachers see the same numbers.</p>
</div>
<div className="flex flex-col gap-4 p-8 border border-white/10 rounded-2xl bg-white/5">
<Brain className="text-[#8C1007]" size={36} />
<h3 className="text-2xl font-bold">Better Decision Making</h3>
<p className="text-[#FFF0C4]/70 leading-relaxed">Plan your activities and leaves based on hard data rather than rough estimations.</p>
</div>
<div className="flex flex-col gap-4 p-8 border border-white/10 rounded-2xl bg-white/5">
<Zap className="text-[#8C1007]" size={36} />
<h3 className="text-2xl font-bold">Reduced Admin Work</h3>
<p className="text-[#FFF0C4]/70 leading-relaxed">Automate the tedious process of leave approvals and daily manual attendance entries.</p>
</div>
</div>
</section>
{/* SECTION 7 — FUTURE VISION */}
<section className="py-24 bg-[#3f0703] text-[#FFF0C4]">
<div className="max-w-7xl mx-auto px-6 text-center flex flex-col gap-10">
<h2 className="text-4xl font-black">Built for the Future...</h2>
<div className="flex flex-wrap justify-center gap-4">
<span className="px-8 py-3 rounded-full border border-[#8C1007] bg-[#8C1007]/10 text-lg font-medium">ERP Integration</span>
<span className="px-8 py-3 rounded-full border border-[#8C1007] bg-[#8C1007]/10 text-lg font-medium">Native Mobile App</span>
<span className="px-8 py-3 rounded-full border border-[#8C1007] bg-[#8C1007]/10 text-lg font-medium">AI Behavior Insights</span>
<span className="px-8 py-3 rounded-full border border-[#8C1007] bg-[#8C1007]/10 text-lg font-medium">Multi-Campus Support</span>
</div>
<div className="h-64 mt-10 rounded-2xl overflow-hidden grayscale opacity-30 hover:grayscale-0 hover:opacity-100 transition-all duration-700 bg-center bg-cover border border-white/10" data-alt="University students working together in a high tech library" style={{ backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuAXoKFdBVksAzwoKziBOU5yMODQQK8A22fW_-HTYGrelOFxZWyMcYeG21lX_5HvX_9VpjpxVGA8cJ8K9m71sKjP0y2UR1M41UmKtyucXxL-2AigIrUaJWEM0QHEicEk5jIYfH0tl1BvXGWCDowKmV0QANkYAZ-BmMDSlKp5hMIz0DEtEDXa_aMd4rHzi7_K2OEuIM-lzO7N4KWvnfZM7M0UAMnETAmX9Nh6Iub9yT7QErvkwrTiIB_KZDkVp2RyzGjkSxZpqV_y2aU')" }}></div>
</div>
</section>
{/* SECTION 8 — CTA */}
<section className="py-24 px-6">
<div className="max-w-5xl mx-auto rounded-[2.5rem] py-20 px-10 text-center flex flex-col items-center gap-8 shadow-2xl" style={{ backgroundImage: 'radial-gradient(circle at center, #8C1007, #3f0703, #3f0703)' }}>
<h2 className="text-4xl md:text-5xl font-black text-[#FFF0C4] max-w-2xl leading-tight tracking-tight">Take Control of Your Academic Attendance</h2>
<p className="text-[#FFF0C4]/80 text-xl">Join thousands of students who never miss a credit again.</p>
<button className="bg-[#FFF0C4] text-[#3f0703] font-black px-10 py-5 rounded-xl text-lg hover:scale-105 transition-transform flex items-center gap-3">
                Start Managing Attendance <ArrowRight size={24} />
</button>
</div>
</section>
{/* SECTION 9 — FOOTER */}
<footer className="bg-[#3f0703] pt-20 pb-10 border-t border-white/5">
<div className="max-w-7xl mx-auto px-6 grid md:grid-cols-3 gap-16 mb-20">
<div className="flex flex-col gap-6">
<div className="flex items-center gap-2">
<CalendarDays className="text-[#8C1007]" size={32} />
<span className="text-[22px] font-bold text-[#FFF0C4] tracking-tight">AttendIQ</span>
</div>
<p className="text-[#FFF0C4]/50 leading-relaxed">Empowering university students with data-driven tools to manage their academic lifecycle efficiently.</p>
</div>
<div className="flex flex-col gap-4">
<h4 className="text-[#FFF0C4] font-bold text-lg">Academic Project</h4>
<p className="text-[#FFF0C4]/50 text-sm italic">Developed as part of the CEP Academic Curriculum for Modern Software Engineering.</p>
<div className="flex gap-4 mt-4 text-[#FFF0C4]/70 underline">
<a href="#">Documentation</a>
<a href="#">Resources</a>
</div>
</div>
<div className="flex flex-col gap-6 items-start md:items-end">
<h4 className="text-[#FFF0C4] font-bold text-lg">Connect</h4>
<div className="flex gap-4">
<a className="size-10 rounded-full bg-white/5 flex items-center justify-center text-[#FFF0C4] hover:bg-[#8C1007] transition-colors" href="#">
<LinkIcon size={20} />
</a>
<a className="size-10 rounded-full bg-white/5 flex items-center justify-center text-[#FFF0C4] hover:bg-[#8C1007] transition-colors" href="#">
<Mail size={20} />
</a>
<a className="size-10 rounded-full bg-white/5 flex items-center justify-center text-[#FFF0C4] hover:bg-[#8C1007] transition-colors" href="#">
<Share2 size={20} />
</a>
</div>
<p className="text-[#FFF0C4]/40 text-xs">Built with Tailwind CSS &amp; Material Symbols</p>
</div>
</div>
<div className="max-w-7xl mx-auto px-6 pt-10 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-4">
<p className="text-[#FFF0C4]/30 text-xs">© 2024 AttendIQ. All rights reserved.</p>
<div className="flex gap-8 text-[#FFF0C4]/30 text-xs uppercase tracking-widest font-bold">
<a className="hover:text-[#FFF0C4]" href="#">Privacy</a>
<a className="hover:text-[#FFF0C4]" href="#">Terms</a>
<a className="hover:text-[#FFF0C4]" href="#">Security</a>
</div>
</div>
</footer>

    </div>
  );
}
