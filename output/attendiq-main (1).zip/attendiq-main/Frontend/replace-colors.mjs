import fs from 'fs';
import path from 'path';

const dir = 'm:/Finalize app concept/src';

const replacements = [
  // Fix leftover arbitrary tailwind classes like bg-[#1A73E8]
  { from: /\[#E5E7EB\]/g, to: 'border' },
  { from: /\[#1A73E8\]/g, to: 'primary' },
  { from: /\[#1557b0\]/g, to: 'primary/90' },
  { from: /\[#EBF3FE\]/g, to: 'primary/10' },
  { from: /\[#F0F7FF\]/g, to: 'primary/5' },
  { from: /\[#DC2626\]/g, to: 'destructive' },
  { from: /\[#FEE2E2\]/g, to: 'destructive/20' },
  { from: /\[#16A34A\]/g, to: 'green-600' },
  { from: /\[#DCFCE7\]/g, to: 'green-100' },
  { from: /\[#F0FDF4\]/g, to: 'green-50' },
  { from: /\[#D97706\]/g, to: 'amber-600' },
  { from: /\[#FEF3C7\]/g, to: 'amber-100' },
  { from: /\[#374151\]/g, to: 'foreground' },
  { from: /\[#6B7280\]/g, to: 'muted-foreground' },
  { from: /\[#1A1A2E\]/g, to: 'secondary' },

  // Fix strings with hex codes
  { from: /border: "1px solid #E5E7EB"/g, to: 'border: "1px solid var(--border)"' },
  { from: /stroke="#E5E7EB"/g, to: 'stroke="var(--border)"' },
  { from: /["']#1A73E8["']/g, to: '`var(--primary)`' },
  { from: /["']#DC2626["']/g, to: '`var(--destructive)`' },
  { from: /["']#16A34A["']/g, to: '`#16a34a`' },
  { from: /["']#D97706["']/g, to: '`#d97706`' },
  { from: /["']#FFFFFF["']/g, to: '`var(--card)`' },
  { from: /["']#F8F9FA["']/g, to: '`transparent`' },
  { from: /["']#374151["']/g, to: '`var(--foreground)`' },
  { from: /["']#6B7280["']/g, to: '`var(--muted-foreground)`' },
  { from: /fill="\#1A73E8"/g, to: 'fill="var(--primary)"' },
  { from: /fill="\#DC2626"/g, to: 'fill="var(--destructive)"' },
];

function processDir(currentPath) {
  const entries = fs.readdirSync(currentPath, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(currentPath, entry.name);
    if (entry.isDirectory()) {
      processDir(fullPath);
    } else if (entry.isFile() && (fullPath.endsWith('.tsx') || fullPath.endsWith('.ts'))) {
      let content = fs.readFileSync(fullPath, 'utf8');
      let modified = false;
      for (const { from, to } of replacements) {
        if (from.test(content)) {
          content = content.replace(from, to);
          modified = true;
        }
      }
      if (modified) {
        fs.writeFileSync(fullPath, content, 'utf8');
        console.log(`Updated hexes in ${fullPath}`);
      }
    }
  }
}

processDir(dir);
console.log("Done");
