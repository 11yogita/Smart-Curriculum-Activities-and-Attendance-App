# Leave Proof Upload Design

## Summary

Finish the partially implemented leave-request proof workflow so that:

- leave types are `medical`, `academic`, `personal`, and `other`
- proof files are required for `medical` and `academic`
- proof files are optional for `personal` and `other`
- students can upload proof while submitting a leave request
- teachers can view or download the uploaded proof while reviewing a leave request

The implementation should align the source code with the already-visible behavior in the built frontend bundle where possible, and avoid unrelated refactors.

## Current State

The repository is in an inconsistent state:

- [backend/leaves/migrations/0004_add_academic_type_and_proof_file.py](/M:/PROJECT_WITH%20FRONT_BACK/backend/leaves/migrations/0004_add_academic_type_and_proof_file.py) adds `proof_file` and replaces `family` with `academic`
- [backend/leaves/models.py](/M:/PROJECT_WITH%20FRONT_BACK/backend/leaves/models.py) still uses the old leave types and does not define `proof_file`
- [Frontend/src/app/pages/student/ApplyLeave.tsx](/M:/PROJECT_WITH%20FRONT_BACK/Frontend/src/app/pages/student/ApplyLeave.tsx) still posts JSON and does not expose the proof upload flow
- the built frontend bundle already contains a more complete student-side proof upload flow, which provides a concrete target for source-level updates

## Goals

- Make model, migration, API, and source frontend behavior consistent
- Enforce proof requirements on both client and server
- Keep the current attendance prediction and leave approval flow intact
- Expose proof metadata in leave responses so the teacher UI can render proof actions
- Cover the feature with backend regression tests

## Non-Goals

- No redesign of leave approval business logic
- No new storage abstraction for proof documents
- No broader serializer refactor outside the scope needed for this feature
- No admin-side proof workflow beyond whatever existing APIs already return

## Product Decisions

### Leave Types

Supported leave types will be:

- `medical`
- `academic`
- `personal`
- `other`

`family` is removed from the active source implementation to match the migration and intended behavior.

### Proof Requirement Rules

Proof files are:

- required for `medical`
- required for `academic`
- optional for `personal`
- optional for `other`

### File Constraints

Accepted proof formats:

- PDF
- JPG/JPEG
- PNG

Maximum file size:

- 5 MB

### Teacher Access

Teachers must be able to view or download the uploaded proof from the review UI when a proof file exists.

## Backend Design

### Model

[backend/leaves/models.py](/M:/PROJECT_WITH%20FRONT_BACK/backend/leaves/models.py) will be updated to match migration `0004`:

- add `proof_file = models.FileField(...)`
- replace the old `TYPE_CHOICES` set with `medical`, `academic`, `personal`, `other`

Small model-level constants or helper functions may be added to keep leave-type and file-validation rules centralized and shared by the view logic.

### Request Handling

[backend/leaves/views.py](/M:/PROJECT_WITH%20FRONT_BACK/backend/leaves/views.py) will continue to own leave creation, but it will be extended to:

- accept multipart form submissions
- read `proof_file` from `request.FILES`
- validate proof presence based on leave type
- validate proof type and size
- persist the uploaded file on successful leave creation

The existing logic for:

- date parsing
- subject validation
- attendance prediction
- auto-approval decisions
- creation of affected subjects
- creation of absence records for approved leaves

should remain functionally unchanged.

### Response Shape

[backend/leaves/serializers.py](/M:/PROJECT_WITH%20FRONT_BACK/backend/leaves/serializers.py) will expose proof metadata through the existing leave serializer:

- `proof_file`: absolute or request-aware URL for the uploaded file when present, otherwise `null`
- `proof_file_name`: basename for display when present, otherwise `null`

This keeps the frontend simple and avoids leaking storage-specific logic into the UI.

### Validation Rules

Server-side validation will reject:

- missing proof for `medical`
- missing proof for `academic`
- unsupported file types
- files larger than 5 MB
- invalid leave type values outside the supported list

Validation failures should return clear `detail` messages because the current frontend error handling expects a single top-level message.

## Frontend Design

### Student Leave Form

[Frontend/src/app/pages/student/ApplyLeave.tsx](/M:/PROJECT_WITH%20FRONT_BACK/Frontend/src/app/pages/student/ApplyLeave.tsx) will be brought in line with the built bundle behavior:

- change leave types to `medical`, `academic`, `personal`, `other`
- add proof upload state and client-side validation
- require proof only for `medical` and `academic`
- clear proof selection and proof-related errors when leave type changes
- submit with `FormData` instead of JSON
- append repeated `subject_ids` fields to the multipart payload

Client-side validation should mirror the server rules:

- only PDF/JPG/PNG accepted
- max size 5 MB
- missing proof blocked only for `medical` and `academic`

The existing prediction preview, affected subjects list, and general layout should remain intact.

### Teacher Leave Review

[Frontend/src/app/pages/teacher/LeaveApprovals.tsx](/M:/PROJECT_WITH%20FRONT_BACK/Frontend/src/app/pages/teacher/LeaveApprovals.tsx) will consume the new proof metadata:

- extend the leave API types with `proof_file` and `proof_file_name`
- show a proof action in the review surface only when a proof exists
- allow teachers to open the proof in a new tab or download it directly via the returned URL

This change should not alter the existing approve/reject workflow beyond exposing proof access.

### Optional Student History Display

[Frontend/src/app/pages/student/LeaveHistory.tsx](/M:/PROJECT_WITH%20FRONT_BACK/Frontend/src/app/pages/student/LeaveHistory.tsx) does not need to change for the core feature.

If proof metadata is already available in the response, the page can safely ignore it for now.

## Media Handling

The implementation should verify whether development media serving is already configured. If media URLs are not currently served in development, add only the minimum required wiring so returned proof URLs are usable from the teacher UI.

This must stay narrowly scoped to proof-file access and should not become a broader storage refactor.

## Testing Strategy

[backend/leaves/tests.py](/M:/PROJECT_WITH%20FRONT_BACK/backend/leaves/tests.py) will be expanded with regression coverage for:

- successful leave submission with proof for `medical`
- successful leave submission with proof for `academic`
- successful leave submission without proof for `personal`
- successful leave submission without proof for `other`
- rejection when `medical` leave is submitted without proof
- rejection when `academic` leave is submitted without proof
- rejection of unsupported proof file types
- rejection of proof files larger than 5 MB
- serializer response including proof metadata when a file exists

These tests should use Django upload helpers and real request paths so they exercise multipart parsing and validation end to end.

## Affected Files

Backend:

- [backend/leaves/models.py](/M:/PROJECT_WITH%20FRONT_BACK/backend/leaves/models.py)
- [backend/leaves/serializers.py](/M:/PROJECT_WITH%20FRONT_BACK/backend/leaves/serializers.py)
- [backend/leaves/views.py](/M:/PROJECT_WITH%20FRONT_BACK/backend/leaves/views.py)
- [backend/leaves/tests.py](/M:/PROJECT_WITH%20FRONT_BACK/backend/leaves/tests.py)

Frontend:

- [Frontend/src/app/pages/student/ApplyLeave.tsx](/M:/PROJECT_WITH%20FRONT_BACK/Frontend/src/app/pages/student/ApplyLeave.tsx)
- [Frontend/src/app/pages/teacher/LeaveApprovals.tsx](/M:/PROJECT_WITH%20FRONT_BACK/Frontend/src/app/pages/teacher/LeaveApprovals.tsx)

Existing migration reused:

- [backend/leaves/migrations/0004_add_academic_type_and_proof_file.py](/M:/PROJECT_WITH%20FRONT_BACK/backend/leaves/migrations/0004_add_academic_type_and_proof_file.py)

## Risks And Mitigations

### Validation Drift

Risk:

- frontend and backend may enforce slightly different proof rules

Mitigation:

- define one canonical backend rule set
- mirror the same rules in the student UI
- lock the backend behavior with tests

### Media URL Breakage In Development

Risk:

- teacher proof links may be returned but not served locally

Mitigation:

- verify existing media configuration before implementation is considered complete
- add only the minimal required URL wiring if missing

### Partial Feature Merge

Risk:

- source code may remain out of sync with the built bundle or migration state

Mitigation:

- treat the migration as source-of-truth for the data shape
- align the source frontend with the already-present built behavior
- verify serializer output and submit flow together

## Recommended Implementation Order

1. Align the leave model with migration `0004`
2. Add backend validation and serializer proof metadata
3. Write and run backend tests for proof rules
4. Update the student leave form to submit multipart data
5. Update the teacher review UI to expose proof access
6. Verify media URLs work in development

## Open Questions

None. The required proof rules, teacher visibility requirement, and file constraints have been specified.
