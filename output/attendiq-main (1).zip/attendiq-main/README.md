# AttendIQ — Smart Attendance Management System

> MVP Phase  
> Django REST API + React TypeScript + PostgreSQL

---

## What This Project Does

AttendIQ is a web application that helps college students track their attendance, predict how missing classes will affect their percentage, and submit leave requests. Teachers can approve or reject leaves. The admin manages users and subjects.

**Three roles:**
- **Student** — views attendance, predicts leave impact, applies for leave
- **Teacher** — reviews and approves/rejects student leave requests  
- **Admin** — manages users, subjects, and views system dashboard

---

## Demo Accounts (after setup)

| Role    | Email                  | Password     |
|---------|------------------------|--------------|
| Student | student@attendiq.com   | Student@123  |
| Teacher | teacher@attendiq.com   | Teacher@123  |
| Admin   | admin@attendiq.com     | Admin@123    |

---

## Prerequisites — Install These First

You need four tools installed before starting. Check if you already have them:

```bash
python --version     # need 3.11 or higher
node --version       # need 18 or higher
npm --version        # comes with Node
psql --version       # need PostgreSQL 15
```

If any command says "not found", install it:

### Install Python 3.11+
1. Go to https://www.python.org/downloads/
2. Download the latest Python 3.11 or 3.12 installer for Windows
3. **IMPORTANT:** During installation, tick the checkbox **"Add Python to PATH"**
4. Click Install Now
5. After install, open a new terminal and run `python --version` to confirm

### Install Node.js 18+
1. Go to https://nodejs.org/
2. Download the **LTS version** (left button, not Current)
3. Run the installer, keep all defaults
4. After install, open a new terminal and run `node --version` to confirm

### Install PostgreSQL 15
1. Go to https://www.postgresql.org/download/windows/
2. Click "Download the installer" → download PostgreSQL 15
3. Run the installer
4. **During installation remember these — you will need them:**
   - Installation directory: leave as default
   - Password: set a password for the `postgres` user — **write this down**
   - Port: leave as `5432`
   - Leave everything else as default
5. After install, open pgAdmin from the Start menu to confirm it works

---

## Step 1 — Clone the Project

Open Command Prompt or PowerShell and run:

```bash
git clone https://github.com/mynkdsl/attendiq
cd attendiq
```

You should now have a folder with two subfolders inside: `backend/` and `frontend/`

---

## Step 2 — Create the Database

### Using pgAdmin (easier):
1. Open pgAdmin from Start menu
2. In the left panel, expand Servers → PostgreSQL 15
3. Enter the postgres password you set during installation
4. Right-click on **Databases** → **Create** → **Database**
5. In the Database field type: `attendiq_db`
6. Click **Save**
7. You should see `attendiq_db` appear in the left panel

### Using psql (command line):
```bash
psql -U postgres
# Enter your postgres password when prompted
CREATE DATABASE attendiq_db;
\q
```

---

## Step 3 — Set Up the Backend

Open a terminal in the project root folder and run these commands one by one. Wait for each one to finish before running the next.

```bash
# Go into the backend folder
cd backend

# Create a virtual environment (isolated Python space for this project)
python -m venv venv

# Activate the virtual environment
venv\Scripts\activate
```

After activating, your terminal prompt will show `(venv)` at the start. This means it worked.

```bash
# Install all Python packages the project needs
pip install -r requirements.txt
```

This will take 1-2 minutes. You will see a lot of text — that is normal. Wait until it says "Successfully installed..."

### Create your .env file

The `.env` file holds your database password and secret keys. It is NOT on GitHub (for security). You must create it yourself.

```bash
# Copy the example file
copy .env.example .env
```

Now open the `.env` file in VS Code:
```bash
code .env
```

You will see this:
```
SECRET_KEY=your-secret-key-here
DEBUG=True
ALLOWED_HOSTS=localhost,127.0.0.1
DB_NAME=attendiq_db
DB_USER=postgres
DB_PASSWORD=your-password-here
DB_HOST=localhost
DB_PORT=5432
CORS_ALLOWED_ORIGINS=http://localhost:5173,http://localhost:3000
```

Change only this one line — replace `your-password-here` with the PostgreSQL password you set during PostgreSQL installation:
```
DB_PASSWORD=your_actual_postgres_password
```

Also replace `your-secret-key-here` with any long random string, for example:
```
SECRET_KEY=attendiq-local-dev-secret-key-change-this-in-production-2025
```

Save the file.

### Run database migrations

This creates all the database tables:

```bash
python manage.py migrate
```

You will see a list of migrations being applied. The last line should say something like `Running migrations: 12 migrations applied` with no errors.

If you see an error like `password authentication failed` — your DB_PASSWORD in `.env` is wrong. Double-check it.

If you see `database "attendiq_db" does not exist` — go back to Step 2 and create the database.

### Seed the database with demo data

This creates the demo accounts, subjects, timetable, and 107 attendance records:

```bash
python manage.py seed_db
```

You should see this output:
```
========================================
  AttendIQ MVP — Seed Complete
========================================
  Student  → student@attendiq.com  / Student@123
  Teacher  → teacher@attendiq.com  / Teacher@123
  Admin    → admin@attendiq.com    / Admin@123
----------------------------------------
  Division A timetable: seeded
  Subjects: 6
  Enrolled: Mayank Disale in all 6 subjects
  Attendance records: 107
========================================
```

If you see this — the backend is fully set up.

### Start the backend server

```bash
python manage.py runserver
```

You should see:
```
Starting development server at http://127.0.0.1:8000/
Quit the server with CTRL-BREAK.
```

**Leave this terminal open.** The backend must keep running while you use the app.

---

## Step 4 — Set Up the Frontend

Open a **new terminal window** (do not close the backend terminal). Navigate to the project root and run:

```bash
# Go into the frontend folder
cd frontend

# Install all JavaScript packages
npm install
```

This will take 1-2 minutes and install packages into a `node_modules` folder.

### Start the frontend

```bash
npm run dev
```

You should see:
```
  VITE v5.x.x  ready in xxx ms

  ➜  Local:   http://localhost:5173/
  ➜  Network: use --host to expose
```

**Leave this terminal open too.**

---

## Step 5 — Open the App

Open your browser and go to:
```
http://localhost:5173
```

You should see the AttendIQ login page.

**Test it works:**
1. Select role: **Student**
2. Email: `student@attendiq.com`
3. Password: `Student@123`
4. Click Sign In

You should see the student dashboard with 88.1% overall attendance.

---

## How to Run the Project Every Day

You do not need to reinstall anything after the first setup. Every day:

**Terminal 1 — Start backend:**
```bash
cd backend
venv\Scripts\activate
python manage.py runserver
```

**Terminal 2 — Start frontend:**
```bash
cd frontend
npm run dev
```

Then open `http://localhost:5173` in your browser.

---

## Project Structure

```
attendiq/
│
├── backend/                    ← Django REST API
│   ├── attendiq/               ← Project config (settings, urls)
│   ├── users/                  ← User accounts and profiles
│   ├── subjects/               ← Subjects and timetable
│   ├── attendance/             ← Attendance records and prediction
│   ├── leaves/                 ← Leave requests and approvals
│   ├── requirements.txt        ← Python packages list
│   ├── .env.example            ← Template for your .env file
│   └── manage.py               ← Django management tool
│
├── frontend/                   ← React TypeScript app
│   ├── src/
│   │   ├── pages/              ← All screen components
│   │   ├── components/         ← Reusable UI components
│   │   ├── services/           ← API call functions
│   │   └── context/            ← Auth state management
│   └── package.json            ← JavaScript packages list
│
├── .gitignore                  ← Files not uploaded to GitHub
└── README.md                   ← This file
```

---

## API Base URL

All backend API endpoints are at:
```
http://localhost:8000/api/v1/
```

| Role    | Key Endpoints |
|---------|--------------|
| Student | GET /student/attendance/ — GET /student/predict/ — POST /student/leave/ |
| Teacher | GET /teacher/leaves/ — PATCH /teacher/leaves/:id/ |
| Admin   | GET /admin/dashboard/ — GET /admin/users/ — GET /admin/subjects/ |

---

## Tech Stack

| Technology | Version | Purpose |
|---|---|---|
| Django | 4.2 | Backend framework |
| Django REST Framework | 3.15 | REST API layer |
| djangorestframework-simplejwt | 5.3 | JWT authentication |
| PostgreSQL | 15 | Database |
| psycopg2-binary | 2.9 | PostgreSQL adapter |
| python-decouple | 3.8 | Environment variables |
| React | 18 | Frontend framework |
| TypeScript | 5 | Type-safe JavaScript |
| Vite | 5 | Frontend build tool |
| Tailwind CSS | 4 | Styling |
| Recharts | 2 | Charts and graphs |
| Axios | 1.6 | HTTP client |

---

## Common Errors and Fixes

**"venv\Scripts\activate is not recognized"**
```bash
# Try this instead
python -m venv venv
.\venv\Scripts\activate
```

**"password authentication failed for user postgres"**
- Open `.env` file and check `DB_PASSWORD` matches what you set during PostgreSQL installation
- If you forgot the password, reset it via pgAdmin: right-click postgres user → Properties → Password

**"database attendiq_db does not exist"**
- Go back to Step 2 and create the database in pgAdmin or psql

**"ModuleNotFoundError: No module named 'django'"**
- Your virtual environment is not activated
- Run `venv\Scripts\activate` first, then try again

**"npm: command not found"**
- Node.js is not installed or not in PATH
- Reinstall Node.js from nodejs.org and tick "Add to PATH" during installation

**"Port 8000 already in use"**
- Another process is using port 8000
- Run: `python manage.py runserver 8001` and update CORS_ALLOWED_ORIGINS in .env

**"CORS error" in browser console**
- Backend is not running
- Check Terminal 1 shows "Starting development server at http://127.0.0.1:8000/"

**Frontend shows blank page after login**
- Open browser DevTools (F12) → Console tab → read the error message
- Usually means backend is not running or JWT token expired — try logging out and back in

---

## Important Rules for the Team

1. **Never commit `.env` to GitHub** — it contains your database password
2. **Always pull before you start working:** `git pull origin main`
3. **Always activate venv before running backend commands:** `venv\Scripts\activate`
4. **If you pull new changes and the app breaks**, run these:
   ```bash
   cd backend
   venv\Scripts\activate
   pip install -r requirements.txt   # in case new packages were added
   python manage.py migrate          # in case new DB tables were added
   ```
5. **To reset database completely** (fresh start):
   ```bash
   # Drop and recreate database in pgAdmin
   # Then run:
   python manage.py migrate
   python manage.py seed_db
   ```

---

## Future Scope (Not in MVP)

- University ERP integration (auto-sync attendance from college portal)
- Mobile app
- Email/SMS notifications
- Multi-division support
---
