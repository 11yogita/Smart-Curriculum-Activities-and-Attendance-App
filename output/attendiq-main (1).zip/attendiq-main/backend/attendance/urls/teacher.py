from django.urls import path
from subjects.views import TeacherSubjectListView
from leaves.views import TeacherLeaveView, TeacherLeaveDetailView
from attendance.views import TeacherStudentAttendanceView, TeacherDashboardView

urlpatterns = [
    path('dashboard/', TeacherDashboardView.as_view(), name='teacher-dashboard'),
    path('subjects/', TeacherSubjectListView.as_view(), name='teacher-subjects'),
    path('attendance/', TeacherStudentAttendanceView.as_view(), name='teacher-attendance'),
    path('leaves/', TeacherLeaveView.as_view(), name='teacher-leaves'),
    path('leaves/<uuid:leave_id>/', TeacherLeaveDetailView.as_view(), name='teacher-leave-detail'),
]
