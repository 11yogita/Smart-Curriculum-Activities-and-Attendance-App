from django.urls import path
from attendance.views_student import StudentAttendanceSummaryView, StudentAttendanceChartView, StudentPredictView, StudentPredictMultiView, StudentTimetableView
from leaves.views import StudentLeaveView

urlpatterns = [
    path('attendance/', StudentAttendanceSummaryView.as_view(), name='student-attendance'),
    path('attendance/chart/', StudentAttendanceChartView.as_view(), name='student-attendance-chart'),
    path('predict/', StudentPredictView.as_view(), name='student-predict'),
    path('predict/multi/', StudentPredictMultiView.as_view(), name='student-predict-multi'),
    path('leave/', StudentLeaveView.as_view(), name='student-leave'),
    path('timetable/', StudentTimetableView.as_view(), name='student-timetable'),
]

