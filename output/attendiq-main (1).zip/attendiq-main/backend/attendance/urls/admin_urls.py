from django.urls import path
from users.views_admin import AdminUserListView, AdminUserDetailView
from subjects.views import AdminSubjectListView, AdminSubjectDetailView
from attendance.views_admin import AdminDashboardView, AdminAttendanceDetailView

urlpatterns = [
    path('dashboard/', AdminDashboardView.as_view(), name='admin-dashboard'),
    path('users/', AdminUserListView.as_view(), name='admin-users-list'),
    path('users/<uuid:user_id>/', AdminUserDetailView.as_view(), name='admin-user-detail'),
    path('subjects/', AdminSubjectListView.as_view(), name='admin-subjects-list'),
    path('subjects/<uuid:subject_id>/', AdminSubjectDetailView.as_view(), name='admin-subject-detail'),
    path('attendance/<uuid:record_id>/', AdminAttendanceDetailView.as_view(), name='admin-attendance-detail'),
]
