from rest_framework.views import APIView
from rest_framework import generics
from rest_framework.response import Response
from rest_framework import status
from django.db.models import Count, Q

from users.models import CustomUser
from subjects.models import Subject
from attendance.models import AttendanceRecord
from leaves.models import LeaveRequest
from users.permissions import IsAdmin

class AdminDashboardView(APIView):
    permission_classes = [IsAdmin]

    def get(self, request):
        total_students = CustomUser.objects.filter(role='student').count()
        total_teachers = CustomUser.objects.filter(role='teacher').count()
        total_subjects = Subject.objects.count()
        
        records = AttendanceRecord.objects.filter(status__in=['present', 'absent'])
        total_recs = records.count()
        present_recs = records.filter(status='present').count()
        avg_attendance_pct = (present_recs / total_recs * 100) if total_recs > 0 else 0.0
        
        pending_leaves_count = LeaveRequest.objects.filter(status='pending').count()
        
        # Calculate below_threshold_count
        # Get present and total per student per subject
        
        # Simplified for prototype: 
        student_stats_query = AttendanceRecord.objects.filter(
            status__in=['present', 'absent']
        ).values('student', 'subject').annotate(
            total=Count('id'),
            present=Count('id', filter=Q(status='present'))
        )
        
        below_threshold_count = 0
        for stat in student_stats_query:
            pct = (stat['present'] / stat['total']) * 100 if stat['total'] > 0 else 0
            if pct < 75.0:
                below_threshold_count += 1
                
        return Response({
            "total_students": total_students,
            "total_teachers": total_teachers,
            "total_subjects": total_subjects,
            "avg_attendance_pct": round(avg_attendance_pct, 1),
            "below_threshold_count": below_threshold_count,
            "pending_leaves_count": pending_leaves_count
        })



class AdminAttendanceDetailView(generics.UpdateAPIView):
    permission_classes = [IsAdmin]
    queryset = AttendanceRecord.objects.all()
    lookup_field = 'id'
    lookup_url_kwarg = 'record_id'
    
    def update(self, request, *args, **kwargs):
        record = self.get_object()
        new_status = request.data.get('status')
        
        if new_status not in [c[0] for c in AttendanceRecord.STATUS_CHOICES]:
            return Response({'status': ['Invalid status']}, status=status.HTTP_400_BAD_REQUEST)
            
        record.status = new_status
        record.save()
        
        # Format the response mapping model fields manually since we aren't using a serializer
        return Response({
            "id": record.id,
            "student_id": record.student_id,
            "subject_id": record.subject_id,
            "date": record.date.strftime('%Y-%m-%d'),
            "status": record.status
        }, status=status.HTTP_200_OK)
