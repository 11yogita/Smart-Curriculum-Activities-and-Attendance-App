from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from datetime import datetime
from subjects.models import Subject, Timetable
from attendance.models import AttendanceRecord
from users.permissions import IsStudent
from .services import run_prediction_formula, get_timetable_slots_in_range

class StudentAttendanceSummaryView(APIView):
    permission_classes = [IsStudent]

    def get(self, request):
        user = request.user
        subjects = Subject.objects.filter(enrollments__student=user)
        
        subjects_data = []
        total_classes_overall = 0
        attended_overall = 0
        
        for subject in subjects:
            records = AttendanceRecord.objects.filter(student=user, subject=subject, status__in=['present', 'absent'])
            total_classes = records.count()
            attended = records.filter(status='present').count()
            
            percentage = (attended / total_classes * 100) if total_classes > 0 else 0.0
            
            subjects_data.append({
                "subject_id": subject.id,
                "subject_name": subject.name,
                "subject_code": subject.subject_code,
                "total_classes": total_classes,
                "attended": attended,
                "percentage": round(percentage, 1),
                "status": "safe" if percentage >= 75.0 else "danger"
            })
            
            total_classes_overall += total_classes
            attended_overall += attended
            
        overall_percentage = (attended_overall / total_classes_overall * 100) if total_classes_overall > 0 else 0.0
        
        return Response({
            "student_id": user.id,
            "subjects": subjects_data,
            "overall_percentage": round(overall_percentage, 1)
        })

class StudentAttendanceChartView(APIView):
    permission_classes = [IsStudent]

    def get(self, request):
        subject_id = request.query_params.get('subject_id')
        if not subject_id:
            return Response({"detail": "subject_id is required"}, status=status.HTTP_400_BAD_REQUEST)
            
        records = AttendanceRecord.objects.filter(
            student=request.user, subject_id=subject_id, status__in=['present', 'absent']
        ).order_by('date')
        
        chart_data = []
        attended = 0
        total = 0
        
        for record in records:
            total += 1
            if record.status == 'present':
                attended += 1
            pct = (attended / total) * 100
            chart_data.append({
                "date": record.date.strftime('%Y-%m-%d'),
                "cumulative_pct": round(pct, 1)
            })
            
        return Response({
            "subject_id": subject_id,
            "chart_data": chart_data
        })

class StudentPredictView(APIView):
    permission_classes = [IsStudent]

    def get(self, request):
        subject_id = request.query_params.get('subject_id')
        miss_str = request.query_params.get('miss')
        
        try:
            miss = int(miss_str)
            if not 1 <= miss <= 30:
                raise ValueError
        except (TypeError, ValueError):
            return Response({"miss": ["Must be an integer between 1 and 30."]}, status=status.HTTP_400_BAD_REQUEST)
            
        try:
            subject = Subject.objects.get(id=subject_id, enrollments__student=request.user)
        except Subject.DoesNotExist:
            return Response({"detail": "Subject not found or not enrolled."}, status=status.HTTP_404_NOT_FOUND)
            
        result = run_prediction_formula(request.user, subject, miss)
        
        # Format the exact response required:
        return Response({
            "subject_id": result["subject_id"],
            "subject_name": result["subject_name"],
            "current_pct": result["current_pct"],
            "predicted_pct": result["predicted_pct"],
            "delta": result["delta"],
            "safe": result["safe"],
            "miss": miss
        })

class StudentPredictMultiView(APIView):
    permission_classes = [IsStudent]

    def get(self, request):
        from_date_str = request.query_params.get('from_date')
        to_date_str = request.query_params.get('to_date')
        
        try:
            from_date = datetime.strptime(from_date_str, '%Y-%m-%d').date()
            to_date = datetime.strptime(to_date_str, '%Y-%m-%d').date()
        except (TypeError, ValueError):
            return Response({"detail": "Valid from_date and to_date (YYYY-MM-DD) are required."}, status=status.HTTP_400_BAD_REQUEST)
            
        subjects = Subject.objects.filter(enrollments__student=request.user)
        results = []
        all_safe = True
        
        for subject in subjects:
            miss_count = get_timetable_slots_in_range(subject, from_date, to_date)
            res = run_prediction_formula(request.user, subject, miss_count)
            results.append(res)
            if not res['safe']:
                all_safe = False
                
        return Response({
            "from_date": from_date_str,
            "to_date": to_date_str,
            "subjects": results,
            "all_safe": all_safe
        })


class StudentTimetableView(APIView):
    permission_classes = [IsStudent]

    def get(self, request):
        user = request.user
        division = user.division or 'A'
        
        # Grouped by day for easier frontend rendering
        days_names = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
        
        slots = Timetable.objects.filter(division=division).select_related('subject').order_by('day_of_week', 'start_time')
        
        schedule = {}
        for day_idx in range(7):
            day_name = days_names[day_idx]
            day_slots = slots.filter(day_of_week=day_idx)
            
            slot_list = []
            for s in day_slots:
                slot_list.append({
                    "id": str(s.id),
                    "start_time": s.start_time.strftime("%H:%M"),
                    "end_time": s.end_time.strftime("%H:%M"),
                    "subject_name": s.subject.name if s.subject else "",
                    "subject_code": s.subject.subject_code if s.subject else "",
                    "room": s.room,
                    "slot_type": s.slot_type,
                })
            
            schedule[day_name] = slot_list

        return Response({
            "success": True,
            "division": division,
            "schedule": schedule
        })

