from datetime import date, timedelta
from subjects.models import Subject, Timetable
from attendance.models import AttendanceRecord

def get_timetable_slots_in_range(subject, from_date: date, to_date: date) -> int:
    """
    Returns the number of scheduled classes (lectures + labs only) for a
    subject within a date range, based on the timetable.

    day_of_week in Timetable is an integer: 0=Monday ... 6=Sunday
    date.weekday() also returns 0=Monday ... 6=Sunday — so they match directly.
    """
    if from_date > to_date:
        return 0

    # Get all timetable slot weekdays for this subject (lectures and labs only)
    # Returns a list of integers e.g. [0, 0, 1, 4] meaning Mon, Mon, Tue, Fri
    slot_weekdays = list(
        Timetable.objects.filter(
            subject=subject,
            slot_type__in=['lecture', 'lab']
        ).values_list('day_of_week', flat=True)
    )

    if not slot_weekdays:
        return 0

    count = 0
    current = from_date
    while current <= to_date:
        # current.weekday() returns 0=Mon, 1=Tue ... same as day_of_week integer
        # Count how many timetable slots fall on this exact weekday
        count += slot_weekdays.count(current.weekday())
        current += timedelta(days=1)

    return count

def run_prediction_formula(student, subject, miss_count: int):
    records = AttendanceRecord.objects.filter(student=student, subject=subject, status__in=['present', 'absent'])
    current_attended = records.filter(status='present').count()
    current_total = records.count()
    
    if current_total == 0:
        return {
            "subject_id": subject.id,
            "subject_name": subject.name,
            "current_pct": 0.0,
            "predicted_pct": 0.0,
            "delta": 0.0,
            "classes_missed": miss_count,
            "safe": False
        }
        
    current_pct = (current_attended / current_total) * 100
    predicted_total = current_total + miss_count
    predicted_pct = (current_attended / predicted_total) * 100 if predicted_total > 0 else 0.0
    delta = predicted_pct - current_pct
    
    return {
        "subject_id": subject.id,
        "subject_name": subject.name,
        "current_pct": round(current_pct, 1),
        "predicted_pct": round(predicted_pct, 1),
        "delta": round(delta, 1),
        "classes_missed": miss_count,
        "safe": predicted_pct >= 75.0
    }
