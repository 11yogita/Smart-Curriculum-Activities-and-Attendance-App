from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

from users.permissions import IsTeacher
from subjects.models import Subject, Enrollment
from attendance.models import AttendanceRecord
from leaves.models import LeaveRequest


class TeacherStudentAttendanceView(APIView):
	permission_classes = [IsTeacher]

	def get(self, request):
		subject_id = request.query_params.get('subject_id')
		if not subject_id:
			return Response({'detail': 'subject_id is required'}, status=status.HTTP_400_BAD_REQUEST)

		try:
			subject = Subject.objects.get(id=subject_id, teacher=request.user)
		except Subject.DoesNotExist:
			return Response({'detail': 'Subject not found or not assigned to teacher'}, status=status.HTTP_404_NOT_FOUND)

		enrollments = Enrollment.objects.filter(subject=subject).select_related('student')
		students_payload = []

		for enrollment in enrollments:
			student = enrollment.student
			recs = AttendanceRecord.objects.filter(
				student=student,
				subject=subject,
				status__in=['present', 'absent']
			)
			total = recs.count()
			attended = recs.filter(status='present').count()
			percentage = round((attended / total) * 100, 1) if total > 0 else 0.0

			students_payload.append({
				'student_id': str(student.id),
				'student_name': student.full_name,
				'student_roll': student.student_id,
				'attended': attended,
				'total': total,
				'percentage': percentage,
			})

		students_payload.sort(key=lambda x: x['student_name'].lower())

		return Response({
			'subject_id': str(subject.id),
			'subject_name': subject.name,
			'subject_code': subject.subject_code,
			'students': students_payload,
		})


class TeacherDashboardView(APIView):
	permission_classes = [IsTeacher]

	def get(self, request):
		subjects = Subject.objects.filter(teacher=request.user)
		subject_stats = []
		at_risk_students = set()

		for subject in subjects:
			enrollments = Enrollment.objects.filter(subject=subject).select_related('student')
			total_students = enrollments.count()

			safe_students = 0
			warning_students = 0
			critical_students = 0
			pct_sum = 0.0

			for enrollment in enrollments:
				student = enrollment.student
				recs = AttendanceRecord.objects.filter(
					student=student,
					subject=subject,
					status__in=['present', 'absent']
				)
				total = recs.count()
				attended = recs.filter(status='present').count()
				pct = (attended / total) * 100 if total > 0 else 0.0
				pct_sum += pct

				if pct >= 75.0:
					safe_students += 1
				elif pct >= 65.0:
					warning_students += 1
				else:
					critical_students += 1
					at_risk_students.add(str(student.id))

			avg_attendance = round((pct_sum / total_students), 1) if total_students > 0 else 0.0

			subject_stats.append({
				'subject_id': str(subject.id),
				'subject__name': subject.name,
				'subject__code': subject.subject_code,
				'total_students': total_students,
				'average_attendance': avg_attendance,
				'safe_students': safe_students,
				'warning_students': warning_students,
				'critical_students': critical_students,
			})

		pending_leaves = LeaveRequest.objects.filter(
			status='pending',
			affected_subjects__subject__teacher=request.user
		).distinct().count()

		overall_stats = {
			'total_subjects': subjects.count(),
			'total_students': Enrollment.objects.filter(subject__teacher=request.user).values('student_id').distinct().count(),
			'pending_leaves': pending_leaves,
			'critical_students': len(at_risk_students),
		}

		return Response({
			'overall_stats': overall_stats,
			'subject_stats': subject_stats,
		})
