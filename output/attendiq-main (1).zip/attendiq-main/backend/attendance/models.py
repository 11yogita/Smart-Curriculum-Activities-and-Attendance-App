from django.db import models
from uuid import uuid4
from users.models import CustomUser
from subjects.models import Subject

class AttendanceRecord(models.Model):
    STATUS_CHOICES = [
        ('present', 'present'),
        ('absent', 'absent'),
        ('holiday', 'holiday'),
        ('cancelled', 'cancelled')
    ]

    id = models.UUIDField(primary_key=True, default=uuid4, editable=False)
    student = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='attendance_records')
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE, related_name='attendance_records')
    date = models.DateField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES)
    marked_by = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True, related_name='marked_attendance')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ['student', 'subject', 'date']

class AttendanceUpload(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid4, editable=False)
    uploaded_by = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True)
    file_name = models.CharField(max_length=255)
    rows_inserted = models.IntegerField(default=0)
    rows_skipped = models.IntegerField(default=0)
    rows_failed = models.IntegerField(default=0)
    status = models.CharField(max_length=20)
    error_report = models.JSONField(default=list)
    created_at = models.DateTimeField(auto_now_add=True)
