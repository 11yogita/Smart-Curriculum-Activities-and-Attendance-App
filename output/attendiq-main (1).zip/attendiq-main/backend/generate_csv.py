import csv
import random
from datetime import date, timedelta

# Seed for reproducibility — same file every time
random.seed(42)

# Timetable: which subjects have class on which weekday
# weekday: 0=Mon, 1=Tue, 2=Wed, 3=Thu, 4=Fri
TIMETABLE = {
    0: ['COI', 'JP', 'DBMS', 'AST', 'DIP'],   # Monday
    1: ['DBMS', 'COI', 'JP'],                   # Tuesday
    2: ['DIP', 'JP', 'MooC'],                   # Wednesday
    3: ['DIP', 'COI', 'AST', 'MooC'],           # Thursday
    4: ['JP', 'AST', 'DIP', 'DBMS'],            # Friday
}

# Present probability per subject
# DBMS and COI slightly lower for interesting demo numbers
PRESENT_RATE = {
    'COI':  0.80,
    'JP':   0.87,
    'DBMS': 0.77,
    'AST':  0.86,
    'DIP':  0.85,
    'MooC': 0.88,
}

rows = []
start = date(2025, 2, 3)   # Monday
end   = date(2025, 3, 14)  # Friday

current = start
while current <= end:
    weekday = current.weekday()
    subjects_today = TIMETABLE.get(weekday, [])

    for subject_code in subjects_today:
        rate = PRESENT_RATE.get(subject_code, 0.85)
        status = 'P' if random.random() < rate else 'A'
        notes = '' if status == 'P' else 'absent'
        rows.append({
            'date': current.strftime('%Y-%m-%d'),
            'subject_code': subject_code,
            'status': status,
            'notes': notes,
        })

    current += timedelta(days=1)

output_path = 'backend/sample_data/attendance_2025_03.csv'
with open(output_path, 'w', newline='') as f:
    writer = csv.DictWriter(f, fieldnames=['date', 'subject_code', 'status', 'notes'])
    writer.writeheader()
    writer.writerows(rows)

print(f"Generated {len(rows)} rows")

# Verify no duplicates
seen = set()
duplicates = []
for row in rows:
    key = (row['date'], row['subject_code'])
    if key in seen:
        duplicates.append(key)
    seen.add(key)

if duplicates:
    print(f"ERROR: {len(duplicates)} duplicate (date, subject_code) pairs found!")
    for d in duplicates:
        print(f"  {d}")
else:
    print("✓ No duplicates — CSV is clean")

# Print summary per subject
from collections import defaultdict
subject_stats = defaultdict(lambda: {'P': 0, 'A': 0})
for row in rows:
    subject_stats[row['subject_code']][row['status']] += 1

print("\nAttendance summary per subject:")
for code in ['COI', 'JP', 'DBMS', 'AST', 'DIP', 'MooC']:
    stats = subject_stats[code]
    total = stats['P'] + stats['A']
    pct = (stats['P'] / total * 100) if total > 0 else 0
    print(f"  {code:6s}  P={stats['P']:2d}  A={stats['A']:2d}  Total={total:2d}  {pct:.1f}%")

print(f"\nTotal rows: {len(rows)}")
