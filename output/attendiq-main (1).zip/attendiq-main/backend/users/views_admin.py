import string
import random
from rest_framework import generics, status
from rest_framework.response import Response
from django.db.models import Q
from users.models import CustomUser
from users.serializers import UserSerializer
from users.permissions import IsAdmin
from rest_framework.pagination import PageNumberPagination

class AdminUserPagination(PageNumberPagination):
    page_size = 20

class AdminUserListView(generics.ListCreateAPIView):
    permission_classes = [IsAdmin]
    pagination_class = AdminUserPagination
    serializer_class = UserSerializer

    def get_queryset(self):
        queryset = CustomUser.objects.all().order_by('-created_at')
        role = self.request.query_params.get('role')
        search = self.request.query_params.get('search')
        
        if role in ['student', 'teacher', 'admin']:
            queryset = queryset.filter(role=role)
        if search:
            queryset = queryset.filter(Q(full_name__icontains=search) | Q(email__icontains=search))
            
        return queryset

    def create(self, request, *args, **kwargs):
        data = request.data
        email = data.get('email')
        full_name = data.get('full_name')
        role = data.get('role')
        student_id = data.get('student_id')

        if not email or not full_name or not role:
            return Response({'detail': 'email, full_name and role are required'}, status=status.HTTP_400_BAD_REQUEST)
        
        if role not in ['student', 'teacher', 'admin']:
            return Response({'detail': 'Invalid role'}, status=status.HTTP_400_BAD_REQUEST)

        if role == 'student' and not student_id:
            return Response({'student_id': ['student_id is required for student role']}, status=status.HTTP_400_BAD_REQUEST)
        
        if CustomUser.objects.filter(email=email).exists():
            return Response({'email': ['Email already exists']}, status=status.HTTP_400_BAD_REQUEST)
            
        generated_password = ''.join(random.choices(string.ascii_letters + string.digits, k=10)) + '@123'

        user = CustomUser(
            email=email,
            full_name=full_name,
            role=role,
            student_id=student_id if role == 'student' else None,
            is_active=True,
        )
        user.set_password(generated_password)
        user.save()
        
        serializer = UserSerializer(user)
        response_data = serializer.data
        response_data['generated_password'] = generated_password
        
        return Response(response_data, status=status.HTTP_201_CREATED)

class AdminUserDetailView(generics.UpdateAPIView):
    permission_classes = [IsAdmin]
    queryset = CustomUser.objects.all()
    serializer_class = UserSerializer
    lookup_field = 'id'
    lookup_url_kwarg = 'user_id'
    
    def update(self, request, *args, **kwargs):
        user = self.get_object()
        
        is_active = request.data.get('is_active')
        full_name = request.data.get('full_name')
        
        if is_active is not None:
            user.is_active = bool(is_active)
        if full_name:
            user.full_name = full_name
            
        user.save()
        
        return Response(UserSerializer(user).data, status=status.HTTP_200_OK)
