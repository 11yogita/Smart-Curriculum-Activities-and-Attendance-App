from django.core.management.base import BaseCommand
from users.models import CustomUser
from subjects.models import Subject, Enrollment, Timetable
import datetime

class Command(BaseCommand):
    help = 'Seeds the database with AttendIQ MVP demo data'

    def _create_user(self, email, full_name, role, password, division='A', is_staff=False, is_superuser=False):
        user, created = CustomUser.objects.get_or_create(
            email=email,
            defaults={
                'full_name': full_name,
                'role': role,
                'division': division,
                'is_staff': is_staff,
                'is_superuser': is_superuser,
                'is_active': True,
            }
        )
        if created or (not user.check_password(password)):
            user.set_password(password)
            user.save()
        return user

    def handle(self, *args, **kwargs):
        self.stdout.write("Starting MVP Seeding...")

        # Clear demo noise
        mvp_emails = ['admin@attendiq.com', 'teacher@attendiq.com', 'student@attendiq.com']
        CustomUser.objects.exclude(email__in=mvp_emails).delete()
        
        # Ensure subjects are cleaned if they don't match our 6
        Subject.objects.exclude(subject_code__in=['COI', 'JP', 'DBMS', 'AST', 'DIP', 'MooC']).delete()

        # 1. Accounts
        admin = self._create_user('admin@attendiq.com', 'Admin AttendIQ', 'admin', 'Admin@123', is_staff=True)
        teacher = self._create_user('teacher@attendiq.com', 'Class Teacher', 'teacher', 'Teacher@123')
        student = self._create_user('student@attendiq.com', 'Mayank Disale', 'student', 'Student@123', division='A')

        # 2. Subjects
        subjects_payload = [
            ('COI', 'Concepts of Intelligence', 3),
            ('JP', 'Java Programming', 4),
            ('DBMS', 'Database Management System', 4),
            ('AST', 'Advanced Software Testing', 3),
            ('DIP', 'Digital Image Processing', 3),
            ('MooC', 'Massive Open Online Course', 2),
        ]
        
        subjects_map = {}
        for code, name, credits in subjects_payload:
            subj, _ = Subject.objects.update_or_create(
                subject_code=code,
                defaults={
                    'name': name,
                    'teacher': teacher,
                    'credits': credits
                }
            )
            subjects_map[code] = subj

        # 3. Timetable (Division A)
        timetable_rows = [
            (0, '09:00', '10:00', 'COI',  'A-608',        'lecture'),
            (0, '10:00', '11:00', 'JP',   'A-608',        'lecture'),
            (0, '11:00', '11:15', None,   '',             'break'),
            (0, '11:15', '12:15', 'DBMS', 'A-608',        'lecture'),
            (0, '12:15', '13:15', 'AST',  'A-608',        'lecture'),
            (0, '13:15', '14:00', None,   '',             'break'),
            (0, '14:00', '16:00', 'DBMS', 'A-309B/A-310', 'lab'),
            (0, '16:00', '16:50', 'DIP',  'A-605',        'lecture'),
            (1, '09:00', '10:00', 'DBMS', 'A-605',        'lecture'),
            (1, '10:00', '11:00', 'COI',  'A-605',        'lecture'),
            (1, '11:00', '11:15', None,   '',             'break'),
            (1, '11:15', '12:15', 'DBMS', 'A-608',        'lecture'),
            (1, '12:15', '13:15', 'JP',   'A-605',        'lecture'),
            (1, '13:15', '14:00', None,   '',             'break'),
            (1, '14:00', '16:00', 'JP',   'A-310/A-309B', 'lab'),
            (2, '09:00', '10:00', 'DIP',  'A-605',        'lecture'),
            (2, '10:00', '11:00', 'JP',   'A-605',        'lecture'),
            (2, '11:00', '11:15', None,   '',             'break'),
            (2, '11:15', '13:15', None,   'A-608',        'activity'),
            (2, '13:15', '14:00', None,   '',             'break'),
            (2, '14:00', '15:00', 'DIP',  'A-608',        'lecture'),
            (2, '15:00', '16:00', 'MooC', 'A-608',        'lecture'),
            (3, '09:00', '11:00', None,   'A-605',        'minor'),
            (3, '11:00', '11:15', None,   '',             'break'),
            (3, '11:15', '12:15', 'DIP',  'A-608',        'lecture'),
            (3, '12:15', '13:15', 'COI',  'A-608',        'lecture'),
            (3, '13:15', '14:00', None,   '',             'break'),
            (3, '14:00', '15:00', 'AST',  'A-608',        'lecture'),
            (3, '15:00', '16:00', 'MooC', 'A-608',        'lecture'),
            (4, '09:00', '10:00', 'JP',   'A-608',        'lecture'),
            (4, '10:00', '11:00', 'AST',  'A-608',        'lecture'),
            (4, '11:00', '11:15', None,   '',             'break'),
            (4, '11:15', '13:15', 'DIP',  'A-309B/A-310', 'lab'),
            (4, '13:15', '14:00', None,   '',             'break'),
            (4, '14:00', '15:00', 'AST',  'A-608',        'lecture'),
            (4, '15:00', '16:00', 'DBMS', 'A-608',        'lecture'),
        ]

        # Cleanup timetable for division A before reseeding
        # We must delete-then-recreate (not get_or_create) because:
        # NULL subject rows bypass PostgreSQL unique constraints -
        # NULL != NULL means duplicate break/activity slots are allowed by the DB.
        # A full delete of division A rows before insert is the safest approach.
        Timetable.objects.filter(division='A').delete()

        timetable_created = 0
        for day_idx, start, end, code, room, slot_type in timetable_rows:
            subj = None
            if code and code in subjects_map:
                subj = subjects_map[code]
                
            Timetable.objects.create(
                subject=subj,
                division='A',
                day_of_week=day_idx,
                start_time=datetime.time.fromisoformat(start),
                end_time=datetime.time.fromisoformat(end),
                room=room,
                slot_type=slot_type
            )
            timetable_created += 1

        self.stdout.write(f"  Timetable: {timetable_created} slots seeded for Division A")

        # 4. Enrollments
        for subj in subjects_map.values():
            Enrollment.objects.get_or_create(student=student, subject=subj)

        # 5. Summary Output
        self.stdout.write("========================================")
        self.stdout.write("  AttendIQ MVP — Seed Complete")
        self.stdout.write("========================================")
        self.stdout.write(f"  Student  → {student.email}  / Student@123")
        self.stdout.write(f"  Teacher  → {teacher.email}  / Teacher@123")
        self.stdout.write(f"  Admin    → {admin.email}    / Admin@123")
        self.stdout.write("----------------------------------------")
        self.stdout.write("  Division A timetable: seeded")
        self.stdout.write(f"  Subjects: {len(subjects_payload)}")
        self.stdout.write(f"  Enrolled: {student.full_name} in all {len(subjects_payload)} subjects")
        self.stdout.write("  Attendance records: 0 (upload via CSV)")
        self.stdout.write("========================================")
