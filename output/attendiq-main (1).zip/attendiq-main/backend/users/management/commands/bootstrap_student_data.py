from datetime import timedelta
import random

from django.core.management.base import BaseCommand, CommandError
from django.utils import timezone

from attendance.models import AttendanceRecord
from subjects.models import Enrollment, Subject, Timetable
from users.models import CustomUser


class Command(BaseCommand):
    help = "Enroll a student into existing subjects and backfill attendance records for testing."

    def add_arguments(self, parser):
        parser.add_argument("--email", required=True, help="Student email")
        parser.add_argument(
            "--days",
            type=int,
            default=45,
            help="How many past days to generate attendance for (default: 45)",
        )
        parser.add_argument(
            "--present-rate",
            type=float,
            default=0.8,
            help="Presence probability between 0.0 and 1.0 (default: 0.8)",
        )

    def handle(self, *args, **options):
        email = options["email"].strip().lower()
        days = options["days"]
        present_rate = options["present_rate"]

        if days < 1:
            raise CommandError("--days must be >= 1")
        if not 0.0 <= present_rate <= 1.0:
            raise CommandError("--present-rate must be between 0.0 and 1.0")

        try:
            student = CustomUser.objects.get(email=email)
        except CustomUser.DoesNotExist as exc:
            raise CommandError(f"No user found with email: {email}") from exc

        if student.role != "student":
            raise CommandError(f"User {email} is role={student.role}, expected role=student")

        subjects = list(Subject.objects.all())
        if not subjects:
            raise CommandError(
                "No subjects found. Create subjects first (or run seed_db) before bootstrapping student data."
            )

        enrollments_created = 0
        for subject in subjects:
            _, created = Enrollment.objects.get_or_create(student=student, subject=subject)
            if created:
                enrollments_created += 1

        day_code_by_weekday = {
            0: "mon",
            1: "tue",
            2: "wed",
            3: "thu",
            4: "fri",
            5: "sat",
            6: "sun",
        }

        records_created = 0
        records_existing = 0
        today = timezone.now().date()

        for i in range(days):
            current_date = today - timedelta(days=i)
            day_code = day_code_by_weekday[current_date.weekday()]

            for subject in subjects:
                # Generate attendance only on days where subject is scheduled.
                if not Timetable.objects.filter(subject=subject, day_of_week=day_code).exists():
                    continue

                status = "present" if random.random() <= present_rate else "absent"
                marker = subject.teacher if subject.teacher else None

                _, created = AttendanceRecord.objects.get_or_create(
                    student=student,
                    subject=subject,
                    date=current_date,
                    defaults={"status": status, "marked_by": marker},
                )
                if created:
                    records_created += 1
                else:
                    records_existing += 1

        self.stdout.write(self.style.SUCCESS("Student data bootstrap complete."))
        self.stdout.write(f"Student: {student.email}")
        self.stdout.write(f"Enrollments created: {enrollments_created}")
        self.stdout.write(f"Attendance records created: {records_created}")
        self.stdout.write(f"Attendance records already existed: {records_existing}")
