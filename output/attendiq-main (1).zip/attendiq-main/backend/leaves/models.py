from uuid import uuid4
from pathlib import Path

from django.db import models
from users.models import CustomUser
from subjects.models import Subject


class LeaveRequest(models.Model):
    STATUS_CHOICES = [
        ('pending', 'pending'),
        ('auto_approved', 'auto_approved'),
        ('approved', 'approved'),
        ('rejected', 'rejected')
    ]
    TYPE_CHOICES = [
        ('medical', 'medical'),
        ('academic', 'academic'),
        ('personal', 'personal'),
        ('other', 'other')
    ]
    PROOF_REQUIRED_TYPES = {'medical', 'academic'}
    ALLOWED_PROOF_CONTENT_TYPES = {'application/pdf', 'image/jpeg', 'image/png'}
    ALLOWED_PROOF_EXTENSIONS = {'.pdf', '.jpg', '.jpeg', '.png'}
    MAX_PROOF_SIZE_BYTES = 5 * 1024 * 1024

    id = models.UUIDField(primary_key=True, default=uuid4, editable=False)
    student = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='leave_requests')
    from_date = models.DateField()
    to_date = models.DateField()
    reason = models.CharField(max_length=500)
    leave_type = models.CharField(max_length=20, choices=TYPE_CHOICES)
    proof_file = models.FileField(upload_to='leave_proofs/%Y/%m/', null=True, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    reviewed_by = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True, blank=True, related_name='reviewed_leaves')
    review_note = models.CharField(max_length=500, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    @classmethod
    def proof_is_required(cls, leave_type):
        return leave_type in cls.PROOF_REQUIRED_TYPES

    @classmethod
    def proof_has_allowed_extension(cls, proof_file):
        return Path(proof_file.name).suffix.lower() in cls.ALLOWED_PROOF_EXTENSIONS

class LeaveRequestSubject(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid4, editable=False)
    leave_request = models.ForeignKey(LeaveRequest, on_delete=models.CASCADE, related_name='affected_subjects')
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE)
    predicted_pct = models.FloatField()
