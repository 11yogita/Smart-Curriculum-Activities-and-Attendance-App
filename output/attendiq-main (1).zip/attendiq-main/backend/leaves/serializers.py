from pathlib import Path

from rest_framework import serializers

from .models import LeaveRequest, LeaveRequestSubject


class LeaveRequestSubjectSerializer(serializers.ModelSerializer):
    subject_name = serializers.CharField(source='subject.name', read_only=True)
    
    class Meta:
        model = LeaveRequestSubject
        fields = ('subject_name', 'predicted_pct')

class LeaveRequestSerializer(serializers.ModelSerializer):
    affected_subjects = LeaveRequestSubjectSerializer(many=True, read_only=True)
    student_name = serializers.CharField(source='student.full_name', read_only=True, default=None)
    student_id = serializers.CharField(source='student.student_id', read_only=True, default=None)
    reviewed_by_name = serializers.CharField(source='reviewed_by.full_name', read_only=True, default=None)
    proof_file = serializers.SerializerMethodField()
    proof_file_name = serializers.SerializerMethodField()

    def get_proof_file(self, obj):
        if not obj.proof_file:
            return None

        request = self.context.get('request')
        url = obj.proof_file.url
        return request.build_absolute_uri(url) if request else url

    def get_proof_file_name(self, obj):
        if not obj.proof_file:
            return None
        return Path(obj.proof_file.name).name

    class Meta:
        model = LeaveRequest
        fields = (
            'id', 'student_name', 'student_id', 'from_date', 'to_date',
            'leave_type', 'reason', 'status', 'review_note',
            'reviewed_by_name', 'created_at', 'updated_at',
            'affected_subjects', 'proof_file', 'proof_file_name'
        )
