from rest_framework.views import APIView
from rest_framework import status
from rest_framework.response import Response
from datetime import datetime
from django.db import transaction

from .models import LeaveRequest, LeaveRequestSubject
from .serializers import LeaveRequestSerializer
from subjects.models import Subject
from attendance.services import run_prediction_formula, get_timetable_slots_in_range
from users.permissions import IsStudent, IsTeacher


def _normalize_subject_ids(data):
    if hasattr(data, 'getlist'):
        return data.getlist('subject_ids')

    subject_ids = data.get('subject_ids', [])
    if isinstance(subject_ids, list):
        return subject_ids
    if subject_ids in (None, ''):
        return []
    return [subject_ids]


def _validate_proof_file(leave_type, proof_file):
    if LeaveRequest.proof_is_required(leave_type) and not proof_file:
        return "Proof document is required for medical and academic leaves."

    if not proof_file:
        return None

    content_type = (proof_file.content_type or '').lower()
    if (
        content_type not in LeaveRequest.ALLOWED_PROOF_CONTENT_TYPES
        or not LeaveRequest.proof_has_allowed_extension(proof_file)
    ):
        return "Only PDF, JPG, and PNG proof files are allowed."

    if proof_file.size > LeaveRequest.MAX_PROOF_SIZE_BYTES:
        return "Proof file must be 5 MB or smaller."

    return None


def _create_absence_records_for_leave(leave):
    """
    When a leave is approved (either auto or by teacher), create AttendanceRecord
    rows for each subject x each date in the leave range that has a timetable slot.

    Uses update_or_create so running this twice never creates duplicates.
    Only creates records for dates that actually have a class (lecture or lab).
    Does not overwrite records that are already marked 'present'.
    """
    from attendance.models import AttendanceRecord
    from subjects.models import Timetable
    from datetime import timedelta

    student = leave.student
    from_date = leave.from_date
    to_date = leave.to_date

    for leave_subject in leave.affected_subjects.select_related('subject'):
        subject = leave_subject.subject

        # Get all timetable slots for this subject (lecture + lab only)
        slot_weekdays = list(
            Timetable.objects.filter(
                subject=subject,
                slot_type__in=['lecture', 'lab']
            ).values_list('day_of_week', flat=True)
        )

        if not slot_weekdays:
            continue

        # Walk through every date in the leave range
        current = from_date
        while current <= to_date:
            weekday = current.weekday()  # 0=Monday ... 6=Sunday

            # How many timetable slots on this weekday for this subject?
            slots_on_this_day = slot_weekdays.count(weekday)

            if slots_on_this_day > 0:
                # Create ONE absence record per subject per date
                # (one record covers all slots on that day)
                obj, created = AttendanceRecord.objects.update_or_create(
                    student=student,
                    subject=subject,
                    date=current,
                    defaults={
                        'status': 'absent',
                        'marked_by': None,
                    }
                )
                # IMPORTANT: Do NOT overwrite a record that is already 'present'
                # If the student was already marked present for that date, keep it
                if not created and obj.status == 'present':
                    # Revert - do not overwrite a present record with absent
                    obj.status = 'present'
                    obj.save()

            current += timedelta(days=1)

class StudentLeaveView(APIView):
    permission_classes = [IsStudent]

    def get(self, request):
        leaves = LeaveRequest.objects.filter(student=request.user).order_by('-created_at')
        serializer = LeaveRequestSerializer(leaves, many=True, context={'request': request})
        return Response({"leaves": serializer.data})

    def post(self, request):
        data = request.data
        from_date_str = data.get('from_date')
        to_date_str = data.get('to_date')
        leave_type = data.get('leave_type')
        reason = data.get('reason')
        subject_ids = _normalize_subject_ids(data)
        proof_file = request.FILES.get('proof_file')

        if not all([from_date_str, to_date_str, leave_type, reason, subject_ids]):
            return Response({"detail": "Missing required fields"}, status=status.HTTP_400_BAD_REQUEST)
            
        try:
            from_date = datetime.strptime(from_date_str, '%Y-%m-%d').date()
            to_date = datetime.strptime(to_date_str, '%Y-%m-%d').date()
        except ValueError:
            return Response({"detail": "Invalid dates"}, status=status.HTTP_400_BAD_REQUEST)
            
        if from_date > to_date:
            return Response({"detail": "from_date must be <= to_date"}, status=status.HTTP_400_BAD_REQUEST)
            
        if leave_type not in [c[0] for c in LeaveRequest.TYPE_CHOICES]:
            return Response({"detail": "Invalid leave type"}, status=status.HTTP_400_BAD_REQUEST)

        proof_validation_error = _validate_proof_file(leave_type, proof_file)
        if proof_validation_error:
            return Response({"detail": proof_validation_error}, status=status.HTTP_400_BAD_REQUEST)

        if len(reason) > 500:
            return Response({"detail": "Reason max length is 500 characters"}, status=status.HTTP_400_BAD_REQUEST)
            
        # Get subjects
        try:
            subjects = Subject.objects.filter(id__in=subject_ids, enrollments__student=request.user)
            if subjects.count() != len(subject_ids):
                return Response({"detail": "One or more subjects not found or not enrolled"}, status=status.HTTP_400_BAD_REQUEST)
        except Exception:
            return Response({"detail": "Invalid subject IDs"}, status=status.HTTP_400_BAD_REQUEST)
            
        predicted_data = []
        all_safe = True
        
        for subject in subjects:
            miss_count = get_timetable_slots_in_range(subject, from_date, to_date)
            # Even if miss_count is 0, we still compute to get current_pct
            res = run_prediction_formula(request.user, subject, miss_count)
            pct = res['predicted_pct']
            predicted_data.append((subject, pct))
            if pct < 75.0:
                all_safe = False
                
        leave_status = 'auto_approved' if all_safe else 'pending'
        
        with transaction.atomic():
            leave = LeaveRequest.objects.create(
                student=request.user,
                from_date=from_date,
                to_date=to_date,
                reason=reason,
                leave_type=leave_type,
                proof_file=proof_file,
                status=leave_status
            )
            for subject, pct in predicted_data:
                LeaveRequestSubject.objects.create(
                    leave_request=leave,
                    subject=subject,
                    predicted_pct=pct
                )
            # If auto-approved, immediately create absence records
            if leave_status == 'auto_approved':
                _create_absence_records_for_leave(leave)

        serializer = LeaveRequestSerializer(leave, context={'request': request})
        return Response(serializer.data, status=status.HTTP_201_CREATED)

class TeacherLeaveView(APIView):
    permission_classes = [IsTeacher]

    def get(self, request):
        status_filter = request.query_params.get('status')
        
        # Teacher can only see leaves that affect subjects they teach
        leaves = LeaveRequest.objects.filter(
            affected_subjects__subject__teacher=request.user
        ).distinct().order_by('-created_at')
        
        if status_filter == 'pending':
            leaves = leaves.filter(status='pending')

        serializer = LeaveRequestSerializer(leaves, many=True, context={'request': request})
        return Response({"leaves": serializer.data})

class TeacherLeaveDetailView(APIView):
    permission_classes = [IsTeacher]

    def patch(self, request, leave_id):
        try:
            leave = LeaveRequest.objects.get(id=leave_id)
        except LeaveRequest.DoesNotExist:
            return Response({"detail": "Not found"}, status=status.HTTP_404_NOT_FOUND)
            
        # Verify teacher owns at least one affected subject
        owns_subject = leave.affected_subjects.filter(subject__teacher=request.user).exists()
        if not owns_subject:
            return Response({"detail": "You do not teach any subjects in this leave request."}, status=status.HTTP_403_FORBIDDEN)
            
        action = request.data.get('action')
        review_note = request.data.get('review_note', '').strip()
        
        if action not in ['approved', 'rejected']:
            return Response({"detail": "Invalid action"}, status=status.HTTP_400_BAD_REQUEST)
            
        if action == 'rejected' and not review_note:
            return Response({"detail": "Review note required when rejecting"}, status=status.HTTP_400_BAD_REQUEST)
            
        leave.status = action
        leave.reviewed_by = request.user
        leave.review_note = review_note
        leave.save()

        # If teacher approved the leave, create absence records for the student
        if action == 'approved':
            _create_absence_records_for_leave(leave)
        
        serializer = LeaveRequestSerializer(leave, context={'request': request})
        return Response(serializer.data, status=status.HTTP_200_OK)
