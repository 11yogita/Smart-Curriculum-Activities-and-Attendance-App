import tempfile
from datetime import date, time
from unittest.mock import patch

from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TestCase, override_settings
from rest_framework.test import APIClient

from attendance.models import AttendanceRecord
from leaves.models import LeaveRequest
from subjects.models import Enrollment, Subject, Timetable
from users.models import CustomUser


@override_settings(MEDIA_ROOT=tempfile.mkdtemp())
class StudentLeaveProofUploadTests(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.student = CustomUser.objects.create_user(
            email="student@example.com",
            password="pass1234",
            full_name="Student User",
            role="student",
            student_id="STU001",
            division="A",
        )
        self.teacher = CustomUser.objects.create_user(
            email="teacher@example.com",
            password="pass1234",
            full_name="Teacher User",
            role="teacher",
        )
        self.subject = Subject.objects.create(
            name="Algorithms",
            subject_code="CS301",
            teacher=self.teacher,
        )
        Enrollment.objects.create(student=self.student, subject=self.subject)
        Timetable.objects.create(
            subject=self.subject,
            division="A",
            day_of_week=0,
            start_time=time(9, 0),
            end_time=time(10, 0),
            slot_type="lecture",
        )
        AttendanceRecord.objects.create(
            student=self.student,
            subject=self.subject,
            date=date(2026, 3, 30),
            status="present",
            marked_by=self.teacher,
        )
        self.client.force_authenticate(user=self.student)
        self.url = "/api/v1/student/leave/"

    def make_payload(self, leave_type="medical"):
        return {
            "leave_type": leave_type,
            "from_date": "2026-04-06",
            "to_date": "2026-04-06",
            "reason": "Need permission",
            "subject_ids": [str(self.subject.id)],
        }

    def make_pdf(self, name="proof.pdf", content=b"%PDF-1.4 test"):
        return SimpleUploadedFile(name, content, content_type="application/pdf")

    def test_medical_leave_requires_proof(self):
        response = self.client.post(self.url, data=self.make_payload("medical"), format="multipart")

        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.data["detail"], "Proof document is required for medical and academic leaves.")

    def test_academic_leave_requires_proof(self):
        response = self.client.post(self.url, data=self.make_payload("academic"), format="multipart")

        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.data["detail"], "Proof document is required for medical and academic leaves.")

    def test_personal_leave_allows_missing_proof(self):
        response = self.client.post(self.url, data=self.make_payload("personal"), format="multipart")

        self.assertEqual(response.status_code, 201)
        self.assertIsNone(response.data["proof_file"])

    def test_other_leave_allows_missing_proof(self):
        response = self.client.post(self.url, data=self.make_payload("other"), format="multipart")

        self.assertEqual(response.status_code, 201)
        self.assertIsNone(response.data["proof_file"])

    def test_rejects_invalid_proof_type(self):
        payload = self.make_payload("medical")
        payload["proof_file"] = SimpleUploadedFile(
            "proof.txt",
            b"bad",
            content_type="text/plain",
        )

        response = self.client.post(self.url, data=payload, format="multipart")

        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.data["detail"], "Only PDF, JPG, and PNG proof files are allowed.")

    def test_rejects_oversized_proof_file(self):
        payload = self.make_payload("medical")
        payload["proof_file"] = SimpleUploadedFile(
            "proof.pdf",
            b"x" * (5 * 1024 * 1024 + 1),
            content_type="application/pdf",
        )

        response = self.client.post(self.url, data=payload, format="multipart")

        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.data["detail"], "Proof file must be 5 MB or smaller.")

    @patch("leaves.views.run_prediction_formula")
    def test_successful_medical_leave_returns_proof_metadata(self, mock_prediction):
        mock_prediction.return_value = {
            "subject_id": self.subject.id,
            "subject_name": self.subject.name,
            "current_pct": 100.0,
            "predicted_pct": 80.0,
            "delta": -20.0,
            "classes_missed": 1,
            "safe": True,
        }
        payload = self.make_payload("medical")
        payload["proof_file"] = self.make_pdf()

        response = self.client.post(self.url, data=payload, format="multipart")

        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.data["leave_type"], "medical")
        self.assertEqual(response.data["proof_file_name"], "proof.pdf")
        self.assertIn("/leave_proofs/", response.data["proof_file"])
        self.assertTrue(LeaveRequest.objects.filter(id=response.data["id"]).exists())
