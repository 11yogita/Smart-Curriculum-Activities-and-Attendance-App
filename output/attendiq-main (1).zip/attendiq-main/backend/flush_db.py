import os, django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "attendiq.settings")
django.setup()
from django.db import connection
with connection.cursor() as cursor:
    cursor.execute("DROP SCHEMA public CASCADE; CREATE SCHEMA public;")
    cursor.execute("GRANT ALL ON SCHEMA public TO attendiq_user;")
    cursor.execute("GRANT ALL ON SCHEMA public TO public;")
print("Schema public dropped and recreated successfully.")
