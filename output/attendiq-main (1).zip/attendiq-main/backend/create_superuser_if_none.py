import os
import django
from django.conf import settings

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "attendiq.settings")
django.setup()

from django.contrib.auth import get_user_model

User = get_user_model()

if not User.objects.filter(email='admin@example.com').exists():
    print("Creating superuser 'admin@example.com' with password 'admin123'")
    try:
        User.objects.create_superuser(
            email='admin@example.com',
            password='admin123',
            role='admin',
            full_name='System Admin'
        )
        print("Superuser created successfully.")
    except Exception as e:
        print(f"Error creating superuser: {e}")
else:
    print("Superuser already exists.")
