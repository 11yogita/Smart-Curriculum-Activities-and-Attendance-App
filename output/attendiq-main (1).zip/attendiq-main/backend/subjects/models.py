from django.db import models
from uuid import uuid4
from users.models import CustomUser

class Subject(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid4, editable=False)
    name = models.CharField(max_length=255)
    subject_code = models.CharField(max_length=20, unique=True)
    teacher = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True, related_name='taught_subjects')
    credits = models.PositiveIntegerField(default=3)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.subject_code} - {self.name}"

class Enrollment(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid4, editable=False)
    student = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='enrollments')
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE, related_name='enrollments')
    enrolled_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ['student', 'subject']

    def __str__(self):
        return f"{self.student.email} -> {self.subject.subject_code}"

class Timetable(models.Model):
    SLOT_TYPES = [
        ('lecture', 'lecture'),
        ('lab', 'lab'),
        ('minor', 'minor'),
        ('activity', 'activity'),
        ('wellness', 'wellness'),
        ('cep', 'cep'),
        ('break', 'break'),
    ]

    id = models.UUIDField(primary_key=True, default=uuid4, editable=False)
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE, related_name='timetable_slots', null=True, blank=True)
    division = models.CharField(max_length=10, default='A')
    day_of_week = models.IntegerField()  # 0=Mon, 1=Tue, ... 6=Sun
    start_time = models.TimeField()
    end_time = models.TimeField()
    room = models.CharField(max_length=50, blank=True)
    slot_type = models.CharField(max_length=20, choices=SLOT_TYPES, default='lecture')

    class Meta:
        # unique_together does NOT prevent duplicate break/activity rows
        # because PostgreSQL treats NULL != NULL in unique constraints.
        # Rows where subject=NULL (breaks, activities) can be duplicated
        # at the DB level despite this constraint.
        # The seed_db command uses filter(division=X).delete() before
        # inserting to prevent this - do not remove that delete call.
        unique_together = ['division', 'day_of_week', 'start_time', 'subject']

    def __str__(self):
        return f"{self.division} | {self.day_of_week} | {self.start_time} - {self.end_time}"

class TimetableUpload(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid4, editable=False)
    uploaded_by = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True)
    file_name = models.CharField(max_length=255)
    rows_inserted = models.IntegerField(default=0)
    rows_skipped = models.IntegerField(default=0)
    rows_failed = models.IntegerField(default=0)
    status = models.CharField(max_length=20)
    error_report = models.JSONField(default=list)
    created_at = models.DateTimeField(auto_now_add=True)
