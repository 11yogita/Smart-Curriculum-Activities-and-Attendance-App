from rest_framework import serializers
from .models import Subject
from users.serializers import UserSerializer

class SubjectSerializer(serializers.ModelSerializer):
    class Meta:
        model = Subject
        fields = ('id', 'name', 'subject_code', 'teacher', 'credits')

class TeacherSubjectSerializer(serializers.ModelSerializer):
    enrolled_count = serializers.IntegerField(read_only=True)
    avg_attendance_pct = serializers.FloatField(read_only=True)
    below_threshold_count = serializers.IntegerField(read_only=True)
    
    # We will compute these in the view using annotate, 
    # but map them here for the exact response
    subject_id = serializers.UUIDField(source='id', read_only=True)
    subject_name = serializers.CharField(source='name', read_only=True)

    class Meta:
        model = Subject
        fields = ('subject_id', 'subject_name', 'subject_code', 'enrolled_count', 'avg_attendance_pct', 'below_threshold_count')

class AdminSubjectSerializer(serializers.ModelSerializer):
    teacher_name = serializers.CharField(source='teacher.full_name', read_only=True, default=None)
    enrolled_count = serializers.IntegerField(read_only=True)
    
    class Meta:
        model = Subject
        fields = ('id', 'name', 'subject_code', 'teacher', 'teacher_name', 'credits', 'enrolled_count')
