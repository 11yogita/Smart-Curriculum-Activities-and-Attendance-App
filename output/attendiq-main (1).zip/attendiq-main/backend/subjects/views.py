from rest_framework import generics, status
from rest_framework.response import Response
from django.db.models import Count
from django.db import models
from .models import Subject, Enrollment
from attendance.models import AttendanceRecord
from .serializers import SubjectSerializer, TeacherSubjectSerializer, AdminSubjectSerializer
from users.permissions import IsTeacher, IsAdmin

class TeacherSubjectListView(generics.ListAPIView):
    serializer_class = TeacherSubjectSerializer
    permission_classes = [IsTeacher]

    def get_queryset(self):
        # Base subjects assigned to this teacher
        queryset = Subject.objects.filter(teacher=self.request.user)
        
        # Annotate enrolled count
        queryset = queryset.annotate(enrolled_count=Count('enrollments', distinct=True))
        
        # For average attendance pct and below threshold, we'll process in python
        # because the formula includes grouping per student first.
        # It's cleaner to override list() or calculate dynamically due to complexity.
        # But for brevity and performance in this prototype, doing it in python per subject:
        return queryset

    def list(self, request, *args, **kwargs):
        queryset = self.get_queryset()
        
        response_data = []
        for subject in queryset:
            student_records = AttendanceRecord.objects.filter(
                subject=subject, 
                status__in=['present', 'absent']
            )
            
            # Map student -> total/present
            student_stats = {}
            for rec in student_records:
                student_id = rec.student_id
                if student_id not in student_stats:
                    student_stats[student_id] = {'present': 0, 'total': 0}
                student_stats[student_id]['total'] += 1
                if rec.status == 'present':
                    student_stats[student_id]['present'] += 1
                    
            below_threshold_count = 0
            total_pct_sum = 0
            student_count = len(student_stats)
            
            for sid, stats in student_stats.items():
                pct = (stats['present'] / stats['total']) * 100
                total_pct_sum += pct
                if pct < 75.0:
                    below_threshold_count += 1
                    
            avg_attendance_pct = (total_pct_sum / student_count) if student_count > 0 else 0.0
            
            # Use serializer logic mapping manually here
            response_data.append({
                'subject_id': subject.id,
                'subject_name': subject.name,
                'subject_code': subject.subject_code,
                'enrolled_count': subject.enrolled_count, # from DB annotate
                'avg_attendance_pct': round(avg_attendance_pct, 1),
                'below_threshold_count': below_threshold_count
            })
            
        return Response({'subjects': response_data})


class AdminSubjectListView(generics.ListCreateAPIView):
    permission_classes = [IsAdmin]
    serializer_class = AdminSubjectSerializer
    
    def get_queryset(self):
        return Subject.objects.annotate(enrolled_count=Count('enrollments', distinct=True))

    def create(self, request, *args, **kwargs):
        serializer = SubjectSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        return Response(serializer.data, status=status.HTTP_201_CREATED)


class AdminSubjectDetailView(generics.RetrieveUpdateDestroyAPIView):
    permission_classes = [IsAdmin]
    serializer_class = SubjectSerializer
    queryset = Subject.objects.all()
    lookup_field = 'id'
    lookup_url_kwarg = 'subject_id'

    def destroy(self, request, *args, **kwargs):
        subject = self.get_object()
        if AttendanceRecord.objects.filter(subject=subject).exists():
            return Response({'detail': 'Cannot delete subject with attendance records.'}, status=status.HTTP_400_BAD_REQUEST)
        self.perform_destroy(subject)
        return Response(status=status.HTTP_200_OK)
