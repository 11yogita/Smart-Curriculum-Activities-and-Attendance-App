from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/v1/auth/', include('users.urls')),
    path('api/v1/student/', include('attendance.urls.student')),
    path('api/v1/teacher/', include('attendance.urls.teacher')),
    path('api/v1/admin/', include('attendance.urls.admin_urls')),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
